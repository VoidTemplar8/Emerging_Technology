﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>
#include <stdint.h>



// System.Action`3<System.Int32,System.Single[],System.Single>
struct Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8;
// System.Action`3<System.Int32,System.Object,System.Single>
struct Action_3_t041F9EB77535247CDCF010C1F285CCCEFE9E2F04;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_tF95C9E01A913DD50575531C8305932628663D9E9;
// System.Collections.Generic.IEnumerable`1<System.String>
struct IEnumerable_1_t349E66EC5F09B881A8E52EE40A1AB9EC60E08E44;
// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D;
// System.Collections.Generic.List`1<System.String>
struct List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD;
// System.Delegate[]
struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771;
// System.IntPtr[]
struct IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832;
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
// System.Single[]
struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF;
// System.String[]
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248;
// System.Action
struct Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07;
// System.ArgumentException
struct ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263;
// UnityEngine.AudioClip
struct AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20;
// Meta.WitAi.Data.AudioEncoding
struct AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4;
// UnityEngine.Component
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3;
// UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B;
// System.Delegate
struct Delegate_t;
// System.DelegateData
struct DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E;
// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F;
// System.Collections.IDictionary
struct IDictionary_t6D03155AF1FA9083817AA5B6AD7DEEACC26AB220;
// System.Collections.IEnumerator
struct IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// Meta.WitAi.Lib.Mic
struct Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71;
// System.NotSupportedException
struct NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A;
// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6;
// System.String
struct String_t;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
// UnityEngine.AudioClip/PCMReaderCallback
struct PCMReaderCallback_t3396D9613664F0AFF65FB91018FD0F901CC16F1E;
// UnityEngine.AudioClip/PCMSetPositionCallback
struct PCMSetPositionCallback_t8D7135A2FB40647CAEC93F5254AD59E18DEB6072;
// Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63
struct U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06;

IL2CPP_EXTERN_C RuntimeClass* Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* GameObject_t76FEDD663AB33C991A9C9A23129337651094216F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* String_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral1790BC7E4E368961EF01213AD7625F9B4441C2B1;
IL2CPP_EXTERN_C String_t* _stringLiteral2709CB4BF2E45EF9216A9D5D0AD1EE93A89B7FE0;
IL2CPP_EXTERN_C String_t* _stringLiteral31D159E683556C06B3B3963D92483B6867EB3233;
IL2CPP_EXTERN_C String_t* _stringLiteral58BC5A0E2D16839B25D7C05F8A250FA68C1AE016;
IL2CPP_EXTERN_C String_t* _stringLiteral5C2C6219EF9AB59B9DE4705897BA951EAFCFBD15;
IL2CPP_EXTERN_C String_t* _stringLiteral8E22AE7C8B8A3D5C7E3553929D697ECBD2DD6053;
IL2CPP_EXTERN_C String_t* _stringLiteral9653A58C4B17007757C99F5A3DD834C1D2E849B0;
IL2CPP_EXTERN_C String_t* _stringLiteralA055516D7CAA2F33278EED3418825E4D7F00D098;
IL2CPP_EXTERN_C String_t* _stringLiteralA27E50E0D7CA344AD5EAF74DD75F77225C4765E2;
IL2CPP_EXTERN_C String_t* _stringLiteralC64EEDB786A80FA4B5C8F83347AD5B82F544A7EA;
IL2CPP_EXTERN_C String_t* _stringLiteralCE18B047107AA23D1AA9B2ED32D316148E02655F;
IL2CPP_EXTERN_C String_t* _stringLiteralE2F929D5515E822FE1F09FC643A45DF3B563BDF8;
IL2CPP_EXTERN_C String_t* _stringLiteralE85AE323424CD7FD07E8850BE5AF84790EA74328;
IL2CPP_EXTERN_C String_t* _stringLiteralFA4604892145AEA13A6D0A7FB0E52EB5803A160C;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_AddComponent_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_mEDE89F407EEBE6CD16CDDF8EDE285FFFC92AC40A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_AddRange_m157DD7AD4D25423F82A21E533BC4686C83770D5E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_IndexOf_m407F5E43ED8B2BD39036693B8F25F363362CE9D4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mCA8DD57EAC70C2B5923DBB9D5A77CEAC22E7068E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m21AEC50E791371101DC22ABCF96A2E46800811F8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Object_FindObjectOfType_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_m30B96F175E1C053E8EFDFECC85BFF5B790180DCE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Profiler_ValidateArguments_m631DF788CA8A7DF599A5871AF4D7FA8B9C3B52CC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CReadRawAudioU3Ed__63_System_Collections_IEnumerator_Reset_mE39146B37BAA48B306DCD9958270B6BA192FF67D_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;

struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C;
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tA6D51A7FDE251DBBE3ECF2A15EE64F75EADF4F61 
{
};

// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.String>
struct List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

struct List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* ___s_emptyArray_5;
};
struct Il2CppArrayBounds;

// Meta.WitAi.Data.AudioEncoding
struct AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4  : public RuntimeObject
{
	// System.String Meta.WitAi.Data.AudioEncoding::encoding
	String_t* ___encoding_0;
	// System.Int32 Meta.WitAi.Data.AudioEncoding::bits
	int32_t ___bits_1;
	// System.Int32 Meta.WitAi.Data.AudioEncoding::samplerate
	int32_t ___samplerate_2;
	// Meta.WitAi.Data.AudioEncoding/Endian Meta.WitAi.Data.AudioEncoding::endian
	int32_t ___endian_3;
};

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_com
{
};

// Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63
struct U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06  : public RuntimeObject
{
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<>2__current
	RuntimeObject* ___U3CU3E2__current_1;
	// Meta.WitAi.Lib.Mic Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<>4__this
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* ___U3CU3E4__this_2;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<loops>5__1
	int32_t ___U3CloopsU3E5__1_3;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<readAbsPos>5__2
	int32_t ___U3CreadAbsPosU3E5__2_4;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<prevPos>5__3
	int32_t ___U3CprevPosU3E5__3_5;
	// System.Single[] Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<temp>5__4
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___U3CtempU3E5__4_6;
	// System.Boolean Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<isNewDataAvailable>5__5
	bool ___U3CisNewDataAvailableU3E5__5_7;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<currPos>5__6
	int32_t ___U3CcurrPosU3E5__6_8;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<currAbsPos>5__7
	int32_t ___U3CcurrAbsPosU3E5__7_9;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<nextReadAbsPos>5__8
	int32_t ___U3CnextReadAbsPosU3E5__8_10;
	// System.Single Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<levelMax>5__9
	float ___U3ClevelMaxU3E5__9_11;
	// System.Int32 Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<i>5__10
	int32_t ___U3CiU3E5__10_12;
	// System.Single Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::<wavePeak>5__11
	float ___U3CwavePeakU3E5__11_13;
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// System.Single
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	// System.Single System.Single::m_value
	float ___m_value_0;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B  : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D
{
	// System.IntPtr UnityEngine.Coroutine::m_Ptr
	intptr_t ___m_Ptr_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B_marshaled_pinvoke : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B_marshaled_com : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_com
{
	intptr_t ___m_Ptr_0;
};

// System.Delegate
struct Delegate_t  : public RuntimeObject
{
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject* ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.IntPtr System.Delegate::interp_method
	intptr_t ___interp_method_7;
	// System.IntPtr System.Delegate::interp_invoke_impl
	intptr_t ___interp_invoke_impl_8;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t* ___method_info_9;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t* ___original_method_info_10;
	// System.DelegateData System.Delegate::data
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_12;
};
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};

// System.Exception
struct Exception_t  : public RuntimeObject
{
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t* ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject* ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject* ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832* ___native_trace_ips_15;
	// System.Int32 System.Exception::caught_in_unmanaged
	int32_t ___caught_in_unmanaged_16;
};

struct Exception_t_StaticFields
{
	// System.Object System.Exception::s_EDILock
	RuntimeObject* ___s_EDILock_0;
};
// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
	int32_t ___caught_in_unmanaged_16;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
	int32_t ___caught_in_unmanaged_16;
};

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;
};

struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;
};
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.AudioClip
struct AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
	// UnityEngine.AudioClip/PCMReaderCallback UnityEngine.AudioClip::m_PCMReaderCallback
	PCMReaderCallback_t3396D9613664F0AFF65FB91018FD0F901CC16F1E* ___m_PCMReaderCallback_4;
	// UnityEngine.AudioClip/PCMSetPositionCallback UnityEngine.AudioClip::m_PCMSetPositionCallback
	PCMSetPositionCallback_t8D7135A2FB40647CAEC93F5254AD59E18DEB6072* ___m_PCMSetPositionCallback_5;
};

// UnityEngine.Component
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// System.MulticastDelegate
struct MulticastDelegate_t  : public Delegate_t
{
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771* ___delegates_13;
};
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_13;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_13;
};

// System.SystemException
struct SystemException_tCC48D868298F4C0705279823E34B00F4FBDB7295  : public Exception_t
{
};

// System.Action`3<System.Int32,System.Single[],System.Single>
struct Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8  : public MulticastDelegate_t
{
};

// System.Action`3<System.Int32,System.Object,System.Single>
struct Action_3_t041F9EB77535247CDCF010C1F285CCCEFE9E2F04  : public MulticastDelegate_t
{
};

// System.Action
struct Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07  : public MulticastDelegate_t
{
};

// System.ArgumentException
struct ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263  : public SystemException_tCC48D868298F4C0705279823E34B00F4FBDB7295
{
	// System.String System.ArgumentException::_paramName
	String_t* ____paramName_18;
};

// UnityEngine.Behaviour
struct Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};

// System.NotSupportedException
struct NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A  : public SystemException_tCC48D868298F4C0705279823E34B00F4FBDB7295
{
};

// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71  : public Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA
{
};

// Meta.WitAi.Lib.Mic
struct Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// System.Boolean Meta.WitAi.Lib.Mic::<IsRecording>k__BackingField
	bool ___U3CIsRecordingU3Ek__BackingField_4;
	// Meta.WitAi.Data.AudioEncoding Meta.WitAi.Lib.Mic::<AudioEncoding>k__BackingField
	AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* ___U3CAudioEncodingU3Ek__BackingField_5;
	// System.Single[] Meta.WitAi.Lib.Mic::<Sample>k__BackingField
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___U3CSampleU3Ek__BackingField_6;
	// System.Int32 Meta.WitAi.Lib.Mic::<SampleDurationMS>k__BackingField
	int32_t ___U3CSampleDurationMSU3Ek__BackingField_7;
	// UnityEngine.AudioClip Meta.WitAi.Lib.Mic::<AudioClip>k__BackingField
	AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* ___U3CAudioClipU3Ek__BackingField_8;
	// System.Collections.Generic.List`1<System.String> Meta.WitAi.Lib.Mic::_devices
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* ____devices_9;
	// System.Int32 Meta.WitAi.Lib.Mic::<CurrentDeviceIndex>k__BackingField
	int32_t ___U3CCurrentDeviceIndexU3Ek__BackingField_10;
	// System.Int32 Meta.WitAi.Lib.Mic::m_SampleCount
	int32_t ___m_SampleCount_11;
	// System.Action Meta.WitAi.Lib.Mic::OnStartRecording
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___OnStartRecording_12;
	// System.Action Meta.WitAi.Lib.Mic::OnStartRecordingFailed
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___OnStartRecordingFailed_13;
	// System.Action`3<System.Int32,System.Single[],System.Single> Meta.WitAi.Lib.Mic::OnSampleReady
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* ___OnSampleReady_14;
	// System.Action Meta.WitAi.Lib.Mic::OnStopRecording
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___OnStopRecording_15;
};

struct Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields
{
	// Meta.WitAi.Lib.Mic Meta.WitAi.Lib.Mic::m_Instance
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* ___m_Instance_16;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Single[]
struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C  : public RuntimeArray
{
	ALIGN_FIELD (8) float m_Items[1];

	inline float GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline float* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, float value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline float GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline float* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, float value)
	{
		m_Items[index] = value;
	}
};
// System.String[]
struct StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248  : public RuntimeArray
{
	ALIGN_FIELD (8) String_t* m_Items[1];

	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, int32_t ___index0, const RuntimeMethod* method) ;
// T UnityEngine.Object::FindObjectOfType<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Object_FindObjectOfType_TisRuntimeObject_m02DFBF011F3B59F777A5E521DB2A116DD496E968_gshared (const RuntimeMethod* method) ;
// T UnityEngine.GameObject::AddComponent<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* GameObject_AddComponent_TisRuntimeObject_m69B93700FACCF372F5753371C6E8FB780800B824_gshared (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::AddRange(System.Collections.Generic.IEnumerable`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_AddRange_m1F76B300133150E6046C5FED00E88B5DE0A02E17_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, RuntimeObject* ___collection0, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.Object>::IndexOf(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t List_1_IndexOf_m378F61BA812B79DEE58D86FE8AA9F20E3FC7D85F_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, RuntimeObject* ___item0, const RuntimeMethod* method) ;
// System.Void System.Action`3<System.Int32,System.Object,System.Single>::Invoke(T1,T2,T3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Action_3_Invoke_mE6726AD48C4B0576C12CD89A49A438E707529E36_gshared_inline (Action_3_t041F9EB77535247CDCF010C1F285CCCEFE9E2F04* __this, int32_t ___arg10, RuntimeObject* ___arg21, float ___arg32, const RuntimeMethod* method) ;

// UnityEngine.AudioClip Meta.WitAi.Lib.Mic::get_AudioClip()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Object::op_Implicit(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Implicit_m93896EF7D68FA113C42D3FE2BC6F661FC7EF514A (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___exists0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::SafeStartMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// Meta.WitAi.Data.AudioEncoding Meta.WitAi.Lib.Mic::get_AudioEncoding()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Int32 Meta.WitAi.Lib.Mic::get_SampleDurationMS()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mic_get_SampleDurationMS_m725B8440FA1DDC9445253977331420E34B115739_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::RefreshMicDevices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_RefreshMicDevices_m132BFED58C51905648DF930AC9CBEBBBADF3BA24 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Int32 Meta.WitAi.Lib.Mic::get_CurrentDeviceIndex()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<System.String> Meta.WitAi.Lib.Mic::get_Devices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.String>::get_Count()
inline int32_t List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// T System.Collections.Generic.List`1<System.String>::get_Item(System.Int32)
inline String_t* List_1_get_Item_m21AEC50E791371101DC22ABCF96A2E46800811F8 (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* __this, int32_t ___index0, const RuntimeMethod* method)
{
	return ((  String_t* (*) (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*, int32_t, const RuntimeMethod*))List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared)(__this, ___index0, method);
}
// System.String Meta.WitAi.Lib.Mic::get_CurrentDeviceName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Microphone::GetPosition(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Microphone_GetPosition_m13F4C8EBE8536893D9AD8388B0E5B46D62E6A459 (String_t* ___deviceName0, const RuntimeMethod* method) ;
// System.Delegate System.Delegate::Combine(System.Delegate,System.Delegate)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Delegate_t* Delegate_Combine_m1F725AEF318BE6F0426863490691A6F4606E7D00 (Delegate_t* ___a0, Delegate_t* ___b1, const RuntimeMethod* method) ;
// System.Delegate System.Delegate::Remove(System.Delegate,System.Delegate)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Delegate_t* Delegate_Remove_m8B7DD5661308FA972E23CA1CC3FC9CEB355504E3 (Delegate_t* ___source0, Delegate_t* ___value1, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___x0, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___y1, const RuntimeMethod* method) ;
// T UnityEngine.Object::FindObjectOfType<Meta.WitAi.Lib.Mic>()
inline Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* Object_FindObjectOfType_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_m30B96F175E1C053E8EFDFECC85BFF5B790180DCE (const RuntimeMethod* method)
{
	return ((  Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* (*) (const RuntimeMethod*))Object_FindObjectOfType_TisRuntimeObject_m02DFBF011F3B59F777A5E521DB2A116DD496E968_gshared)(method);
}
// System.Boolean UnityEngine.Application::get_isPlaying()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Application_get_isPlaying_m25B0ABDFEF54F5370CD3F263A813540843D00F34 (const RuntimeMethod* method) ;
// System.Void UnityEngine.GameObject::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameObject__ctor_m37D512B05D292F954792225E6C6EEE95293A9B88 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, String_t* ___name0, const RuntimeMethod* method) ;
// T UnityEngine.GameObject::AddComponent<Meta.WitAi.Lib.Mic>()
inline Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* GameObject_AddComponent_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_mEDE89F407EEBE6CD16CDDF8EDE285FFFC92AC40A (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method)
{
	return ((  Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* (*) (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F*, const RuntimeMethod*))GameObject_AddComponent_TisRuntimeObject_m69B93700FACCF372F5753371C6E8FB780800B824_gshared)(__this, method);
}
// UnityEngine.GameObject UnityEngine.Component::get_gameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Object::DontDestroyOnLoad(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_DontDestroyOnLoad_m4B70C3AEF886C176543D1295507B6455C9DCAEA7 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___target0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::StopMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Boolean Meta.WitAi.Lib.Mic::get_IsRecording()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m9E3155FB84015C823606188F53B47CB44C444991 (String_t* ___str00, String_t* ___str11, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.VLog::D(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37 (RuntimeObject* ___log0, const RuntimeMethod* method) ;
// System.Collections.IEnumerator Meta.WitAi.Lib.Mic::ReadRawAudio()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Mic_ReadRawAudio_m2540593A5E20AE8E57046FD08870373B5BEF662E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.Collections.IEnumerator)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* MonoBehaviour_StartCoroutine_m4CAFF732AA28CD3BDC5363B44A863575530EC812 (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, RuntimeObject* ___routine0, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B (String_t* ___str00, String_t* ___str11, String_t* ___str22, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.GameObject::get_activeInHierarchy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool GameObject_get_activeInHierarchy_m49250F4F168DCC5388D5BE4F6A5681386907B109 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method) ;
// System.Boolean System.String::IsNullOrEmpty(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_IsNullOrEmpty_mEA9E3FB005AC28FE02E69FCF95A7B8456192B478 (String_t* ___value0, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___x0, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___y1, const RuntimeMethod* method) ;
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// System.Boolean System.String::Equals(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool String_Equals_m3354EFE6393BED8DD6E18F69BEA131AAADCC622D (String_t* ___a0, String_t* ___b1, const RuntimeMethod* method) ;
// System.Boolean Meta.WitAi.Lib.Mic::MicrophoneIsRecording(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Mic_MicrophoneIsRecording_m7C74D5CD1AB2CD2823F9DE61569918BA7DD1A87E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, String_t* ___device0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::ChangeDevice(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_ChangeDevice_mDDA83C8262DFF0DEFC0D5F580CE899968D6FB23C (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___index0, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.String>::.ctor()
inline void List_1__ctor_mCA8DD57EAC70C2B5923DBB9D5A77CEAC22E7068E (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// System.Void UnityEngine.Profiling.Profiler::BeginSample(System.String)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Profiler_BeginSample_m640E26B682D803CC5DB4EDFDF2F6E83771BF0BE4_inline (String_t* ___name0, const RuntimeMethod* method) ;
// System.String[] Meta.WitAi.Lib.Mic::MicrophoneGetDevices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* Mic_MicrophoneGetDevices_mD7854A2C49C54E334D86D1EB1527CED25DEF7D6E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.String>::AddRange(System.Collections.Generic.IEnumerable`1<T>)
inline void List_1_AddRange_m157DD7AD4D25423F82A21E533BC4686C83770D5E (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* __this, RuntimeObject* ___collection0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*, RuntimeObject*, const RuntimeMethod*))List_1_AddRange_m1F76B300133150E6046C5FED00E88B5DE0A02E17_gshared)(__this, ___collection0, method);
}
// System.Void Meta.WitAi.VLog::W(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void VLog_W_m7943297ED32FD0E92544C324E6793089056A2344 (RuntimeObject* ___log0, const RuntimeMethod* method) ;
// System.String System.String::Format(System.String,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Format_mA8DBB4C2516B9723C5A41E6CB1E2FAF4BBE96DD8 (String_t* ___format0, RuntimeObject* ___arg01, const RuntimeMethod* method) ;
// System.Void UnityEngine.Profiling.Profiler::EndSample()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Profiler_EndSample_m3FCA26738A87C0B8E352533AD48E2A16B047A757 (const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.String>::IndexOf(T)
inline int32_t List_1_IndexOf_m407F5E43ED8B2BD39036693B8F25F363362CE9D4 (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* __this, String_t* ___item0, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*, String_t*, const RuntimeMethod*))List_1_IndexOf_m378F61BA812B79DEE58D86FE8AA9F20E3FC7D85F_gshared)(__this, ___item0, method);
}
// System.Void Meta.WitAi.Lib.Mic::set_CurrentDeviceIndex(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_CurrentDeviceIndex_mBE12F013AA9E4960005FA3E555C91F59EFBAB01E_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::StartMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StartMicrophone_m77A63B3455FBED5488BB40D36D4D6C8C14D43360 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// UnityEngine.AudioClip UnityEngine.Microphone::Start(System.String,System.Boolean,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* Microphone_Start_mDA38C5376D122F27D9DEFD2AE811BAE460F2242E (String_t* ___deviceName0, bool ___loop1, int32_t ___lengthSec2, int32_t ___frequency3, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::set_AudioClip(UnityEngine.AudioClip)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_AudioClip_m669271C92845436644125FE7F2C2772D606FF7BC_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* ___value0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Object::set_name(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_set_name_mC79E6DC8FFD72479C90F0C4CC7F42A0FEAF5AE47 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, String_t* ___value0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Microphone::End(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Microphone_End_mB368877FCC9EA1522914006671E637848A0F7CC6 (String_t* ___deviceName0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Object::Destroy(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___obj0, const RuntimeMethod* method) ;
// System.Boolean Meta.WitAi.Lib.Mic::get_IsInputAvailable()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Mic_get_IsInputAvailable_mB923FAD41282AF61B18414EA4D289352A39CB37B (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::StopRecording()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StopRecording_m8525C6F3D7E02848432DABACC3FCCB901BD1CB28 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::set_IsRecording(System.Boolean)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_IsRecording_m3F0A99CC2B7421CDA82940CD8218F6FB1E82D94D_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, bool ___value0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::set_SampleDurationMS(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_SampleDurationMS_mB651F5378E82541862F643CAC54BDEA43D588AD3_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.AudioClip::get_channels()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AudioClip_get_channels_mFEECF5D6389D196BA5102EB79257298B9FDC9F84 (AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* __this, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic::set_Sample(System.Single[])
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_Sample_m597932121A4B7EE048277235928450EC95AB46C8_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___value0, const RuntimeMethod* method) ;
// System.Int32 Meta.WitAi.Lib.Mic::MicrophoneGetPosition(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_MicrophoneGetPosition_m472553E27CC1DE60E108FBADC80A304D1BB2B652 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, String_t* ___device0, const RuntimeMethod* method) ;
// System.Void System.Action::Invoke()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Action_Invoke_m7126A54DACA72B845424072887B5F3A51FC3808E_inline (Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.MonoBehaviour::StopCoroutine(System.Collections.IEnumerator)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour_StopCoroutine_mF9E93B82091E804595BE13AA29F9AB7517F7E04A (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, RuntimeObject* ___routine0, const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadRawAudioU3Ed__63__ctor_mCA3488763C0B875BF8E98FE5678553313CE266C6 (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Microphone::IsRecording(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Microphone_IsRecording_m93CA54969E12BF2083326E43794D71F0FED5D653 (String_t* ___deviceName0, const RuntimeMethod* method) ;
// System.String[] UnityEngine.Microphone::get_devices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* Microphone_get_devices_mC2821E200C36C599DDC37927DEC9EA725240812D (const RuntimeMethod* method) ;
// System.Void Meta.WitAi.Data.AudioEncoding::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void AudioEncoding__ctor_m3B8B23AA7A25A3069EA907156789A050DA90F28E (AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.MonoBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, const RuntimeMethod* method) ;
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2 (RuntimeObject* __this, const RuntimeMethod* method) ;
// System.Single[] Meta.WitAi.Lib.Mic::get_Sample()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* Mic_get_Sample_m304BDFD016D05421B641CED860E2E1E1404D9CEC_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.AudioClip::get_samples()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AudioClip_get_samples_mDEA01CA75E7DEA0F8D480E4AF97FB96085BCF38E (AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* __this, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.AudioClip::GetData(System.Single[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AudioClip_GetData_m1F6480FFDA2E354A7D8C8DE40F61AAB5AF6B4A1D (AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* __this, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___data0, int32_t ___offsetSamples1, const RuntimeMethod* method) ;
// System.Void System.Action`3<System.Int32,System.Single[],System.Single>::Invoke(T1,T2,T3)
inline void Action_3_Invoke_m210005E412E0E8B43987971844C4FB9D817BFCFB_inline (Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* __this, int32_t ___arg10, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___arg21, float ___arg32, const RuntimeMethod* method)
{
	((  void (*) (Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*, int32_t, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C*, float, const RuntimeMethod*))Action_3_Invoke_mE6726AD48C4B0576C12CD89A49A438E707529E36_gshared_inline)(__this, ___arg10, ___arg21, ___arg32, method);
}
// System.Void System.NotSupportedException::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NotSupportedException__ctor_m1398D0CDE19B36AA3DE9392879738C1EA2439CDF (NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Profiling.Profiler::ValidateArguments(System.String)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Profiler_ValidateArguments_m631DF788CA8A7DF599A5871AF4D7FA8B9C3B52CC_inline (String_t* ___name0, const RuntimeMethod* method) ;
// System.Void UnityEngine.Profiling.Profiler::BeginSampleImpl(System.String,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Profiler_BeginSampleImpl_m7CA0C092A61229CA7BF617E521F2DE0E2B155CEA (String_t* ___name0, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___targetObject1, const RuntimeMethod* method) ;
// System.Void System.ArgumentException::.ctor(System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArgumentException__ctor_m8F9D40CE19D19B698A70F9A258640EB52DB39B62 (ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263* __this, String_t* ___message0, String_t* ___paramName1, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean Meta.WitAi.Lib.Mic::get_IsRecording()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public bool IsRecording { get; private set; }
		bool L_0 = __this->___U3CIsRecordingU3Ek__BackingField_4;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic::set_IsRecording(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_set_IsRecording_m3F0A99CC2B7421CDA82940CD8218F6FB1E82D94D (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, bool ___value0, const RuntimeMethod* method) 
{
	{
		// public bool IsRecording { get; private set; }
		bool L_0 = ___value0;
		__this->___U3CIsRecordingU3Ek__BackingField_4 = L_0;
		return;
	}
}
// Meta.WitAi.Data.AudioEncoding Meta.WitAi.Lib.Mic::get_AudioEncoding()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public AudioEncoding AudioEncoding { get; } = new AudioEncoding();
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_0 = __this->___U3CAudioEncodingU3Ek__BackingField_5;
		return L_0;
	}
}
// System.Single[] Meta.WitAi.Lib.Mic::get_Sample()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* Mic_get_Sample_m304BDFD016D05421B641CED860E2E1E1404D9CEC (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public float[] Sample { get; private set; }
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_0 = __this->___U3CSampleU3Ek__BackingField_6;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic::set_Sample(System.Single[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_set_Sample_m597932121A4B7EE048277235928450EC95AB46C8 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___value0, const RuntimeMethod* method) 
{
	{
		// public float[] Sample { get; private set; }
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_0 = ___value0;
		__this->___U3CSampleU3Ek__BackingField_6 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CSampleU3Ek__BackingField_6), (void*)L_0);
		return;
	}
}
// System.Int32 Meta.WitAi.Lib.Mic::get_SampleDurationMS()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_get_SampleDurationMS_m725B8440FA1DDC9445253977331420E34B115739 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public int SampleDurationMS { get; private set; }
		int32_t L_0 = __this->___U3CSampleDurationMSU3Ek__BackingField_7;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic::set_SampleDurationMS(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_set_SampleDurationMS_mB651F5378E82541862F643CAC54BDEA43D588AD3 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) 
{
	{
		// public int SampleDurationMS { get; private set; }
		int32_t L_0 = ___value0;
		__this->___U3CSampleDurationMSU3Ek__BackingField_7 = L_0;
		return;
	}
}
// System.Boolean Meta.WitAi.Lib.Mic::get_IsInputAvailable()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Mic_get_IsInputAvailable_mB923FAD41282AF61B18414EA4D289352A39CB37B (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	{
		// if (!AudioClip)
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_0;
		L_0 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_1;
		L_1 = Object_op_Implicit_m93896EF7D68FA113C42D3FE2BC6F661FC7EF514A(L_0, NULL);
		V_0 = (bool)((((int32_t)L_1) == ((int32_t)0))? 1 : 0);
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_001c;
		}
	}
	{
		// SafeStartMicrophone();
		Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216(__this, NULL);
	}

IL_001c:
	{
		// return AudioClip;
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_3;
		L_3 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_4;
		L_4 = Object_op_Implicit_m93896EF7D68FA113C42D3FE2BC6F661FC7EF514A(L_3, NULL);
		V_1 = L_4;
		goto IL_002a;
	}

IL_002a:
	{
		// }
		bool L_5 = V_1;
		return L_5;
	}
}
// System.Void Meta.WitAi.Lib.Mic::CheckForInput()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_CheckForInput_mCAC407544753F63B9D6C63C95C54ED543F48BFBC (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public void CheckForInput() => SafeStartMicrophone();
		Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216(__this, NULL);
		return;
	}
}
// System.Int32 Meta.WitAi.Lib.Mic::get_SampleLength()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_get_SampleLength_m32005F78B80430A9BED97E0757F184EF48BECDF7 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		// get { return AudioEncoding.samplerate * SampleDurationMS / 1000; }
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_0;
		L_0 = Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1 = L_0->___samplerate_2;
		int32_t L_2;
		L_2 = Mic_get_SampleDurationMS_m725B8440FA1DDC9445253977331420E34B115739_inline(__this, NULL);
		V_0 = ((int32_t)(((int32_t)il2cpp_codegen_multiply(L_1, L_2))/((int32_t)1000)));
		goto IL_001c;
	}

IL_001c:
	{
		// get { return AudioEncoding.samplerate * SampleDurationMS / 1000; }
		int32_t L_3 = V_0;
		return L_3;
	}
}
// UnityEngine.AudioClip Meta.WitAi.Lib.Mic::get_AudioClip()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public AudioClip AudioClip { get; private set; }
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_0 = __this->___U3CAudioClipU3Ek__BackingField_8;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic::set_AudioClip(UnityEngine.AudioClip)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_set_AudioClip_m669271C92845436644125FE7F2C2772D606FF7BC (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* ___value0, const RuntimeMethod* method) 
{
	{
		// public AudioClip AudioClip { get; private set; }
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_0 = ___value0;
		__this->___U3CAudioClipU3Ek__BackingField_8 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CAudioClipU3Ek__BackingField_8), (void*)L_0);
		return;
	}
}
// System.Collections.Generic.List`1<System.String> Meta.WitAi.Lib.Mic::get_Devices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	bool V_0 = false;
	List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* V_1 = NULL;
	{
		// if (null == _devices)
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_0 = __this->____devices_9;
		V_0 = (bool)((((RuntimeObject*)(List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*)L_0) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0017;
		}
	}
	{
		// RefreshMicDevices();
		Mic_RefreshMicDevices_m132BFED58C51905648DF930AC9CBEBBBADF3BA24(__this, NULL);
	}

IL_0017:
	{
		// return _devices;
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_2 = __this->____devices_9;
		V_1 = L_2;
		goto IL_0020;
	}

IL_0020:
	{
		// }
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_3 = V_1;
		return L_3;
	}
}
// System.Int32 Meta.WitAi.Lib.Mic::get_CurrentDeviceIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public int CurrentDeviceIndex { get; private set; } = -1;
		int32_t L_0 = __this->___U3CCurrentDeviceIndexU3Ek__BackingField_10;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic::set_CurrentDeviceIndex(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_set_CurrentDeviceIndex_mBE12F013AA9E4960005FA3E555C91F59EFBAB01E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) 
{
	{
		// public int CurrentDeviceIndex { get; private set; } = -1;
		int32_t L_0 = ___value0;
		__this->___U3CCurrentDeviceIndexU3Ek__BackingField_10 = L_0;
		return;
	}
}
// System.String Meta.WitAi.Lib.Mic::get_CurrentDeviceName()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m21AEC50E791371101DC22ABCF96A2E46800811F8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&String_t_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	String_t* V_1 = NULL;
	int32_t G_B3_0 = 0;
	{
		// if (CurrentDeviceIndex < 0 || CurrentDeviceIndex >= Devices.Count)
		int32_t L_0;
		L_0 = Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline(__this, NULL);
		if ((((int32_t)L_0) < ((int32_t)0)))
		{
			goto IL_0022;
		}
	}
	{
		int32_t L_1;
		L_1 = Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline(__this, NULL);
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_2;
		L_2 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		NullCheck(L_2);
		int32_t L_3;
		L_3 = List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline(L_2, List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		G_B3_0 = ((((int32_t)((((int32_t)L_1) < ((int32_t)L_3))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_0023;
	}

IL_0022:
	{
		G_B3_0 = 1;
	}

IL_0023:
	{
		V_0 = (bool)G_B3_0;
		bool L_4 = V_0;
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		// return string.Empty;
		String_t* L_5 = ((String_t_StaticFields*)il2cpp_codegen_static_fields_for(String_t_il2cpp_TypeInfo_var))->___Empty_6;
		V_1 = L_5;
		goto IL_0043;
	}

IL_002f:
	{
		// return Devices[CurrentDeviceIndex];
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_6;
		L_6 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		int32_t L_7;
		L_7 = Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline(__this, NULL);
		NullCheck(L_6);
		String_t* L_8;
		L_8 = List_1_get_Item_m21AEC50E791371101DC22ABCF96A2E46800811F8(L_6, L_7, List_1_get_Item_m21AEC50E791371101DC22ABCF96A2E46800811F8_RuntimeMethod_var);
		V_1 = L_8;
		goto IL_0043;
	}

IL_0043:
	{
		// }
		String_t* L_9 = V_1;
		return L_9;
	}
}
// System.Int32 Meta.WitAi.Lib.Mic::get_MicPosition()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_get_MicPosition_m115FC819946710B4E8521679289C36948D6E736E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// int MicPosition => Microphone.GetPosition(CurrentDeviceName);
		String_t* L_0;
		L_0 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		int32_t L_1;
		L_1 = Microphone_GetPosition_m13F4C8EBE8536893D9AD8388B0E5B46D62E6A459(L_0, NULL);
		return L_1;
	}
}
// System.Void Meta.WitAi.Lib.Mic::add_OnStartRecording(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_add_OnStartRecording_mD3DF696C7B330CA46082731CF39F11A6C3793BD3 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStartRecording_12;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Combine_m1F725AEF318BE6F0426863490691A6F4606E7D00(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStartRecording_12);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::remove_OnStartRecording(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_remove_OnStartRecording_m6D0BBFD5146BED6F9411F6438A1AC9CC79F7E826 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStartRecording_12;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Remove_m8B7DD5661308FA972E23CA1CC3FC9CEB355504E3(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStartRecording_12);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::add_OnStartRecordingFailed(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_add_OnStartRecordingFailed_m61E268F404DA0F6106EC509511E7C59F0F7A3ADD (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStartRecordingFailed_13;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Combine_m1F725AEF318BE6F0426863490691A6F4606E7D00(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStartRecordingFailed_13);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::remove_OnStartRecordingFailed(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_remove_OnStartRecordingFailed_m3B345863DCC181EDF31C2B2B00B193A380DED561 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStartRecordingFailed_13;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Remove_m8B7DD5661308FA972E23CA1CC3FC9CEB355504E3(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStartRecordingFailed_13);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::add_OnSampleReady(System.Action`3<System.Int32,System.Single[],System.Single>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_add_OnSampleReady_mB7D8EB67F971422ED6859C20E189076D972F0392 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_0 = NULL;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_1 = NULL;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_2 = NULL;
	{
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_0 = __this->___OnSampleReady_14;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_1 = V_0;
		V_1 = L_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_2 = V_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Combine_m1F725AEF318BE6F0426863490691A6F4606E7D00(L_2, L_3, NULL);
		V_2 = ((Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)Castclass((RuntimeObject*)L_4, Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8_il2cpp_TypeInfo_var));
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8** L_5 = (&__this->___OnSampleReady_14);
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_6 = V_2;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_7 = V_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_9 = V_0;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)L_9) == ((RuntimeObject*)(Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::remove_OnSampleReady(System.Action`3<System.Int32,System.Single[],System.Single>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_remove_OnSampleReady_mD37CCD606D9A9629DF45687430F5E0753BF7A025 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_0 = NULL;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_1 = NULL;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* V_2 = NULL;
	{
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_0 = __this->___OnSampleReady_14;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_1 = V_0;
		V_1 = L_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_2 = V_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Remove_m8B7DD5661308FA972E23CA1CC3FC9CEB355504E3(L_2, L_3, NULL);
		V_2 = ((Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)Castclass((RuntimeObject*)L_4, Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8_il2cpp_TypeInfo_var));
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8** L_5 = (&__this->___OnSampleReady_14);
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_6 = V_2;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_7 = V_1;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_9 = V_0;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)L_9) == ((RuntimeObject*)(Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::add_OnStopRecording(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_add_OnStopRecording_m1112F8AFEC2645C15DF36A9D5B37AFE8575CB2ED (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStopRecording_15;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Combine_m1F725AEF318BE6F0426863490691A6F4606E7D00(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStopRecording_15);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::remove_OnStopRecording(System.Action)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_remove_OnStopRecording_m30A81DE352E60601F5822BB0668BECE251ADEECA (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* ___value0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_0 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_1 = NULL;
	Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* V_2 = NULL;
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_0 = __this->___OnStopRecording_15;
		V_0 = L_0;
	}

IL_0007:
	{
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_1 = V_0;
		V_1 = L_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_2 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_3 = ___value0;
		Delegate_t* L_4;
		L_4 = Delegate_Remove_m8B7DD5661308FA972E23CA1CC3FC9CEB355504E3(L_2, L_3, NULL);
		V_2 = ((Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)CastclassSealed((RuntimeObject*)L_4, Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07_il2cpp_TypeInfo_var));
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07** L_5 = (&__this->___OnStopRecording_15);
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_6 = V_2;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = V_1;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_8;
		L_8 = InterlockedCompareExchangeImpl<Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*>(L_5, L_6, L_7);
		V_0 = L_8;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_9 = V_0;
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_10 = V_1;
		if ((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_9) == ((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// Meta.WitAi.Lib.Mic Meta.WitAi.Lib.Mic::get_Instance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* Mic_get_Instance_mF437723421E54F88E2D9308A3276950E8F2FBD3E (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_AddComponent_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_mEDE89F407EEBE6CD16CDDF8EDE285FFFC92AC40A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_t76FEDD663AB33C991A9C9A23129337651094216F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_FindObjectOfType_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_m30B96F175E1C053E8EFDFECC85BFF5B790180DCE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralC64EEDB786A80FA4B5C8F83347AD5B82F544A7EA);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* V_2 = NULL;
	int32_t G_B5_0 = 0;
	{
		// if (m_Instance == null)
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_0 = ((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_1;
		L_1 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_0, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		V_0 = L_1;
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_001a;
		}
	}
	{
		// m_Instance = GameObject.FindObjectOfType<Mic>();
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_3;
		L_3 = Object_FindObjectOfType_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_m30B96F175E1C053E8EFDFECC85BFF5B790180DCE(Object_FindObjectOfType_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_m30B96F175E1C053E8EFDFECC85BFF5B790180DCE_RuntimeMethod_var);
		((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16 = L_3;
		Il2CppCodeGenWriteBarrier((void**)(&((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16), (void*)L_3);
	}

IL_001a:
	{
		// if (m_Instance == null && Application.isPlaying)
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_4 = ((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_5;
		L_5 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_4, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_5)
		{
			goto IL_002e;
		}
	}
	{
		bool L_6;
		L_6 = Application_get_isPlaying_m25B0ABDFEF54F5370CD3F263A813540843D00F34(NULL);
		G_B5_0 = ((int32_t)(L_6));
		goto IL_002f;
	}

IL_002e:
	{
		G_B5_0 = 0;
	}

IL_002f:
	{
		V_1 = (bool)G_B5_0;
		bool L_7 = V_1;
		if (!L_7)
		{
			goto IL_0059;
		}
	}
	{
		// m_Instance = new GameObject("UniMic.Mic").AddComponent<Mic>();
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_8 = (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F*)il2cpp_codegen_object_new(GameObject_t76FEDD663AB33C991A9C9A23129337651094216F_il2cpp_TypeInfo_var);
		NullCheck(L_8);
		GameObject__ctor_m37D512B05D292F954792225E6C6EEE95293A9B88(L_8, _stringLiteralC64EEDB786A80FA4B5C8F83347AD5B82F544A7EA, NULL);
		NullCheck(L_8);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_9;
		L_9 = GameObject_AddComponent_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_mEDE89F407EEBE6CD16CDDF8EDE285FFFC92AC40A(L_8, GameObject_AddComponent_TisMic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_mEDE89F407EEBE6CD16CDDF8EDE285FFFC92AC40A_RuntimeMethod_var);
		((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16 = L_9;
		Il2CppCodeGenWriteBarrier((void**)(&((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16), (void*)L_9);
		// DontDestroyOnLoad(m_Instance.gameObject);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_10 = ((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16;
		NullCheck(L_10);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_11;
		L_11 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(L_10, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Object_DontDestroyOnLoad_m4B70C3AEF886C176543D1295507B6455C9DCAEA7(L_11, NULL);
	}

IL_0059:
	{
		// return m_Instance;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_12 = ((Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_StaticFields*)il2cpp_codegen_static_fields_for(Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4_il2cpp_TypeInfo_var))->___m_Instance_16;
		V_2 = L_12;
		goto IL_0061;
	}

IL_0061:
	{
		// }
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_13 = V_2;
		return L_13;
	}
}
// System.Void Meta.WitAi.Lib.Mic::OnEnable()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_OnEnable_mF724F3155F70FD4FAA5B6F77E74E51337C6D09D4 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// SafeStartMicrophone();
		Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216(__this, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::OnDisable()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_OnDisable_m7CEDA1D6235A215F8E27705E37B62482354D43EE (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// StopMicrophone();
		Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9(__this, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::OnApplicationFocus(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_OnApplicationFocus_m7A517C88E04301F5CC4587277E7DBECB07D22FCE (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, bool ___hasFocus0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral58BC5A0E2D16839B25D7C05F8A250FA68C1AE016);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral5C2C6219EF9AB59B9DE4705897BA951EAFCFBD15);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral9653A58C4B17007757C99F5A3DD834C1D2E849B0);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	int32_t G_B3_0 = 0;
	{
		// if (hasFocus && IsRecording)
		bool L_0 = ___hasFocus0;
		if (!L_0)
		{
			goto IL_000c;
		}
	}
	{
		bool L_1;
		L_1 = Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214_inline(__this, NULL);
		G_B3_0 = ((int32_t)(L_1));
		goto IL_000d;
	}

IL_000c:
	{
		G_B3_0 = 0;
	}

IL_000d:
	{
		V_0 = (bool)G_B3_0;
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_003f;
		}
	}
	{
		// VLog.D($"Mic was recording and app is resumed, resuming listening on {CurrentDeviceName}");
		String_t* L_3;
		L_3 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_4;
		L_4 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(_stringLiteral9653A58C4B17007757C99F5A3DD834C1D2E849B0, L_3, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_4, NULL);
		// SafeStartMicrophone();
		Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216(__this, NULL);
		// StartCoroutine(ReadRawAudio());
		RuntimeObject* L_5;
		L_5 = Mic_ReadRawAudio_m2540593A5E20AE8E57046FD08870373B5BEF662E(__this, NULL);
		Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* L_6;
		L_6 = MonoBehaviour_StartCoroutine_m4CAFF732AA28CD3BDC5363B44A863575530EC812(__this, L_5, NULL);
		goto IL_006b;
	}

IL_003f:
	{
		// else if (!hasFocus)
		bool L_7 = ___hasFocus0;
		V_1 = (bool)((((int32_t)L_7) == ((int32_t)0))? 1 : 0);
		bool L_8 = V_1;
		if (!L_8)
		{
			goto IL_006b;
		}
	}
	{
		// VLog.D($"Stopping listening on {CurrentDeviceName} due to loss of focus.");
		String_t* L_9;
		L_9 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_10;
		L_10 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral58BC5A0E2D16839B25D7C05F8A250FA68C1AE016, L_9, _stringLiteral5C2C6219EF9AB59B9DE4705897BA951EAFCFBD15, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_10, NULL);
		// StopMicrophone();
		Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9(__this, NULL);
	}

IL_006b:
	{
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::OnApplicationPause(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_OnApplicationPause_mF3A0877291883BAA8CD8AF1B9F0ADDDE521F1D6D (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, bool ___pauseStatus0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral58BC5A0E2D16839B25D7C05F8A250FA68C1AE016);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralA27E50E0D7CA344AD5EAF74DD75F77225C4765E2);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		// if (pauseStatus)
		bool L_0 = ___pauseStatus0;
		V_0 = L_0;
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_002a;
		}
	}
	{
		// VLog.D($"Stopping listening on {CurrentDeviceName} due to application pause.");
		String_t* L_2;
		L_2 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_3;
		L_3 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral58BC5A0E2D16839B25D7C05F8A250FA68C1AE016, L_2, _stringLiteralA27E50E0D7CA344AD5EAF74DD75F77225C4765E2, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_3, NULL);
		// StopMicrophone();
		Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9(__this, NULL);
	}

IL_002a:
	{
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::OnDestroy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_OnDestroy_mE2BC058609EF4B046519B6840E8506EC55DFA7C2 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// StopMicrophone();
		Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9(__this, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::SafeStartMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_SafeStartMicrophone_m8DC643BAB43D2586A1C5F910A9D9F30B36A24216 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	bool V_1 = false;
	bool V_2 = false;
	bool V_3 = false;
	bool V_4 = false;
	int32_t G_B5_0 = 0;
	int32_t G_B9_0 = 0;
	int32_t G_B17_0 = 0;
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* G_B21_0 = NULL;
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* G_B20_0 = NULL;
	int32_t G_B22_0 = 0;
	Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* G_B22_1 = NULL;
	{
		// if (!gameObject.activeInHierarchy)
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_0;
		L_0 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = GameObject_get_activeInHierarchy_m49250F4F168DCC5388D5BE4F6A5681386907B109(L_0, NULL);
		V_1 = (bool)((((int32_t)L_1) == ((int32_t)0))? 1 : 0);
		bool L_2 = V_1;
		if (!L_2)
		{
			goto IL_0019;
		}
	}
	{
		// return;
		goto IL_00bb;
	}

IL_0019:
	{
		// if (Devices == null || Devices.Count == 0)
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_3;
		L_3 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		if (!L_3)
		{
			goto IL_0031;
		}
	}
	{
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_4;
		L_4 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		NullCheck(L_4);
		int32_t L_5;
		L_5 = List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline(L_4, List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		G_B5_0 = ((((int32_t)L_5) == ((int32_t)0))? 1 : 0);
		goto IL_0032;
	}

IL_0031:
	{
		G_B5_0 = 1;
	}

IL_0032:
	{
		V_2 = (bool)G_B5_0;
		bool L_6 = V_2;
		if (!L_6)
		{
			goto IL_005f;
		}
	}
	{
		// RefreshMicDevices();
		Mic_RefreshMicDevices_m132BFED58C51905648DF930AC9CBEBBBADF3BA24(__this, NULL);
		// if (Devices == null || Devices.Count == 0)
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_7;
		L_7 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		if (!L_7)
		{
			goto IL_0056;
		}
	}
	{
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_8;
		L_8 = Mic_get_Devices_m5EB1323E49A3EA4B4038112E79EE7E11CA2599AA(__this, NULL);
		NullCheck(L_8);
		int32_t L_9;
		L_9 = List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline(L_8, List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		G_B9_0 = ((((int32_t)L_9) == ((int32_t)0))? 1 : 0);
		goto IL_0057;
	}

IL_0056:
	{
		G_B9_0 = 1;
	}

IL_0057:
	{
		V_3 = (bool)G_B9_0;
		bool L_10 = V_3;
		if (!L_10)
		{
			goto IL_005e;
		}
	}
	{
		// return;
		goto IL_00bb;
	}

IL_005e:
	{
	}

IL_005f:
	{
		// string micID = CurrentDeviceName;
		String_t* L_11;
		L_11 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		V_0 = L_11;
		// if (!string.IsNullOrEmpty(micID) && AudioClip != null && string.Equals(micID, AudioClip.name) && MicrophoneIsRecording(micID))
		String_t* L_12 = V_0;
		bool L_13;
		L_13 = String_IsNullOrEmpty_mEA9E3FB005AC28FE02E69FCF95A7B8456192B478(L_12, NULL);
		if (L_13)
		{
			goto IL_0098;
		}
	}
	{
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_14;
		L_14 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_15;
		L_15 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_14, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_15)
		{
			goto IL_0098;
		}
	}
	{
		String_t* L_16 = V_0;
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_17;
		L_17 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		NullCheck(L_17);
		String_t* L_18;
		L_18 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_17, NULL);
		bool L_19;
		L_19 = String_Equals_m3354EFE6393BED8DD6E18F69BEA131AAADCC622D(L_16, L_18, NULL);
		if (!L_19)
		{
			goto IL_0098;
		}
	}
	{
		String_t* L_20 = V_0;
		bool L_21;
		L_21 = Mic_MicrophoneIsRecording_m7C74D5CD1AB2CD2823F9DE61569918BA7DD1A87E(__this, L_20, NULL);
		G_B17_0 = ((int32_t)(L_21));
		goto IL_0099;
	}

IL_0098:
	{
		G_B17_0 = 0;
	}

IL_0099:
	{
		V_4 = (bool)G_B17_0;
		bool L_22 = V_4;
		if (!L_22)
		{
			goto IL_00a2;
		}
	}
	{
		// return;
		goto IL_00bb;
	}

IL_00a2:
	{
		// ChangeDevice(CurrentDeviceIndex < 0 ? 0 : CurrentDeviceIndex);
		int32_t L_23;
		L_23 = Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline(__this, NULL);
		G_B20_0 = __this;
		if ((((int32_t)L_23) < ((int32_t)0)))
		{
			G_B21_0 = __this;
			goto IL_00b4;
		}
	}
	{
		int32_t L_24;
		L_24 = Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline(__this, NULL);
		G_B22_0 = L_24;
		G_B22_1 = G_B20_0;
		goto IL_00b5;
	}

IL_00b4:
	{
		G_B22_0 = 0;
		G_B22_1 = G_B21_0;
	}

IL_00b5:
	{
		NullCheck(G_B22_1);
		Mic_ChangeDevice_mDDA83C8262DFF0DEFC0D5F580CE899968D6FB23C(G_B22_1, G_B22_0, NULL);
	}

IL_00bb:
	{
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::RefreshMicDevices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_RefreshMicDevices_m132BFED58C51905648DF930AC9CBEBBBADF3BA24 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_AddRange_m157DD7AD4D25423F82A21E533BC4686C83770D5E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_IndexOf_m407F5E43ED8B2BD39036693B8F25F363362CE9D4_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mCA8DD57EAC70C2B5923DBB9D5A77CEAC22E7068E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral2709CB4BF2E45EF9216A9D5D0AD1EE93A89B7FE0);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE2F929D5515E822FE1F09FC643A45DF3B563BDF8);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralFA4604892145AEA13A6D0A7FB0E52EB5803A160C);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* V_1 = NULL;
	bool V_2 = false;
	bool V_3 = false;
	{
		// string oldDevice = CurrentDeviceName;
		String_t* L_0;
		L_0 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		V_0 = L_0;
		// _devices = new List<string>();
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_1 = (List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD*)il2cpp_codegen_object_new(List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD_il2cpp_TypeInfo_var);
		NullCheck(L_1);
		List_1__ctor_mCA8DD57EAC70C2B5923DBB9D5A77CEAC22E7068E(L_1, List_1__ctor_mCA8DD57EAC70C2B5923DBB9D5A77CEAC22E7068E_RuntimeMethod_var);
		__this->____devices_9 = L_1;
		Il2CppCodeGenWriteBarrier((void**)(&__this->____devices_9), (void*)L_1);
		// UnityEngine.Profiling.Profiler.BeginSample("Microphone Devices");
		Profiler_BeginSample_m640E26B682D803CC5DB4EDFDF2F6E83771BF0BE4_inline(_stringLiteral2709CB4BF2E45EF9216A9D5D0AD1EE93A89B7FE0, NULL);
		// string[] micIDs = MicrophoneGetDevices();
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_2;
		L_2 = Mic_MicrophoneGetDevices_mD7854A2C49C54E334D86D1EB1527CED25DEF7D6E(__this, NULL);
		V_1 = L_2;
		// if (micIDs != null)
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_3 = V_1;
		V_2 = (bool)((!(((RuntimeObject*)(StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248*)L_3) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_4 = V_2;
		if (!L_4)
		{
			goto IL_003c;
		}
	}
	{
		// _devices.AddRange(micIDs);
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_5 = __this->____devices_9;
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_6 = V_1;
		NullCheck(L_5);
		List_1_AddRange_m157DD7AD4D25423F82A21E533BC4686C83770D5E(L_5, (RuntimeObject*)L_6, List_1_AddRange_m157DD7AD4D25423F82A21E533BC4686C83770D5E_RuntimeMethod_var);
	}

IL_003c:
	{
		// if (_devices.Count == 0)
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_7 = __this->____devices_9;
		NullCheck(L_7);
		int32_t L_8;
		L_8 = List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline(L_7, List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		V_3 = (bool)((((int32_t)L_8) == ((int32_t)0))? 1 : 0);
		bool L_9 = V_3;
		if (!L_9)
		{
			goto IL_005d;
		}
	}
	{
		// VLog.W("No mics found");
		VLog_W_m7943297ED32FD0E92544C324E6793089056A2344(_stringLiteralFA4604892145AEA13A6D0A7FB0E52EB5803A160C, NULL);
		goto IL_007f;
	}

IL_005d:
	{
		// VLog.D($"Found {_devices.Count} Mics");
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_10 = __this->____devices_9;
		NullCheck(L_10);
		int32_t L_11;
		L_11 = List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_inline(L_10, List_1_get_Count_mB63183A9151F4345A9DD444A7CBE0D6E03F77C7C_RuntimeMethod_var);
		int32_t L_12 = L_11;
		RuntimeObject* L_13 = Box(Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var, &L_12);
		String_t* L_14;
		L_14 = String_Format_mA8DBB4C2516B9723C5A41E6CB1E2FAF4BBE96DD8(_stringLiteralE2F929D5515E822FE1F09FC643A45DF3B563BDF8, L_13, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_14, NULL);
	}

IL_007f:
	{
		// UnityEngine.Profiling.Profiler.EndSample();
		Profiler_EndSample_m3FCA26738A87C0B8E352533AD48E2A16B047A757(NULL);
		// CurrentDeviceIndex = _devices.IndexOf(oldDevice);
		List_1_tF470A3BE5C1B5B68E1325EF3F109D172E60BD7CD* L_15 = __this->____devices_9;
		String_t* L_16 = V_0;
		NullCheck(L_15);
		int32_t L_17;
		L_17 = List_1_IndexOf_m407F5E43ED8B2BD39036693B8F25F363362CE9D4(L_15, L_16, List_1_IndexOf_m407F5E43ED8B2BD39036693B8F25F363362CE9D4_RuntimeMethod_var);
		Mic_set_CurrentDeviceIndex_mBE12F013AA9E4960005FA3E555C91F59EFBAB01E_inline(__this, L_17, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::ChangeDevice(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_ChangeDevice_mDDA83C8262DFF0DEFC0D5F580CE899968D6FB23C (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___index0, const RuntimeMethod* method) 
{
	{
		// StopMicrophone();
		Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9(__this, NULL);
		// CurrentDeviceIndex = index;
		int32_t L_0 = ___index0;
		Mic_set_CurrentDeviceIndex_mBE12F013AA9E4960005FA3E555C91F59EFBAB01E_inline(__this, L_0, NULL);
		// StartMicrophone();
		Mic_StartMicrophone_m77A63B3455FBED5488BB40D36D4D6C8C14D43360(__this, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::StartMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StartMicrophone_m77A63B3455FBED5488BB40D36D4D6C8C14D43360 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral1790BC7E4E368961EF01213AD7625F9B4441C2B1);
		s_Il2CppMethodInitialized = true;
	}
	{
		// VLog.D("Reserved mic " + CurrentDeviceName);
		String_t* L_0;
		L_0 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_1;
		L_1 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(_stringLiteral1790BC7E4E368961EF01213AD7625F9B4441C2B1, L_0, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_1, NULL);
		// AudioClip = Microphone.Start(CurrentDeviceName, true, 1, AudioEncoding.samplerate);
		String_t* L_2;
		L_2 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_3;
		L_3 = Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54_inline(__this, NULL);
		NullCheck(L_3);
		int32_t L_4 = L_3->___samplerate_2;
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_5;
		L_5 = Microphone_Start_mDA38C5376D122F27D9DEFD2AE811BAE460F2242E(L_2, (bool)1, 1, L_4, NULL);
		Mic_set_AudioClip_m669271C92845436644125FE7F2C2772D606FF7BC_inline(__this, L_5, NULL);
		// AudioClip.name = CurrentDeviceName;
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_6;
		L_6 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		String_t* L_7;
		L_7 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		NullCheck(L_6);
		Object_set_name_mC79E6DC8FFD72479C90F0C4CC7F42A0FEAF5AE47(L_6, L_7, NULL);
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::StopMicrophone()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StopMicrophone_m4EA9741BFBE65E65BC4521513918A56CAC76CCC9 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral8E22AE7C8B8A3D5C7E3553929D697ECBD2DD6053);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	{
		// if (MicrophoneIsRecording(CurrentDeviceName))
		String_t* L_0;
		L_0 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		bool L_1;
		L_1 = Mic_MicrophoneIsRecording_m7C74D5CD1AB2CD2823F9DE61569918BA7DD1A87E(__this, L_0, NULL);
		V_0 = L_1;
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_0035;
		}
	}
	{
		// VLog.D("Released mic " + CurrentDeviceName);
		String_t* L_3;
		L_3 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_4;
		L_4 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(_stringLiteral8E22AE7C8B8A3D5C7E3553929D697ECBD2DD6053, L_3, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_4, NULL);
		// Microphone.End(CurrentDeviceName);
		String_t* L_5;
		L_5 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		Microphone_End_mB368877FCC9EA1522914006671E637848A0F7CC6(L_5, NULL);
	}

IL_0035:
	{
		// if (AudioClip != null)
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_6;
		L_6 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_7;
		L_7 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_6, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		V_1 = L_7;
		bool L_8 = V_1;
		if (!L_8)
		{
			goto IL_005d;
		}
	}
	{
		// Destroy(AudioClip);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_9;
		L_9 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB(L_9, NULL);
		// AudioClip = null;
		Mic_set_AudioClip_m669271C92845436644125FE7F2C2772D606FF7BC_inline(__this, (AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20*)NULL, NULL);
	}

IL_005d:
	{
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::StartRecording(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StartRecording_mA08F543E712CA47B1D92CDB893AC0E635AB852E1 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___sampleLen0, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE85AE323424CD7FD07E8850BE5AF84790EA74328);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	bool V_2 = false;
	{
		// if (!IsInputAvailable)
		bool L_0;
		L_0 = Mic_get_IsInputAvailable_mB923FAD41282AF61B18414EA4D289352A39CB37B(__this, NULL);
		V_0 = (bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0014;
		}
	}
	{
		// return;
		goto IL_00c5;
	}

IL_0014:
	{
		// StopRecording();
		Mic_StopRecording_m8525C6F3D7E02848432DABACC3FCCB901BD1CB28(__this, NULL);
		// IsRecording = true;
		Mic_set_IsRecording_m3F0A99CC2B7421CDA82940CD8218F6FB1E82D94D_inline(__this, (bool)1, NULL);
		// SampleDurationMS = sampleLen;
		int32_t L_2 = ___sampleLen0;
		Mic_set_SampleDurationMS_mB651F5378E82541862F643CAC54BDEA43D588AD3_inline(__this, L_2, NULL);
		// Sample = new float[AudioEncoding.samplerate / 1000 * SampleDurationMS * AudioClip.channels];
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_3;
		L_3 = Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54_inline(__this, NULL);
		NullCheck(L_3);
		int32_t L_4 = L_3->___samplerate_2;
		int32_t L_5;
		L_5 = Mic_get_SampleDurationMS_m725B8440FA1DDC9445253977331420E34B115739_inline(__this, NULL);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_6;
		L_6 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		NullCheck(L_6);
		int32_t L_7;
		L_7 = AudioClip_get_channels_mFEECF5D6389D196BA5102EB79257298B9FDC9F84(L_6, NULL);
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_8 = (SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C*)(SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C*)SZArrayNew(SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C_il2cpp_TypeInfo_var, (uint32_t)((int32_t)il2cpp_codegen_multiply(((int32_t)il2cpp_codegen_multiply(((int32_t)(L_4/((int32_t)1000))), L_5)), L_7)));
		Mic_set_Sample_m597932121A4B7EE048277235928450EC95AB46C8_inline(__this, L_8, NULL);
		// if (AudioClip)
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_9;
		L_9 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_10;
		L_10 = Object_op_Implicit_m93896EF7D68FA113C42D3FE2BC6F661FC7EF514A(L_9, NULL);
		V_1 = L_10;
		bool L_11 = V_1;
		if (!L_11)
		{
			goto IL_00b7;
		}
	}
	{
		// StartCoroutine(ReadRawAudio());
		RuntimeObject* L_12;
		L_12 = Mic_ReadRawAudio_m2540593A5E20AE8E57046FD08870373B5BEF662E(__this, NULL);
		Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* L_13;
		L_13 = MonoBehaviour_StartCoroutine_m4CAFF732AA28CD3BDC5363B44A863575530EC812(__this, L_12, NULL);
		// MicrophoneGetPosition(CurrentDeviceName);
		String_t* L_14;
		L_14 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		int32_t L_15;
		L_15 = Mic_MicrophoneGetPosition_m472553E27CC1DE60E108FBADC80A304D1BB2B652(__this, L_14, NULL);
		// VLog.D("Started recording with " + CurrentDeviceName);
		String_t* L_16;
		L_16 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_17;
		L_17 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(_stringLiteralE85AE323424CD7FD07E8850BE5AF84790EA74328, L_16, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_17, NULL);
		// if (OnStartRecording != null)
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_18 = __this->___OnStartRecording_12;
		V_2 = (bool)((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_18) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_19 = V_2;
		if (!L_19)
		{
			goto IL_00b4;
		}
	}
	{
		// OnStartRecording.Invoke();
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_20 = __this->___OnStartRecording_12;
		NullCheck(L_20);
		Action_Invoke_m7126A54DACA72B845424072887B5F3A51FC3808E_inline(L_20, NULL);
	}

IL_00b4:
	{
		goto IL_00c5;
	}

IL_00b7:
	{
		// OnStartRecordingFailed.Invoke();
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_21 = __this->___OnStartRecordingFailed_13;
		NullCheck(L_21);
		Action_Invoke_m7126A54DACA72B845424072887B5F3A51FC3808E_inline(L_21, NULL);
	}

IL_00c5:
	{
		// }
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic::StopRecording()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic_StopRecording_m8525C6F3D7E02848432DABACC3FCCB901BD1CB28 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralA055516D7CAA2F33278EED3418825E4D7F00D098);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	bool V_1 = false;
	{
		// if (!IsRecording) return;
		bool L_0;
		L_0 = Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214_inline(__this, NULL);
		V_0 = (bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		// if (!IsRecording) return;
		goto IL_0054;
	}

IL_0010:
	{
		// IsRecording = false;
		Mic_set_IsRecording_m3F0A99CC2B7421CDA82940CD8218F6FB1E82D94D_inline(__this, (bool)0, NULL);
		// StopCoroutine(ReadRawAudio());
		RuntimeObject* L_2;
		L_2 = Mic_ReadRawAudio_m2540593A5E20AE8E57046FD08870373B5BEF662E(__this, NULL);
		MonoBehaviour_StopCoroutine_mF9E93B82091E804595BE13AA29F9AB7517F7E04A(__this, L_2, NULL);
		// VLog.D("Stopped recording with " + CurrentDeviceName);
		String_t* L_3;
		L_3 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(__this, NULL);
		String_t* L_4;
		L_4 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(_stringLiteralA055516D7CAA2F33278EED3418825E4D7F00D098, L_3, NULL);
		VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37(L_4, NULL);
		// if (OnStopRecording != null)
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_5 = __this->___OnStopRecording_15;
		V_1 = (bool)((!(((RuntimeObject*)(Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07*)L_5) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_6 = V_1;
		if (!L_6)
		{
			goto IL_0054;
		}
	}
	{
		// OnStopRecording.Invoke();
		Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* L_7 = __this->___OnStopRecording_15;
		NullCheck(L_7);
		Action_Invoke_m7126A54DACA72B845424072887B5F3A51FC3808E_inline(L_7, NULL);
	}

IL_0054:
	{
		// }
		return;
	}
}
// System.Collections.IEnumerator Meta.WitAi.Lib.Mic::ReadRawAudio()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Mic_ReadRawAudio_m2540593A5E20AE8E57046FD08870373B5BEF662E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* L_0 = (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06*)il2cpp_codegen_object_new(U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CReadRawAudioU3Ed__63__ctor_mCA3488763C0B875BF8E98FE5678553313CE266C6(L_0, 0, NULL);
		U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* L_1 = L_0;
		NullCheck(L_1);
		L_1->___U3CU3E4__this_2 = __this;
		Il2CppCodeGenWriteBarrier((void**)(&L_1->___U3CU3E4__this_2), (void*)__this);
		return L_1;
	}
}
// System.Boolean Meta.WitAi.Lib.Mic::MicrophoneIsRecording(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Mic_MicrophoneIsRecording_m7C74D5CD1AB2CD2823F9DE61569918BA7DD1A87E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, String_t* ___device0, const RuntimeMethod* method) 
{
	bool V_0 = false;
	{
		// return Microphone.IsRecording(device);
		String_t* L_0 = ___device0;
		bool L_1;
		L_1 = Microphone_IsRecording_m93CA54969E12BF2083326E43794D71F0FED5D653(L_0, NULL);
		V_0 = L_1;
		goto IL_000a;
	}

IL_000a:
	{
		// }
		bool L_2 = V_0;
		return L_2;
	}
}
// System.String[] Meta.WitAi.Lib.Mic::MicrophoneGetDevices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* Mic_MicrophoneGetDevices_mD7854A2C49C54E334D86D1EB1527CED25DEF7D6E (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* V_0 = NULL;
	{
		// return Microphone.devices;
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_0;
		L_0 = Microphone_get_devices_mC2821E200C36C599DDC37927DEC9EA725240812D(NULL);
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		// }
		StringU5BU5D_t7674CD946EC0CE7B3AE0BE70E6EE85F2ECD9F248* L_1 = V_0;
		return L_1;
	}
}
// System.Int32 Meta.WitAi.Lib.Mic::MicrophoneGetPosition(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Mic_MicrophoneGetPosition_m472553E27CC1DE60E108FBADC80A304D1BB2B652 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, String_t* ___device0, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		// return Microphone.GetPosition(device);
		String_t* L_0 = ___device0;
		int32_t L_1;
		L_1 = Microphone_GetPosition_m13F4C8EBE8536893D9AD8388B0E5B46D62E6A459(L_0, NULL);
		V_0 = L_1;
		goto IL_000a;
	}

IL_000a:
	{
		// }
		int32_t L_2 = V_0;
		return L_2;
	}
}
// System.Void Meta.WitAi.Lib.Mic::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Mic__ctor_m43EC686B38CDE093B94D0AD1AA5F2F592D96CA75 (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public AudioEncoding AudioEncoding { get; } = new AudioEncoding();
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_0 = (AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4*)il2cpp_codegen_object_new(AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		AudioEncoding__ctor_m3B8B23AA7A25A3069EA907156789A050DA90F28E(L_0, NULL);
		__this->___U3CAudioEncodingU3Ek__BackingField_5 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CAudioEncodingU3Ek__BackingField_5), (void*)L_0);
		// public int CurrentDeviceIndex { get; private set; } = -1;
		__this->___U3CCurrentDeviceIndexU3Ek__BackingField_10 = (-1);
		// int m_SampleCount = 0;
		__this->___m_SampleCount_11 = 0;
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadRawAudioU3Ed__63__ctor_mCA3488763C0B875BF8E98FE5678553313CE266C6 (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, int32_t ___U3CU3E1__state0, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		int32_t L_0 = ___U3CU3E1__state0;
		__this->___U3CU3E1__state_0 = L_0;
		return;
	}
}
// System.Void Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadRawAudioU3Ed__63_System_IDisposable_Dispose_m194E7E49BEF74B4BDBD1AA409B7F9D21156EFACD (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, const RuntimeMethod* method) 
{
	{
		return;
	}
}
// System.Boolean Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CReadRawAudioU3Ed__63_MoveNext_m512827C082DB4A11F1AD915AAD9D484D6D38A7B7 (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	bool V_1 = false;
	int32_t V_2 = 0;
	bool V_3 = false;
	bool V_4 = false;
	bool V_5 = false;
	bool V_6 = false;
	bool V_7 = false;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* G_B19_0 = NULL;
	Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* G_B18_0 = NULL;
	int32_t G_B26_0 = 0;
	int32_t G_B33_0 = 0;
	{
		int32_t L_0 = __this->___U3CU3E1__state_0;
		V_0 = L_0;
		int32_t L_1 = V_0;
		if (!L_1)
		{
			goto IL_0012;
		}
	}
	{
		goto IL_000c;
	}

IL_000c:
	{
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) == ((int32_t)1)))
		{
			goto IL_0014;
		}
	}
	{
		goto IL_0019;
	}

IL_0012:
	{
		goto IL_001b;
	}

IL_0014:
	{
		goto IL_0272;
	}

IL_0019:
	{
		return (bool)0;
	}

IL_001b:
	{
		__this->___U3CU3E1__state_0 = (-1);
		// int loops = 0;
		__this->___U3CloopsU3E5__1_3 = 0;
		// int readAbsPos = MicrophoneGetPosition(CurrentDeviceName);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_3 = __this->___U3CU3E4__this_2;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_4 = __this->___U3CU3E4__this_2;
		NullCheck(L_4);
		String_t* L_5;
		L_5 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(L_4, NULL);
		NullCheck(L_3);
		int32_t L_6;
		L_6 = Mic_MicrophoneGetPosition_m472553E27CC1DE60E108FBADC80A304D1BB2B652(L_3, L_5, NULL);
		__this->___U3CreadAbsPosU3E5__2_4 = L_6;
		// int prevPos = readAbsPos;
		int32_t L_7 = __this->___U3CreadAbsPosU3E5__2_4;
		__this->___U3CprevPosU3E5__3_5 = L_7;
		// float[] temp = new float[Sample.Length];
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_8 = __this->___U3CU3E4__this_2;
		NullCheck(L_8);
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_9;
		L_9 = Mic_get_Sample_m304BDFD016D05421B641CED860E2E1E1404D9CEC_inline(L_8, NULL);
		NullCheck(L_9);
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_10 = (SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C*)(SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C*)SZArrayNew(SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C_il2cpp_TypeInfo_var, (uint32_t)((int32_t)(((RuntimeArray*)L_9)->max_length)));
		__this->___U3CtempU3E5__4_6 = L_10;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CtempU3E5__4_6), (void*)L_10);
		goto IL_027a;
	}

IL_006f:
	{
		// bool isNewDataAvailable = true;
		__this->___U3CisNewDataAvailableU3E5__5_7 = (bool)1;
		goto IL_023e;
	}

IL_007c:
	{
		// int currPos = MicrophoneGetPosition(CurrentDeviceName);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_11 = __this->___U3CU3E4__this_2;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_12 = __this->___U3CU3E4__this_2;
		NullCheck(L_12);
		String_t* L_13;
		L_13 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(L_12, NULL);
		NullCheck(L_11);
		int32_t L_14;
		L_14 = Mic_MicrophoneGetPosition_m472553E27CC1DE60E108FBADC80A304D1BB2B652(L_11, L_13, NULL);
		__this->___U3CcurrPosU3E5__6_8 = L_14;
		// if (currPos < prevPos)
		int32_t L_15 = __this->___U3CcurrPosU3E5__6_8;
		int32_t L_16 = __this->___U3CprevPosU3E5__3_5;
		V_1 = (bool)((((int32_t)L_15) < ((int32_t)L_16))? 1 : 0);
		bool L_17 = V_1;
		if (!L_17)
		{
			goto IL_00bb;
		}
	}
	{
		// loops++;
		int32_t L_18 = __this->___U3CloopsU3E5__1_3;
		V_2 = L_18;
		int32_t L_19 = V_2;
		__this->___U3CloopsU3E5__1_3 = ((int32_t)il2cpp_codegen_add(L_19, 1));
	}

IL_00bb:
	{
		// prevPos = currPos;
		int32_t L_20 = __this->___U3CcurrPosU3E5__6_8;
		__this->___U3CprevPosU3E5__3_5 = L_20;
		// var currAbsPos = loops * AudioClip.samples + currPos;
		int32_t L_21 = __this->___U3CloopsU3E5__1_3;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_22 = __this->___U3CU3E4__this_2;
		NullCheck(L_22);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_23;
		L_23 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(L_22, NULL);
		NullCheck(L_23);
		int32_t L_24;
		L_24 = AudioClip_get_samples_mDEA01CA75E7DEA0F8D480E4AF97FB96085BCF38E(L_23, NULL);
		int32_t L_25 = __this->___U3CcurrPosU3E5__6_8;
		__this->___U3CcurrAbsPosU3E5__7_9 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(L_21, L_24)), L_25));
		// var nextReadAbsPos = readAbsPos + temp.Length;
		int32_t L_26 = __this->___U3CreadAbsPosU3E5__2_4;
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_27 = __this->___U3CtempU3E5__4_6;
		NullCheck(L_27);
		__this->___U3CnextReadAbsPosU3E5__8_10 = ((int32_t)il2cpp_codegen_add(L_26, ((int32_t)(((RuntimeArray*)L_27)->max_length))));
		// float levelMax = 0;
		__this->___U3ClevelMaxU3E5__9_11 = (0.0f);
		// if (nextReadAbsPos < currAbsPos)
		int32_t L_28 = __this->___U3CnextReadAbsPosU3E5__8_10;
		int32_t L_29 = __this->___U3CcurrAbsPosU3E5__7_9;
		V_3 = (bool)((((int32_t)L_28) < ((int32_t)L_29))? 1 : 0);
		bool L_30 = V_3;
		if (!L_30)
		{
			goto IL_0236;
		}
	}
	{
		// AudioClip.GetData(temp, readAbsPos % AudioClip.samples);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_31 = __this->___U3CU3E4__this_2;
		NullCheck(L_31);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_32;
		L_32 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(L_31, NULL);
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_33 = __this->___U3CtempU3E5__4_6;
		int32_t L_34 = __this->___U3CreadAbsPosU3E5__2_4;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_35 = __this->___U3CU3E4__this_2;
		NullCheck(L_35);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_36;
		L_36 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(L_35, NULL);
		NullCheck(L_36);
		int32_t L_37;
		L_37 = AudioClip_get_samples_mDEA01CA75E7DEA0F8D480E4AF97FB96085BCF38E(L_36, NULL);
		NullCheck(L_32);
		bool L_38;
		L_38 = AudioClip_GetData_m1F6480FFDA2E354A7D8C8DE40F61AAB5AF6B4A1D(L_32, L_33, ((int32_t)(L_34%L_37)), NULL);
		// for (int i = 0; i < temp.Length; i++)
		__this->___U3CiU3E5__10_12 = 0;
		goto IL_01ad;
	}

IL_0158:
	{
		// float wavePeak = temp[i] * temp[i];
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_39 = __this->___U3CtempU3E5__4_6;
		int32_t L_40 = __this->___U3CiU3E5__10_12;
		NullCheck(L_39);
		int32_t L_41 = L_40;
		float L_42 = (L_39)->GetAt(static_cast<il2cpp_array_size_t>(L_41));
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_43 = __this->___U3CtempU3E5__4_6;
		int32_t L_44 = __this->___U3CiU3E5__10_12;
		NullCheck(L_43);
		int32_t L_45 = L_44;
		float L_46 = (L_43)->GetAt(static_cast<il2cpp_array_size_t>(L_45));
		__this->___U3CwavePeakU3E5__11_13 = ((float)il2cpp_codegen_multiply(L_42, L_46));
		// if (levelMax < wavePeak)
		float L_47 = __this->___U3ClevelMaxU3E5__9_11;
		float L_48 = __this->___U3CwavePeakU3E5__11_13;
		V_4 = (bool)((((float)L_47) < ((float)L_48))? 1 : 0);
		bool L_49 = V_4;
		if (!L_49)
		{
			goto IL_019c;
		}
	}
	{
		// levelMax = wavePeak;
		float L_50 = __this->___U3CwavePeakU3E5__11_13;
		__this->___U3ClevelMaxU3E5__9_11 = L_50;
	}

IL_019c:
	{
		// for (int i = 0; i < temp.Length; i++)
		int32_t L_51 = __this->___U3CiU3E5__10_12;
		V_2 = L_51;
		int32_t L_52 = V_2;
		__this->___U3CiU3E5__10_12 = ((int32_t)il2cpp_codegen_add(L_52, 1));
	}

IL_01ad:
	{
		// for (int i = 0; i < temp.Length; i++)
		int32_t L_53 = __this->___U3CiU3E5__10_12;
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_54 = __this->___U3CtempU3E5__4_6;
		NullCheck(L_54);
		V_5 = (bool)((((int32_t)L_53) < ((int32_t)((int32_t)(((RuntimeArray*)L_54)->max_length))))? 1 : 0);
		bool L_55 = V_5;
		if (L_55)
		{
			goto IL_0158;
		}
	}
	{
		// Sample = temp;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_56 = __this->___U3CU3E4__this_2;
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_57 = __this->___U3CtempU3E5__4_6;
		NullCheck(L_56);
		Mic_set_Sample_m597932121A4B7EE048277235928450EC95AB46C8_inline(L_56, L_57, NULL);
		// m_SampleCount++;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_58 = __this->___U3CU3E4__this_2;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_59 = __this->___U3CU3E4__this_2;
		NullCheck(L_59);
		int32_t L_60 = L_59->___m_SampleCount_11;
		NullCheck(L_58);
		L_58->___m_SampleCount_11 = ((int32_t)il2cpp_codegen_add(L_60, 1));
		// OnSampleReady?.Invoke(m_SampleCount, Sample, levelMax);
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_61 = __this->___U3CU3E4__this_2;
		NullCheck(L_61);
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_62 = L_61->___OnSampleReady_14;
		Action_3_t014775F97068AFC7018FE805CA856B7C5CF281F8* L_63 = L_62;
		G_B18_0 = L_63;
		if (L_63)
		{
			G_B19_0 = L_63;
			goto IL_01fe;
		}
	}
	{
		goto IL_0220;
	}

IL_01fe:
	{
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_64 = __this->___U3CU3E4__this_2;
		NullCheck(L_64);
		int32_t L_65 = L_64->___m_SampleCount_11;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_66 = __this->___U3CU3E4__this_2;
		NullCheck(L_66);
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_67;
		L_67 = Mic_get_Sample_m304BDFD016D05421B641CED860E2E1E1404D9CEC_inline(L_66, NULL);
		float L_68 = __this->___U3ClevelMaxU3E5__9_11;
		NullCheck(G_B19_0);
		Action_3_Invoke_m210005E412E0E8B43987971844C4FB9D817BFCFB_inline(G_B19_0, L_65, L_67, L_68, NULL);
	}

IL_0220:
	{
		// readAbsPos = nextReadAbsPos;
		int32_t L_69 = __this->___U3CnextReadAbsPosU3E5__8_10;
		__this->___U3CreadAbsPosU3E5__2_4 = L_69;
		// isNewDataAvailable = true;
		__this->___U3CisNewDataAvailableU3E5__5_7 = (bool)1;
		goto IL_023d;
	}

IL_0236:
	{
		// isNewDataAvailable = false;
		__this->___U3CisNewDataAvailableU3E5__5_7 = (bool)0;
	}

IL_023d:
	{
	}

IL_023e:
	{
		// while (isNewDataAvailable && AudioClip)
		bool L_70 = __this->___U3CisNewDataAvailableU3E5__5_7;
		if (!L_70)
		{
			goto IL_0258;
		}
	}
	{
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_71 = __this->___U3CU3E4__this_2;
		NullCheck(L_71);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_72;
		L_72 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(L_71, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_73;
		L_73 = Object_op_Implicit_m93896EF7D68FA113C42D3FE2BC6F661FC7EF514A(L_72, NULL);
		G_B26_0 = ((int32_t)(L_73));
		goto IL_0259;
	}

IL_0258:
	{
		G_B26_0 = 0;
	}

IL_0259:
	{
		V_6 = (bool)G_B26_0;
		bool L_74 = V_6;
		if (L_74)
		{
			goto IL_007c;
		}
	}
	{
		// yield return null;
		__this->___U3CU3E2__current_1 = NULL;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CU3E2__current_1), (void*)NULL);
		__this->___U3CU3E1__state_0 = 1;
		return (bool)1;
	}

IL_0272:
	{
		__this->___U3CU3E1__state_0 = (-1);
	}

IL_027a:
	{
		// while (AudioClip != null && MicrophoneIsRecording(CurrentDeviceName) && IsRecording)
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_75 = __this->___U3CU3E4__this_2;
		NullCheck(L_75);
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_76;
		L_76 = Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline(L_75, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_77;
		L_77 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_76, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_77)
		{
			goto IL_02b2;
		}
	}
	{
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_78 = __this->___U3CU3E4__this_2;
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_79 = __this->___U3CU3E4__this_2;
		NullCheck(L_79);
		String_t* L_80;
		L_80 = Mic_get_CurrentDeviceName_m0C4E300B4CC13A635903C60622DB6F291F299C91(L_79, NULL);
		NullCheck(L_78);
		bool L_81;
		L_81 = Mic_MicrophoneIsRecording_m7C74D5CD1AB2CD2823F9DE61569918BA7DD1A87E(L_78, L_80, NULL);
		if (!L_81)
		{
			goto IL_02b2;
		}
	}
	{
		Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* L_82 = __this->___U3CU3E4__this_2;
		NullCheck(L_82);
		bool L_83;
		L_83 = Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214_inline(L_82, NULL);
		G_B33_0 = ((int32_t)(L_83));
		goto IL_02b3;
	}

IL_02b2:
	{
		G_B33_0 = 0;
	}

IL_02b3:
	{
		V_7 = (bool)G_B33_0;
		bool L_84 = V_7;
		if (L_84)
		{
			goto IL_006f;
		}
	}
	{
		// }
		return (bool)0;
	}
}
// System.Object Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CReadRawAudioU3Ed__63_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE2ACCCBBF00EA98D3A21C4538F0B1C4B69E5F0D0 (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
// System.Void Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CReadRawAudioU3Ed__63_System_Collections_IEnumerator_Reset_mE39146B37BAA48B306DCD9958270B6BA192FF67D (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, const RuntimeMethod* method) 
{
	{
		NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A* L_0 = (NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A_il2cpp_TypeInfo_var)));
		NullCheck(L_0);
		NotSupportedException__ctor_m1398D0CDE19B36AA3DE9392879738C1EA2439CDF(L_0, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CReadRawAudioU3Ed__63_System_Collections_IEnumerator_Reset_mE39146B37BAA48B306DCD9958270B6BA192FF67D_RuntimeMethod_var)));
	}
}
// System.Object Meta.WitAi.Lib.Mic/<ReadRawAudio>d__63::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CReadRawAudioU3Ed__63_System_Collections_IEnumerator_get_Current_m6F144816BF4D7BD47B5273B04985C4CFA86A18F2 (U3CReadRawAudioU3Ed__63_tCF89D7015658AD3E369EC1364A34A7CDF8C09E06* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* Mic_get_AudioClip_m05C846895337110DAB56C5D893468B9644469954_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public AudioClip AudioClip { get; private set; }
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_0 = __this->___U3CAudioClipU3Ek__BackingField_8;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* Mic_get_AudioEncoding_m69605D36C27DAB534629ABBF207A9225CDE68A54_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public AudioEncoding AudioEncoding { get; } = new AudioEncoding();
		AudioEncoding_t98ED2D092A9829C604C73C3B611E2FC987413EE4* L_0 = __this->___U3CAudioEncodingU3Ek__BackingField_5;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mic_get_SampleDurationMS_m725B8440FA1DDC9445253977331420E34B115739_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public int SampleDurationMS { get; private set; }
		int32_t L_0 = __this->___U3CSampleDurationMSU3Ek__BackingField_7;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mic_get_CurrentDeviceIndex_m7E82A371F1F57ED87300016E630814060A1C040C_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public int CurrentDeviceIndex { get; private set; } = -1;
		int32_t L_0 = __this->___U3CCurrentDeviceIndexU3Ek__BackingField_10;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Mic_get_IsRecording_mF29DD9F4AC9C77F327D7EF0699390F8FB675E214_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public bool IsRecording { get; private set; }
		bool L_0 = __this->___U3CIsRecordingU3Ek__BackingField_4;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Profiler_BeginSample_m640E26B682D803CC5DB4EDFDF2F6E83771BF0BE4_inline (String_t* ___name0, const RuntimeMethod* method) 
{
	{
		String_t* L_0 = ___name0;
		Profiler_ValidateArguments_m631DF788CA8A7DF599A5871AF4D7FA8B9C3B52CC_inline(L_0, NULL);
		String_t* L_1 = ___name0;
		Profiler_BeginSampleImpl_m7CA0C092A61229CA7BF617E521F2DE0E2B155CEA(L_1, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_CurrentDeviceIndex_mBE12F013AA9E4960005FA3E555C91F59EFBAB01E_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) 
{
	{
		// public int CurrentDeviceIndex { get; private set; } = -1;
		int32_t L_0 = ___value0;
		__this->___U3CCurrentDeviceIndexU3Ek__BackingField_10 = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_AudioClip_m669271C92845436644125FE7F2C2772D606FF7BC_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* ___value0, const RuntimeMethod* method) 
{
	{
		// public AudioClip AudioClip { get; private set; }
		AudioClip_t5D272C4EB4F2D3ED49F1C346DEA373CF6D585F20* L_0 = ___value0;
		__this->___U3CAudioClipU3Ek__BackingField_8 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CAudioClipU3Ek__BackingField_8), (void*)L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_IsRecording_m3F0A99CC2B7421CDA82940CD8218F6FB1E82D94D_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, bool ___value0, const RuntimeMethod* method) 
{
	{
		// public bool IsRecording { get; private set; }
		bool L_0 = ___value0;
		__this->___U3CIsRecordingU3Ek__BackingField_4 = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_SampleDurationMS_mB651F5378E82541862F643CAC54BDEA43D588AD3_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, int32_t ___value0, const RuntimeMethod* method) 
{
	{
		// public int SampleDurationMS { get; private set; }
		int32_t L_0 = ___value0;
		__this->___U3CSampleDurationMSU3Ek__BackingField_7 = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Mic_set_Sample_m597932121A4B7EE048277235928450EC95AB46C8_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___value0, const RuntimeMethod* method) 
{
	{
		// public float[] Sample { get; private set; }
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_0 = ___value0;
		__this->___U3CSampleU3Ek__BackingField_6 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CSampleU3Ek__BackingField_6), (void*)L_0);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Action_Invoke_m7126A54DACA72B845424072887B5F3A51FC3808E_inline (Action_tD00B0A84D7945E50C2DFFC28EFEE6ED44ED2AD07* __this, const RuntimeMethod* method) 
{
	typedef void (*FunctionPointerType) (RuntimeObject*, const RuntimeMethod*);
	((FunctionPointerType)__this->___invoke_impl_1)((Il2CppObject*)__this->___method_code_6, reinterpret_cast<RuntimeMethod*>(__this->___method_3));
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* Mic_get_Sample_m304BDFD016D05421B641CED860E2E1E1404D9CEC_inline (Mic_t754EFE9D630FC1FBB701EB317849C522C0F384F4* __this, const RuntimeMethod* method) 
{
	{
		// public float[] Sample { get; private set; }
		SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* L_0 = __this->___U3CSampleU3Ek__BackingField_6;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = (int32_t)__this->____size_2;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Action_3_Invoke_mE6726AD48C4B0576C12CD89A49A438E707529E36_gshared_inline (Action_3_t041F9EB77535247CDCF010C1F285CCCEFE9E2F04* __this, int32_t ___arg10, RuntimeObject* ___arg21, float ___arg32, const RuntimeMethod* method) 
{
	typedef void (*FunctionPointerType) (RuntimeObject*, int32_t, RuntimeObject*, float, const RuntimeMethod*);
	((FunctionPointerType)__this->___invoke_impl_1)((Il2CppObject*)__this->___method_code_6, ___arg10, ___arg21, ___arg32, reinterpret_cast<RuntimeMethod*>(__this->___method_3));
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Profiler_ValidateArguments_m631DF788CA8A7DF599A5871AF4D7FA8B9C3B52CC_inline (String_t* ___name0, const RuntimeMethod* method) 
{
	bool V_0 = false;
	{
		String_t* L_0 = ___name0;
		bool L_1;
		L_1 = String_IsNullOrEmpty_mEA9E3FB005AC28FE02E69FCF95A7B8456192B478(L_0, NULL);
		V_0 = L_1;
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_001c;
		}
	}
	{
		ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263* L_3 = (ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&ArgumentException_tAD90411542A20A9C72D5CDA3A84181D8B947A263_il2cpp_TypeInfo_var)));
		NullCheck(L_3);
		ArgumentException__ctor_m8F9D40CE19D19B698A70F9A258640EB52DB39B62(L_3, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral31D159E683556C06B3B3963D92483B6867EB3233)), ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteralCE18B047107AA23D1AA9B2ED32D316148E02655F)), NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Profiler_ValidateArguments_m631DF788CA8A7DF599A5871AF4D7FA8B9C3B52CC_RuntimeMethod_var)));
	}

IL_001c:
	{
		return;
	}
}
