﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Oculus.Voice.Core.Utilities.ArrayElementTitleAttribute::.ctor(System.String,System.String)
extern void ArrayElementTitleAttribute__ctor_m7990542BCC882B8960A3B61CCAAD6D3024438B52 (void);
// 0x00000002 System.DateTime Oculus.Voice.Core.Utilities.DateTimeUtility::get_UtcNow()
extern void DateTimeUtility_get_UtcNow_m45B39BA40DBE9DB6D4E96FA5C71A4AE49D6F71E2 (void);
// 0x00000003 System.Int64 Oculus.Voice.Core.Utilities.DateTimeUtility::get_ElapsedMilliseconds()
extern void DateTimeUtility_get_ElapsedMilliseconds_mFCCD79CB27652B45BB76D679824C381809226602 (void);
// 0x00000004 System.Void Oculus.Voice.Core.Utilities.DateTimeUtility::.ctor()
extern void DateTimeUtility__ctor_m13105FFC88652B794CAFB4919D2B999178A6C946 (void);
// 0x00000005 System.Void Oculus.Voice.Core.Bindings.Interfaces.IConnection::Connect(System.String)
// 0x00000006 System.Void Oculus.Voice.Core.Bindings.Interfaces.IConnection::Disconnect()
// 0x00000007 System.Boolean Oculus.Voice.Core.Bindings.Interfaces.IConnection::get_IsConnected()
// 0x00000008 System.Boolean Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::get_IsUsingPlatformIntegration()
// 0x00000009 System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::set_IsUsingPlatformIntegration(System.Boolean)
// 0x0000000A System.Boolean Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::get_ShouldLogToConsole()
// 0x0000000B System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::set_ShouldLogToConsole(System.Boolean)
// 0x0000000C System.String Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::get_WitApplication()
// 0x0000000D System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::set_WitApplication(System.String)
// 0x0000000E System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::LogInteractionStart(System.String,System.String)
// 0x0000000F System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::LogInteractionEndSuccess()
// 0x00000010 System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::LogInteractionEndFailure(System.String)
// 0x00000011 System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::LogInteractionPoint(System.String)
// 0x00000012 System.Void Oculus.Voice.Core.Bindings.Interfaces.IVoiceSDKLogger::LogAnnotation(System.String,System.String)
// 0x00000013 System.Boolean Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::get_IsConnected()
extern void AndroidServiceConnection_get_IsConnected_m87FF953B8004D62BAC41D5057E6C1F2E6C87B38C (void);
// 0x00000014 UnityEngine.AndroidJavaObject Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::get_AssistantServiceConnection()
extern void AndroidServiceConnection_get_AssistantServiceConnection_m7CB9FD77AC661424EEEC2258CD62EAB2EE98C6FC (void);
// 0x00000015 System.Void Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::.ctor(System.String,System.String)
extern void AndroidServiceConnection__ctor_m5A0B7A0B00C1B3958A6E6456813F4DC174F87183 (void);
// 0x00000016 System.Void Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::Connect(System.String)
extern void AndroidServiceConnection_Connect_m72A36FAF67CE01E6B4579F4CF6174497D7149449 (void);
// 0x00000017 System.Void Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::Disconnect()
extern void AndroidServiceConnection_Disconnect_m6793307BEC56F3840BEE62436171D42C7036A8B5 (void);
// 0x00000018 UnityEngine.AndroidJavaObject Oculus.Voice.Core.Bindings.Android.AndroidServiceConnection::GetService()
extern void AndroidServiceConnection_GetService_m10C8E3DC881909650EFBFFDC577236CEDDF11860 (void);
// 0x00000019 System.Boolean Oculus.Voice.Core.Bindings.Android.BaseAndroidConnectionImpl`1::get_IsConnected()
// 0x0000001A System.Void Oculus.Voice.Core.Bindings.Android.BaseAndroidConnectionImpl`1::.ctor(System.String)
// 0x0000001B System.Void Oculus.Voice.Core.Bindings.Android.BaseAndroidConnectionImpl`1::Connect(System.String)
// 0x0000001C System.Void Oculus.Voice.Core.Bindings.Android.BaseAndroidConnectionImpl`1::Disconnect()
// 0x0000001D System.Void Oculus.Voice.Core.Bindings.Android.BaseServiceBinding::.ctor(UnityEngine.AndroidJavaObject)
extern void BaseServiceBinding__ctor_m22F1D7EDB34C2C3349D5678957D925793DAB1D20 (void);
// 0x0000001E System.Void Oculus.Voice.Core.Bindings.Android.BaseServiceBinding::Shutdown()
extern void BaseServiceBinding_Shutdown_mFA621C6F626DA54E41EB6F1E88B8AF18D5F9907F (void);
// 0x0000001F System.Boolean Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::get_IsUsingPlatformIntegration()
extern void VoiceSDKConsoleLoggerImpl_get_IsUsingPlatformIntegration_mD9EC5E5EB8484758F9EA7C4AB77B3C2401030325 (void);
// 0x00000020 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::set_IsUsingPlatformIntegration(System.Boolean)
extern void VoiceSDKConsoleLoggerImpl_set_IsUsingPlatformIntegration_m876AF05667EBCFCC3D9F5CF4AF25AE6ABCF41E97 (void);
// 0x00000021 System.String Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::get_WitApplication()
extern void VoiceSDKConsoleLoggerImpl_get_WitApplication_m6D645BA4007F4C5BE5AAC187E1933C914E10C8B3 (void);
// 0x00000022 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::set_WitApplication(System.String)
extern void VoiceSDKConsoleLoggerImpl_set_WitApplication_m90F2C396FE8F236EB9DACB3AAB1A421C0EE0C6F1 (void);
// 0x00000023 System.Boolean Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::get_ShouldLogToConsole()
extern void VoiceSDKConsoleLoggerImpl_get_ShouldLogToConsole_m4D45C67EF5CD56C8BC8F06C6C7FB31AEE960B463 (void);
// 0x00000024 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::set_ShouldLogToConsole(System.Boolean)
extern void VoiceSDKConsoleLoggerImpl_set_ShouldLogToConsole_m5AED016486F14274253E0B46362531EFECDD5726 (void);
// 0x00000025 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::LogInteractionStart(System.String,System.String)
extern void VoiceSDKConsoleLoggerImpl_LogInteractionStart_m26108DBD0704DE28B70DA663566069CF1297B50D (void);
// 0x00000026 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::LogInteractionEndSuccess()
extern void VoiceSDKConsoleLoggerImpl_LogInteractionEndSuccess_mDF65FD2FC716D13F935943891AE899145D1A1361 (void);
// 0x00000027 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::LogInteractionEndFailure(System.String)
extern void VoiceSDKConsoleLoggerImpl_LogInteractionEndFailure_mBF0953BD4D37F241EE5EF3B6F957BB8C7C624283 (void);
// 0x00000028 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::LogInteractionPoint(System.String)
extern void VoiceSDKConsoleLoggerImpl_LogInteractionPoint_mEE073AF2DA38C14A4C3175BB161D131D6514B185 (void);
// 0x00000029 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::LogAnnotation(System.String,System.String)
extern void VoiceSDKConsoleLoggerImpl_LogAnnotation_m10806011D78726CEC0FA7888D2C21279FC7230C9 (void);
// 0x0000002A System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::.ctor()
extern void VoiceSDKConsoleLoggerImpl__ctor_m23702E026CC9965257C14E48CC5A22084EBA6A6D (void);
// 0x0000002B System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKConsoleLoggerImpl::.cctor()
extern void VoiceSDKConsoleLoggerImpl__cctor_m67035F85CEEF68A1066E4519BC4CAE0203B42771 (void);
// 0x0000002C System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::.ctor(UnityEngine.AndroidJavaObject)
extern void VoiceSDKLoggerBinding__ctor_m427F08E3C3B787F1446089A7D7C8F532B4AEEDCF (void);
// 0x0000002D System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::Connect()
extern void VoiceSDKLoggerBinding_Connect_m8E3EBF537CDAA7B87345B44994D51B1EDF166009 (void);
// 0x0000002E System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::LogInteractionStart(System.String,System.String)
extern void VoiceSDKLoggerBinding_LogInteractionStart_m644168734AD3E9C5167D85AB69A569544A2851F5 (void);
// 0x0000002F System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::LogInteractionEndSuccess(System.String)
extern void VoiceSDKLoggerBinding_LogInteractionEndSuccess_m260A40D66E795A24917FDFFE7657DB86181BD76A (void);
// 0x00000030 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::LogInteractionEndFailure(System.String,System.String)
extern void VoiceSDKLoggerBinding_LogInteractionEndFailure_m78BD1AA57102DEC964B9B62BB81DBB689B452105 (void);
// 0x00000031 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::LogInteractionPoint(System.String,System.String)
extern void VoiceSDKLoggerBinding_LogInteractionPoint_m985D32FFD45C1E718216D16DC10E293F7C86A8BD (void);
// 0x00000032 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKLoggerBinding::LogAnnotation(System.String,System.String)
extern void VoiceSDKLoggerBinding_LogAnnotation_mC92543C05D4F520B53A848DC51FEE6AA139E8722 (void);
// 0x00000033 System.Boolean Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::get_IsUsingPlatformIntegration()
extern void VoiceSDKPlatformLoggerImpl_get_IsUsingPlatformIntegration_m0466CB43678C0193D189DD18F19FAB598E8FC9EB (void);
// 0x00000034 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::set_IsUsingPlatformIntegration(System.Boolean)
extern void VoiceSDKPlatformLoggerImpl_set_IsUsingPlatformIntegration_mFB3D98D346BEF82595EDD3667716E003C0FA9A93 (void);
// 0x00000035 System.String Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::get_WitApplication()
extern void VoiceSDKPlatformLoggerImpl_get_WitApplication_m25B26B83D68539706D5E5F10A1F2E70581FABA59 (void);
// 0x00000036 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::set_WitApplication(System.String)
extern void VoiceSDKPlatformLoggerImpl_set_WitApplication_m7F975934ED58B9277DB05E965C06F983DD59DD7B (void);
// 0x00000037 System.Boolean Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::get_ShouldLogToConsole()
extern void VoiceSDKPlatformLoggerImpl_get_ShouldLogToConsole_mF388128B357EF09A8960F551274486EB206B27B2 (void);
// 0x00000038 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::set_ShouldLogToConsole(System.Boolean)
extern void VoiceSDKPlatformLoggerImpl_set_ShouldLogToConsole_m18C0A8AB3136039D65ED8570E7582031C9652A96 (void);
// 0x00000039 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::.ctor()
extern void VoiceSDKPlatformLoggerImpl__ctor_mB98388D0B9F59FF41DA4D886AF2BE550F914E2DF (void);
// 0x0000003A System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::Connect(System.String)
extern void VoiceSDKPlatformLoggerImpl_Connect_mD33CC2FED6D720DBAF1BECEF6CBAB9BAA6F4CE81 (void);
// 0x0000003B System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::Disconnect()
extern void VoiceSDKPlatformLoggerImpl_Disconnect_m735622EB3C9E542BBB0FB48FD7E968CCFFE95457 (void);
// 0x0000003C System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::LogInteractionStart(System.String,System.String)
extern void VoiceSDKPlatformLoggerImpl_LogInteractionStart_m2947187631C618999B245B6E667B167F61EBE06F (void);
// 0x0000003D System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::LogInteractionEndSuccess()
extern void VoiceSDKPlatformLoggerImpl_LogInteractionEndSuccess_m5F4085592B5CD055E3AD93886BD318B91DAD3F5C (void);
// 0x0000003E System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::LogInteractionEndFailure(System.String)
extern void VoiceSDKPlatformLoggerImpl_LogInteractionEndFailure_mC7941231510EA62A197472A197F76F6F7FEDD755 (void);
// 0x0000003F System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::LogInteractionPoint(System.String)
extern void VoiceSDKPlatformLoggerImpl_LogInteractionPoint_m53EC1674A66CC8956C8B215F42A92749683E150A (void);
// 0x00000040 System.Void Oculus.Voice.Core.Bindings.Android.PlatformLogger.VoiceSDKPlatformLoggerImpl::LogAnnotation(System.String,System.String)
extern void VoiceSDKPlatformLoggerImpl_LogAnnotation_m444D68A273B832F9C5D1D522F0DA544E08AB1307 (void);
static Il2CppMethodPointer s_methodPointers[64] = 
{
	ArrayElementTitleAttribute__ctor_m7990542BCC882B8960A3B61CCAAD6D3024438B52,
	DateTimeUtility_get_UtcNow_m45B39BA40DBE9DB6D4E96FA5C71A4AE49D6F71E2,
	DateTimeUtility_get_ElapsedMilliseconds_mFCCD79CB27652B45BB76D679824C381809226602,
	DateTimeUtility__ctor_m13105FFC88652B794CAFB4919D2B999178A6C946,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AndroidServiceConnection_get_IsConnected_m87FF953B8004D62BAC41D5057E6C1F2E6C87B38C,
	AndroidServiceConnection_get_AssistantServiceConnection_m7CB9FD77AC661424EEEC2258CD62EAB2EE98C6FC,
	AndroidServiceConnection__ctor_m5A0B7A0B00C1B3958A6E6456813F4DC174F87183,
	AndroidServiceConnection_Connect_m72A36FAF67CE01E6B4579F4CF6174497D7149449,
	AndroidServiceConnection_Disconnect_m6793307BEC56F3840BEE62436171D42C7036A8B5,
	AndroidServiceConnection_GetService_m10C8E3DC881909650EFBFFDC577236CEDDF11860,
	NULL,
	NULL,
	NULL,
	NULL,
	BaseServiceBinding__ctor_m22F1D7EDB34C2C3349D5678957D925793DAB1D20,
	BaseServiceBinding_Shutdown_mFA621C6F626DA54E41EB6F1E88B8AF18D5F9907F,
	VoiceSDKConsoleLoggerImpl_get_IsUsingPlatformIntegration_mD9EC5E5EB8484758F9EA7C4AB77B3C2401030325,
	VoiceSDKConsoleLoggerImpl_set_IsUsingPlatformIntegration_m876AF05667EBCFCC3D9F5CF4AF25AE6ABCF41E97,
	VoiceSDKConsoleLoggerImpl_get_WitApplication_m6D645BA4007F4C5BE5AAC187E1933C914E10C8B3,
	VoiceSDKConsoleLoggerImpl_set_WitApplication_m90F2C396FE8F236EB9DACB3AAB1A421C0EE0C6F1,
	VoiceSDKConsoleLoggerImpl_get_ShouldLogToConsole_m4D45C67EF5CD56C8BC8F06C6C7FB31AEE960B463,
	VoiceSDKConsoleLoggerImpl_set_ShouldLogToConsole_m5AED016486F14274253E0B46362531EFECDD5726,
	VoiceSDKConsoleLoggerImpl_LogInteractionStart_m26108DBD0704DE28B70DA663566069CF1297B50D,
	VoiceSDKConsoleLoggerImpl_LogInteractionEndSuccess_mDF65FD2FC716D13F935943891AE899145D1A1361,
	VoiceSDKConsoleLoggerImpl_LogInteractionEndFailure_mBF0953BD4D37F241EE5EF3B6F957BB8C7C624283,
	VoiceSDKConsoleLoggerImpl_LogInteractionPoint_mEE073AF2DA38C14A4C3175BB161D131D6514B185,
	VoiceSDKConsoleLoggerImpl_LogAnnotation_m10806011D78726CEC0FA7888D2C21279FC7230C9,
	VoiceSDKConsoleLoggerImpl__ctor_m23702E026CC9965257C14E48CC5A22084EBA6A6D,
	VoiceSDKConsoleLoggerImpl__cctor_m67035F85CEEF68A1066E4519BC4CAE0203B42771,
	VoiceSDKLoggerBinding__ctor_m427F08E3C3B787F1446089A7D7C8F532B4AEEDCF,
	VoiceSDKLoggerBinding_Connect_m8E3EBF537CDAA7B87345B44994D51B1EDF166009,
	VoiceSDKLoggerBinding_LogInteractionStart_m644168734AD3E9C5167D85AB69A569544A2851F5,
	VoiceSDKLoggerBinding_LogInteractionEndSuccess_m260A40D66E795A24917FDFFE7657DB86181BD76A,
	VoiceSDKLoggerBinding_LogInteractionEndFailure_m78BD1AA57102DEC964B9B62BB81DBB689B452105,
	VoiceSDKLoggerBinding_LogInteractionPoint_m985D32FFD45C1E718216D16DC10E293F7C86A8BD,
	VoiceSDKLoggerBinding_LogAnnotation_mC92543C05D4F520B53A848DC51FEE6AA139E8722,
	VoiceSDKPlatformLoggerImpl_get_IsUsingPlatformIntegration_m0466CB43678C0193D189DD18F19FAB598E8FC9EB,
	VoiceSDKPlatformLoggerImpl_set_IsUsingPlatformIntegration_mFB3D98D346BEF82595EDD3667716E003C0FA9A93,
	VoiceSDKPlatformLoggerImpl_get_WitApplication_m25B26B83D68539706D5E5F10A1F2E70581FABA59,
	VoiceSDKPlatformLoggerImpl_set_WitApplication_m7F975934ED58B9277DB05E965C06F983DD59DD7B,
	VoiceSDKPlatformLoggerImpl_get_ShouldLogToConsole_mF388128B357EF09A8960F551274486EB206B27B2,
	VoiceSDKPlatformLoggerImpl_set_ShouldLogToConsole_m18C0A8AB3136039D65ED8570E7582031C9652A96,
	VoiceSDKPlatformLoggerImpl__ctor_mB98388D0B9F59FF41DA4D886AF2BE550F914E2DF,
	VoiceSDKPlatformLoggerImpl_Connect_mD33CC2FED6D720DBAF1BECEF6CBAB9BAA6F4CE81,
	VoiceSDKPlatformLoggerImpl_Disconnect_m735622EB3C9E542BBB0FB48FD7E968CCFFE95457,
	VoiceSDKPlatformLoggerImpl_LogInteractionStart_m2947187631C618999B245B6E667B167F61EBE06F,
	VoiceSDKPlatformLoggerImpl_LogInteractionEndSuccess_m5F4085592B5CD055E3AD93886BD318B91DAD3F5C,
	VoiceSDKPlatformLoggerImpl_LogInteractionEndFailure_mC7941231510EA62A197472A197F76F6F7FEDD755,
	VoiceSDKPlatformLoggerImpl_LogInteractionPoint_m53EC1674A66CC8956C8B215F42A92749683E150A,
	VoiceSDKPlatformLoggerImpl_LogAnnotation_m444D68A273B832F9C5D1D522F0DA544E08AB1307,
};
static const int32_t s_InvokerIndices[64] = 
{
	2733,
	8757,
	8766,
	5809,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5610,
	5697,
	2733,
	4680,
	5809,
	5697,
	0,
	0,
	0,
	0,
	4680,
	5809,
	5610,
	4589,
	5697,
	4680,
	5610,
	4589,
	2733,
	5809,
	4680,
	4680,
	2733,
	5809,
	8805,
	4680,
	5809,
	2733,
	4680,
	2733,
	2733,
	2733,
	5610,
	4589,
	5697,
	4680,
	5610,
	4589,
	5809,
	4680,
	5809,
	2733,
	5809,
	4680,
	4680,
	2733,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x02000007, { 0, 2 } },
};
extern const uint32_t g_rgctx_T_t713CBFD72389157AB8930324AECA6BD4ED75C0B3;
extern const uint32_t g_rgctx_T_t713CBFD72389157AB8930324AECA6BD4ED75C0B3;
static const Il2CppRGCTXDefinition s_rgctxValues[2] = 
{
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t713CBFD72389157AB8930324AECA6BD4ED75C0B3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t713CBFD72389157AB8930324AECA6BD4ED75C0B3 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssistantCoreSDKRuntime_CodeGenModule;
const Il2CppCodeGenModule g_AssistantCoreSDKRuntime_CodeGenModule = 
{
	"AssistantCoreSDKRuntime.dll",
	64,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	2,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
