﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.String Meta.WitAi.IWitRequestConfiguration::GetConfigurationId()
// 0x00000002 System.String Meta.WitAi.IWitRequestConfiguration::GetApplicationId()
// 0x00000003 Meta.WitAi.Data.Info.WitAppInfo Meta.WitAi.IWitRequestConfiguration::GetApplicationInfo()
// 0x00000004 Meta.WitAi.WitRequestEndpointOverride Meta.WitAi.IWitRequestConfiguration::GetEndpointOverrides()
// 0x00000005 System.String Meta.WitAi.IWitRequestConfiguration::GetClientAccessToken()
// 0x00000006 Meta.WitAi.CoroutineUtility/CoroutinePerformer Meta.WitAi.CoroutineUtility::StartCoroutine(System.Collections.IEnumerator,System.Boolean)
extern void CoroutineUtility_StartCoroutine_m5680A02AF835BAFFC3A54F57446E7594EEB832B8 (void);
// 0x00000007 Meta.WitAi.CoroutineUtility/CoroutinePerformer Meta.WitAi.CoroutineUtility::GetPerformer()
extern void CoroutineUtility_GetPerformer_mA455E68F266B8A2DB7BDD6BDA7ACCA29E7F22C67 (void);
// 0x00000008 System.Boolean Meta.WitAi.CoroutineUtility/CoroutinePerformer::get_IsRunning()
extern void CoroutinePerformer_get_IsRunning_m19E6CECFFAC5B06651F463FEF2C63C5394FFE227 (void);
// 0x00000009 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::set_IsRunning(System.Boolean)
extern void CoroutinePerformer_set_IsRunning_m897C40657C00115C43D53CBEF4C3143B9A9B23A1 (void);
// 0x0000000A System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::Awake()
extern void CoroutinePerformer_Awake_m903BD197AF349AA78E509053AC670749F15E4E64 (void);
// 0x0000000B System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineBegin(System.Collections.IEnumerator,System.Boolean)
extern void CoroutinePerformer_CoroutineBegin_m168F0759DFBF0128EE9C1BB3855D5EE5C12E2F32 (void);
// 0x0000000C System.Collections.IEnumerator Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineIterateEnumerator()
extern void CoroutinePerformer_CoroutineIterateEnumerator_m110D9685700AD6EA9D7FD07C9D87CFF46F6772D0 (void);
// 0x0000000D System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::Update()
extern void CoroutinePerformer_Update_mF318B1FD0CA4DF28A2AE2F05A3D78461EDE43B5F (void);
// 0x0000000E System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineIterateUpdate()
extern void CoroutinePerformer_CoroutineIterateUpdate_m6E65F4FACA2E969CC66A5FF3BC6A7FADC5C1F944 (void);
// 0x0000000F System.Boolean Meta.WitAi.CoroutineUtility/CoroutinePerformer::MoveNext(System.Collections.IEnumerator)
extern void CoroutinePerformer_MoveNext_m79ADEA3A1DFA04FCB54C5812BD0BF230052C4A49 (void);
// 0x00000010 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::OnDestroy()
extern void CoroutinePerformer_OnDestroy_m51550C2552E781808BB4A6ED7CC3D5C241B248B7 (void);
// 0x00000011 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineCancel()
extern void CoroutinePerformer_CoroutineCancel_m51E365ADABD833BDC0ED8020BF6400F3D87A3E14 (void);
// 0x00000012 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineComplete()
extern void CoroutinePerformer_CoroutineComplete_mAD804B2B7CCCF5FD9B27548D3AE9A03DC6589E12 (void);
// 0x00000013 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::CoroutineUnload()
extern void CoroutinePerformer_CoroutineUnload_mB36A94A478413E587602AEF7801242E27CC57041 (void);
// 0x00000014 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer::.ctor()
extern void CoroutinePerformer__ctor_m38757CB7375B7289938A5B9381AEB2321E4794E9 (void);
// 0x00000015 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::.ctor(System.Int32)
extern void U3CCoroutineIterateEnumeratorU3Ed__9__ctor_m004DE712531EB1CC04344B1CF1FC4D087B69560F (void);
// 0x00000016 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::System.IDisposable.Dispose()
extern void U3CCoroutineIterateEnumeratorU3Ed__9_System_IDisposable_Dispose_mADE839050C9C4523150F56B0A6D34D437A44BA21 (void);
// 0x00000017 System.Boolean Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::MoveNext()
extern void U3CCoroutineIterateEnumeratorU3Ed__9_MoveNext_m4389ECBDACF6356F0675DDC17FBBF3ACA9BE2BE6 (void);
// 0x00000018 System.Object Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCFEED8F504F0EB8227AB65BC8FA0D346D86CA6B2 (void);
// 0x00000019 System.Void Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::System.Collections.IEnumerator.Reset()
extern void U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_IEnumerator_Reset_mF0CD85E8E99747845372CCE5C8A0399A09401B10 (void);
// 0x0000001A System.Object Meta.WitAi.CoroutineUtility/CoroutinePerformer/<CoroutineIterateEnumerator>d__9::System.Collections.IEnumerator.get_Current()
extern void U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_IEnumerator_get_Current_m32F9100BB3E02E28735715AB1CA4C656A43E8C84 (void);
// 0x0000001B System.Boolean Meta.WitAi.EnumerableExtensions::Equivalent(System.Collections.Generic.IEnumerable`1<TSource>,System.Collections.Generic.IEnumerable`1<TSource>)
// 0x0000001C Meta.WitAi.ThreadUtility/ThreadPerformer Meta.WitAi.ThreadUtility::PerformInBackground(System.Func`1<System.Boolean>,System.Action`1<System.Boolean>,System.Single)
extern void ThreadUtility_PerformInBackground_m5225CF8D107EF69D434F52633F1A62BC64B4AF1A (void);
// 0x0000001D System.Boolean Meta.WitAi.ThreadUtility/ThreadPerformer::get_IsRunning()
extern void ThreadPerformer_get_IsRunning_m8783C25140FE776DD1BD48DE782F3AEEFD449D89 (void);
// 0x0000001E System.Void Meta.WitAi.ThreadUtility/ThreadPerformer::set_IsRunning(System.Boolean)
extern void ThreadPerformer_set_IsRunning_mC46576DF9ADFFB9A57D8523B3A4CD7A839BCF515 (void);
// 0x0000001F System.Void Meta.WitAi.ThreadUtility/ThreadPerformer::.ctor(System.Func`1<System.Boolean>,System.Action`1<System.Boolean>,System.Single)
extern void ThreadPerformer__ctor_m38152742FAFF310C8EC305BF1EC5862B9F57A3EC (void);
// 0x00000020 System.Void Meta.WitAi.ThreadUtility/ThreadPerformer::Work()
extern void ThreadPerformer_Work_mC4239E321130800C9C6E7B9E71B5F80A6D0A8DDF (void);
// 0x00000021 System.Collections.IEnumerator Meta.WitAi.ThreadUtility/ThreadPerformer::WaitForCompletion()
extern void ThreadPerformer_WaitForCompletion_m84A642BDA2546E959CB5FEE31563C2910DD15FC1 (void);
// 0x00000022 System.Boolean Meta.WitAi.ThreadUtility/ThreadPerformer::IsTimedOut(System.DateTime)
extern void ThreadPerformer_IsTimedOut_m9FF4CD7F3951668149BAB121C11CEB6E51710810 (void);
// 0x00000023 System.Void Meta.WitAi.ThreadUtility/ThreadPerformer::Quit()
extern void ThreadPerformer_Quit_mCAE2EBA8A920018BDD42EFEAF778E094F851365D (void);
// 0x00000024 System.Void Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::.ctor(System.Int32)
extern void U3CWaitForCompletionU3Ed__12__ctor_mA2EC205F9BC60B2434F8742AA2DE6B46445BB015 (void);
// 0x00000025 System.Void Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::System.IDisposable.Dispose()
extern void U3CWaitForCompletionU3Ed__12_System_IDisposable_Dispose_m3B0C465A7782AFA1F20BAF8852C88906B76C1EDE (void);
// 0x00000026 System.Boolean Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::MoveNext()
extern void U3CWaitForCompletionU3Ed__12_MoveNext_mD36C6466A88B687522ABCE8A64EE7DAAFB125DBA (void);
// 0x00000027 System.Object Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitForCompletionU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE7327EBB09EAC46C920610F63BA0EDD5D6F759CF (void);
// 0x00000028 System.Void Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::System.Collections.IEnumerator.Reset()
extern void U3CWaitForCompletionU3Ed__12_System_Collections_IEnumerator_Reset_m050E5036651E75800B1C8DBF4CE0F417DCBCCE3E (void);
// 0x00000029 System.Object Meta.WitAi.ThreadUtility/ThreadPerformer/<WaitForCompletion>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CWaitForCompletionU3Ed__12_System_Collections_IEnumerator_get_Current_mEB5D836A53F9E76B434351EECC0F450CEAFBC364 (void);
// 0x0000002A System.Boolean Meta.WitAi.VLog::get_SuppressErrors()
extern void VLog_get_SuppressErrors_m7822CA1B52753AD2CEA6D1F53C848C733BFC0DF3 (void);
// 0x0000002B System.Void Meta.WitAi.VLog::set_SuppressErrors(System.Boolean)
extern void VLog_set_SuppressErrors_m3CC6ED42BE850D8CEAB0D6B8ECAEF4F196BC850E (void);
// 0x0000002C System.Void Meta.WitAi.VLog::add_OnPreLog(System.Action`3<System.Text.StringBuilder,System.String,UnityEngine.LogType>)
extern void VLog_add_OnPreLog_m80E921053B5B27C2C94B805E2102598E6D702A94 (void);
// 0x0000002D System.Void Meta.WitAi.VLog::remove_OnPreLog(System.Action`3<System.Text.StringBuilder,System.String,UnityEngine.LogType>)
extern void VLog_remove_OnPreLog_m4D59F8243A80F8F713C89C481C133C79864647C6 (void);
// 0x0000002E System.Void Meta.WitAi.VLog::D(System.Object)
extern void VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37 (void);
// 0x0000002F System.Void Meta.WitAi.VLog::D(System.String,System.Object)
extern void VLog_D_m133AFAEBCDE1687214E2E4C38905D6690105F9E4 (void);
// 0x00000030 System.Void Meta.WitAi.VLog::W(System.Object)
extern void VLog_W_m7943297ED32FD0E92544C324E6793089056A2344 (void);
// 0x00000031 System.Void Meta.WitAi.VLog::W(System.String,System.Object)
extern void VLog_W_m97F796A4C02E724416AFDB19E1B91C1C9F284575 (void);
// 0x00000032 System.Void Meta.WitAi.VLog::E(System.Object)
extern void VLog_E_m72B89ED9282703998618195366B61B9F26A40AC1 (void);
// 0x00000033 System.Void Meta.WitAi.VLog::E(System.String,System.Object)
extern void VLog_E_m407BD08603D66FB6F1173E8E2F172395E461334C (void);
// 0x00000034 System.Void Meta.WitAi.VLog::Log(UnityEngine.LogType,System.String,System.Object)
extern void VLog_Log_m77583BC27FFECD24FBCD8BCCC77D29253E1C5DA6 (void);
// 0x00000035 System.String Meta.WitAi.VLog::GetCallingCategory()
extern void VLog_GetCallingCategory_mD8F04E537A19B1E7E38B26B71869A5523567F3AE (void);
// 0x00000036 System.Void Meta.WitAi.VLog::WrapWithCallingLink(System.Text.StringBuilder,System.Int32)
extern void VLog_WrapWithCallingLink_mB3F632BBAF9E033A864DCB1A04E19A3D0091DB67 (void);
// 0x00000037 System.Void Meta.WitAi.VLog::WrapWithLogColor(System.Text.StringBuilder,System.Int32,UnityEngine.LogType)
extern void VLog_WrapWithLogColor_m099596C358459A020271465417A1CDA6CB0B6FB5 (void);
// 0x00000038 System.Int32 Meta.WitAi.Requests.VRequest::get_Timeout()
extern void VRequest_get_Timeout_m0C2A0B6850A5377DF0439A1BE30E3FCD98FCD225 (void);
// 0x00000039 System.Void Meta.WitAi.Requests.VRequest::set_Timeout(System.Int32)
extern void VRequest_set_Timeout_mB1621F4CBAEBF2E3F8FE30866911BE2915A2E87B (void);
// 0x0000003A System.Boolean Meta.WitAi.Requests.VRequest::get_IsComplete()
extern void VRequest_get_IsComplete_m81474D77CDD9BDFEDDF752B12A81D0794FB1BE0C (void);
// 0x0000003B System.Void Meta.WitAi.Requests.VRequest::set_IsComplete(System.Boolean)
extern void VRequest_set_IsComplete_mC5583B96C76FD15B52AE82B4D055B26783B9B9B1 (void);
// 0x0000003C System.Boolean Meta.WitAi.Requests.VRequest::get_IsPerforming()
extern void VRequest_get_IsPerforming_mB8C0D61A2D99A3CE2D4CF74C89D82827BD239393 (void);
// 0x0000003D System.Single Meta.WitAi.Requests.VRequest::get_Progress()
extern void VRequest_get_Progress_mC18867D610CA62C3373ED2AFBA5BCD70D6E9FAD8 (void);
// 0x0000003E System.Boolean Meta.WitAi.Requests.VRequest::Request(UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<UnityEngine.Networking.UnityWebRequest>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_Request_m684F5A0DF9F66FAC7A2B53EDE5E7D11634014893 (void);
// 0x0000003F System.String Meta.WitAi.Requests.VRequest::CleanUrl(System.String)
extern void VRequest_CleanUrl_m5876C13024534312528195DB22E81CD8C06D7430 (void);
// 0x00000040 System.Collections.Generic.Dictionary`2<System.String,System.String> Meta.WitAi.Requests.VRequest::GetHeaders()
extern void VRequest_GetHeaders_m5DE012C50EDAA025BCE7EB3839E3147642D055A0 (void);
// 0x00000041 System.Collections.IEnumerator Meta.WitAi.Requests.VRequest::PerformUpdate()
extern void VRequest_PerformUpdate_mAC5A928ACD1D56ECF2FB316E604A6A0381927567 (void);
// 0x00000042 System.Void Meta.WitAi.Requests.VRequest::Begin()
extern void VRequest_Begin_m3863AA40526B8AD5F9222AEBE286772BF2833075 (void);
// 0x00000043 System.Void Meta.WitAi.Requests.VRequest::Complete()
extern void VRequest_Complete_mAD054B7711A37664EB212EF1DAA32CDAA09E3287 (void);
// 0x00000044 System.Void Meta.WitAi.Requests.VRequest::Cancel()
extern void VRequest_Cancel_mC26F1718B30082B2F939CE3898AF4481F897FDB2 (void);
// 0x00000045 System.Void Meta.WitAi.Requests.VRequest::Unload()
extern void VRequest_Unload_mC59B7F890F95E41EA11D4165DF259F5CF2AF54EA (void);
// 0x00000046 System.Boolean Meta.WitAi.Requests.VRequest::RequestFileHeaders(System.Uri,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.Collections.Generic.Dictionary`2<System.String,System.String>>)
extern void VRequest_RequestFileHeaders_m11ECE714308E5E494427593E2C70E18217114844 (void);
// 0x00000047 System.Boolean Meta.WitAi.Requests.VRequest::RequestFile(System.Uri,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.Byte[]>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_RequestFile_m1E29DDF0B87DC09A7DBA6C27A08554CB643A4A07 (void);
// 0x00000048 System.Boolean Meta.WitAi.Requests.VRequest::RequestFileDownload(System.String,UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.Boolean>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_RequestFileDownload_m2E5FBE78A57283210AF091B14F5756B3CECE1B70 (void);
// 0x00000049 System.Boolean Meta.WitAi.Requests.VRequest::RequestFileExists(System.String,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.Boolean>)
extern void VRequest_RequestFileExists_m10362277B1273A6C217E9BABAC916476D0E24778 (void);
// 0x0000004A System.Boolean Meta.WitAi.Requests.VRequest::RequestText(UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.String>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_RequestText_mF65A05F3294E36C3C5C058144580DD657D21B272 (void);
// 0x0000004B System.Boolean Meta.WitAi.Requests.VRequest::RequestJson(UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x0000004C System.Boolean Meta.WitAi.Requests.VRequest::RequestJson(System.Uri,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x0000004D System.Boolean Meta.WitAi.Requests.VRequest::RequestJson(System.Uri,System.Byte[],Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x0000004E System.Boolean Meta.WitAi.Requests.VRequest::RequestJson(System.Uri,System.String,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x0000004F System.Boolean Meta.WitAi.Requests.VRequest::RequestAudioClip(UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<UnityEngine.AudioClip>,UnityEngine.AudioType,System.Boolean,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_RequestAudioClip_mD290A894976F216133BCBD84FEEC8A5910FEAEBD (void);
// 0x00000050 System.Boolean Meta.WitAi.Requests.VRequest::RequestAudioClip(System.Uri,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<UnityEngine.AudioClip>,UnityEngine.AudioType,System.Boolean,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void VRequest_RequestAudioClip_m889F3CDCDB4752DCB79529692CCB23459C855800 (void);
// 0x00000051 System.Void Meta.WitAi.Requests.VRequest::.ctor()
extern void VRequest__ctor_m2CBEC55394F069C557B77F74AEC80508F65C8537 (void);
// 0x00000052 System.Void Meta.WitAi.Requests.VRequest::.cctor()
extern void VRequest__cctor_m3A9D35BF41950AE968FB9F11758C217790220A3E (void);
// 0x00000053 System.Void Meta.WitAi.Requests.VRequest/RequestProgressDelegate::.ctor(System.Object,System.IntPtr)
extern void RequestProgressDelegate__ctor_m3E241D94035D7034B4DEF78A048A4B909EEEC20F (void);
// 0x00000054 System.Void Meta.WitAi.Requests.VRequest/RequestProgressDelegate::Invoke(System.Single)
extern void RequestProgressDelegate_Invoke_m26170A39DD5E2DBC99E324679C632FDE0AFEE46C (void);
// 0x00000055 System.IAsyncResult Meta.WitAi.Requests.VRequest/RequestProgressDelegate::BeginInvoke(System.Single,System.AsyncCallback,System.Object)
extern void RequestProgressDelegate_BeginInvoke_m384DB7AB3E11756EFC97B3AB16D850BC3D5BCE97 (void);
// 0x00000056 System.Void Meta.WitAi.Requests.VRequest/RequestProgressDelegate::EndInvoke(System.IAsyncResult)
extern void RequestProgressDelegate_EndInvoke_m1041D2E110074E4C4B527C17CFC53D015A0FB882 (void);
// 0x00000057 System.Void Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1::.ctor(System.Object,System.IntPtr)
// 0x00000058 System.Void Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1::Invoke(TResult,System.String)
// 0x00000059 System.IAsyncResult Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1::BeginInvoke(TResult,System.String,System.AsyncCallback,System.Object)
// 0x0000005A System.Void Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1::EndInvoke(System.IAsyncResult)
// 0x0000005B System.Void Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::.ctor(System.Int32)
extern void U3CPerformUpdateU3Ed__26__ctor_m36004B10B24E5820CAA8267A74C8639F4F49C42D (void);
// 0x0000005C System.Void Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::System.IDisposable.Dispose()
extern void U3CPerformUpdateU3Ed__26_System_IDisposable_Dispose_m10CEBD93AA93069E54239BFD088F261FE213FDB0 (void);
// 0x0000005D System.Boolean Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::MoveNext()
extern void U3CPerformUpdateU3Ed__26_MoveNext_mF980F4BB747AA453FC6648A31220E8330D71BA54 (void);
// 0x0000005E System.Object Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CPerformUpdateU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m21781DF1DF684FC71313A014D72F7B31166516DA (void);
// 0x0000005F System.Void Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::System.Collections.IEnumerator.Reset()
extern void U3CPerformUpdateU3Ed__26_System_Collections_IEnumerator_Reset_mDB7A136F0EAA8377B7766F8FF8498228EEAF96B6 (void);
// 0x00000060 System.Object Meta.WitAi.Requests.VRequest/<PerformUpdate>d__26::System.Collections.IEnumerator.get_Current()
extern void U3CPerformUpdateU3Ed__26_System_Collections_IEnumerator_get_Current_m9373FBB805C95D909D98E1FD4A110E355DD13EFB (void);
// 0x00000061 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass31_0::.ctor()
extern void U3CU3Ec__DisplayClass31_0__ctor_mF2C81670D1D5DD2E7449A0B3FAA0197145AB74D7 (void);
// 0x00000062 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass31_0::<RequestFileHeaders>b__0(UnityEngine.Networking.UnityWebRequest,System.String)
extern void U3CU3Ec__DisplayClass31_0_U3CRequestFileHeadersU3Eb__0_mD9F2AE383EC094E82C9F2C3955DD98D847825AD9 (void);
// 0x00000063 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass32_0::.ctor()
extern void U3CU3Ec__DisplayClass32_0__ctor_m2D6905D9649DE06DF13C6E60BAC6D795F3C04709 (void);
// 0x00000064 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass32_0::<RequestFile>b__0(UnityEngine.Networking.UnityWebRequest,System.String)
extern void U3CU3Ec__DisplayClass32_0_U3CRequestFileU3Eb__0_m7D7D386DA31FB031DCB29A62C1EEEAB325BBC20E (void);
// 0x00000065 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass33_0::.ctor()
extern void U3CU3Ec__DisplayClass33_0__ctor_m92E90653A2F0749092E188A03B2CC797C77C2CD6 (void);
// 0x00000066 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass33_0::<RequestFileDownload>b__0(UnityEngine.Networking.UnityWebRequest,System.String)
extern void U3CU3Ec__DisplayClass33_0_U3CRequestFileDownloadU3Eb__0_mB18717AD9CED1D355A6ACE75D0B0FCE7CBB3A129 (void);
// 0x00000067 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass34_0::.ctor()
extern void U3CU3Ec__DisplayClass34_0__ctor_m08ADDADD2801B43292565C0D4180D0DEC1BC5273 (void);
// 0x00000068 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass34_0::<RequestFileExists>b__0(System.Collections.Generic.Dictionary`2<System.String,System.String>,System.String)
extern void U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__0_mA9D99FB63B3360672F826527A4F0DA37C7948D56 (void);
// 0x00000069 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass34_0::<RequestFileExists>b__1(System.Byte[],System.String)
extern void U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__1_m52676EA887466195248E2A8C023CDDC30AE88FDA (void);
// 0x0000006A System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass34_0::<RequestFileExists>b__2(System.Single)
extern void U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__2_m3A9A88711FA1AB800141A5C783001E0525134A24 (void);
// 0x0000006B System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass35_0::.ctor()
extern void U3CU3Ec__DisplayClass35_0__ctor_m99CA6D4A98B8562CB0BCCC4631EDDA81CE34664A (void);
// 0x0000006C System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass35_0::<RequestText>b__0(UnityEngine.Networking.UnityWebRequest,System.String)
extern void U3CU3Ec__DisplayClass35_0_U3CRequestTextU3Eb__0_mB583A33D1C989534D7DD9C0D6C2B8D4DFE5626F1 (void);
// 0x0000006D System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass36_0`1::.ctor()
// 0x0000006E System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass36_0`1::<RequestJson>b__0(System.String,System.String)
// 0x0000006F System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass36_1`1::.ctor()
// 0x00000070 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass36_1`1::<RequestJson>b__1(TData,System.Boolean)
// 0x00000071 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass40_0::.ctor()
extern void U3CU3Ec__DisplayClass40_0__ctor_m2840E881AD97DFDA0A7BD75190F2848F6B373FF8 (void);
// 0x00000072 System.Void Meta.WitAi.Requests.VRequest/<>c__DisplayClass40_0::<RequestAudioClip>b__0(UnityEngine.Networking.UnityWebRequest,System.String)
extern void U3CU3Ec__DisplayClass40_0_U3CRequestAudioClipU3Eb__0_mF7330104481698419DDB25B7CB4A7EF7D451F7C8 (void);
// 0x00000073 System.Void Meta.WitAi.Requests.WitMessageVRequest::.ctor(Meta.WitAi.IWitRequestConfiguration)
extern void WitMessageVRequest__ctor_mFC7436091A46F29F5171AC007CD2FB554404D3CC (void);
// 0x00000074 System.Boolean Meta.WitAi.Requests.WitMessageVRequest::MessageRequest(System.String,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<Meta.WitAi.Json.WitResponseNode>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void WitMessageVRequest_MessageRequest_mF48587E2F9305DB73FBC30A382D9C2D099BA702F (void);
// 0x00000075 System.Void Meta.WitAi.Requests.WitTTSVRequest::.ctor(Meta.WitAi.IWitRequestConfiguration)
extern void WitTTSVRequest__ctor_mE43EC29E3525BEC8516493C873894135017E6FB6 (void);
// 0x00000076 UnityEngine.Networking.UnityWebRequest Meta.WitAi.Requests.WitTTSVRequest::GetUnityRequest(System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>)
extern void WitTTSVRequest_GetUnityRequest_mE62D08FFE6CA6BAFA6ACE487837354A2672308E3 (void);
// 0x00000077 System.Boolean Meta.WitAi.Requests.WitTTSVRequest::RequestStream(System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<UnityEngine.AudioClip>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void WitTTSVRequest_RequestStream_m543A1147518C743CEB7925E4B69D72A1C9784508 (void);
// 0x00000078 System.Boolean Meta.WitAi.Requests.WitTTSVRequest::RequestDownload(System.String,System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<System.Boolean>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void WitTTSVRequest_RequestDownload_mC18DF9CEEB421F2A33282F36F70844C508731D3B (void);
// 0x00000079 System.Void Meta.WitAi.Requests.WitTTSVRequest::.cctor()
extern void WitTTSVRequest__cctor_mDAA3B8F2C6377AA62732ACB19F26C27C420C6C1A (void);
// 0x0000007A System.Void Meta.WitAi.Requests.WitVRequest::add_OnProvideCustomUri(System.Func`2<System.UriBuilder,System.Uri>)
extern void WitVRequest_add_OnProvideCustomUri_mE50119C857E73845F9EF84573EFB9BFB3E75D538 (void);
// 0x0000007B System.Void Meta.WitAi.Requests.WitVRequest::remove_OnProvideCustomUri(System.Func`2<System.UriBuilder,System.Uri>)
extern void WitVRequest_remove_OnProvideCustomUri_mB41DA656E7463EF519D71625058E4994334A3AC1 (void);
// 0x0000007C System.Void Meta.WitAi.Requests.WitVRequest::add_OnProvideCustomHeaders(System.Action`1<System.Collections.Generic.Dictionary`2<System.String,System.String>>)
extern void WitVRequest_add_OnProvideCustomHeaders_mA252E19E936B0DFDE47D63DF259CD44363AF86A4 (void);
// 0x0000007D System.Void Meta.WitAi.Requests.WitVRequest::remove_OnProvideCustomHeaders(System.Action`1<System.Collections.Generic.Dictionary`2<System.String,System.String>>)
extern void WitVRequest_remove_OnProvideCustomHeaders_mC7531AEA066356C3FB022E2FBE6431856E57FFB2 (void);
// 0x0000007E System.Void Meta.WitAi.Requests.WitVRequest::add_OnProvideCustomUserAgent(System.Action`1<System.Text.StringBuilder>)
extern void WitVRequest_add_OnProvideCustomUserAgent_m0ADDFB64122A96484E3714F6C73F60B9E120175F (void);
// 0x0000007F System.Void Meta.WitAi.Requests.WitVRequest::remove_OnProvideCustomUserAgent(System.Action`1<System.Text.StringBuilder>)
extern void WitVRequest_remove_OnProvideCustomUserAgent_m226B1C965F1A3279806A45939F7C92091271553B (void);
// 0x00000080 Meta.WitAi.IWitRequestConfiguration Meta.WitAi.Requests.WitVRequest::get_Configuration()
extern void WitVRequest_get_Configuration_m249A5C4BF1B892702955A74A30BBFA082E5F124F (void);
// 0x00000081 System.Void Meta.WitAi.Requests.WitVRequest::.ctor(Meta.WitAi.IWitRequestConfiguration,System.Boolean)
extern void WitVRequest__ctor_mF6B376A37B660B28858C9BE5165972E24A151186 (void);
// 0x00000082 System.Uri Meta.WitAi.Requests.WitVRequest::GetUri(System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>)
extern void WitVRequest_GetUri_m2B02986E00CD6AB6903AA77A2418494D1494B468 (void);
// 0x00000083 System.Collections.Generic.Dictionary`2<System.String,System.String> Meta.WitAi.Requests.WitVRequest::GetHeaders()
extern void WitVRequest_GetHeaders_m9E469964828B68DB649BE59D9E53A3C06E68DE05 (void);
// 0x00000084 System.Boolean Meta.WitAi.Requests.WitVRequest::Request(UnityEngine.Networking.UnityWebRequest,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<UnityEngine.Networking.UnityWebRequest>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
extern void WitVRequest_Request_mA56EBEE3E3EB8F4C8D0C29B1CE5C60C4289FEB65 (void);
// 0x00000085 System.Boolean Meta.WitAi.Requests.WitVRequest::RequestWit(System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x00000086 System.Boolean Meta.WitAi.Requests.WitVRequest::RequestWit(System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>,System.String,Meta.WitAi.Requests.VRequest/RequestCompleteDelegate`1<TData>,Meta.WitAi.Requests.VRequest/RequestProgressDelegate)
// 0x00000087 System.Uri Meta.WitAi.Requests.WitVRequest::GetWitUri(Meta.WitAi.IWitRequestConfiguration,System.String,System.Collections.Generic.Dictionary`2<System.String,System.String>)
extern void WitVRequest_GetWitUri_m2AAB406E20FA195917B5754ACFDCA1EDD7364622 (void);
// 0x00000088 System.Collections.Generic.Dictionary`2<System.String,System.String> Meta.WitAi.Requests.WitVRequest::GetWitHeaders(Meta.WitAi.IWitRequestConfiguration,System.Boolean)
extern void WitVRequest_GetWitHeaders_m3CB0711D7370D325D875678A1628C885E1CA53C5 (void);
// 0x00000089 System.String Meta.WitAi.Requests.WitVRequest::GetAuthorizationHeader(Meta.WitAi.IWitRequestConfiguration,System.Boolean)
extern void WitVRequest_GetAuthorizationHeader_m1E4D1D86D4B3E55CB44909166197B1C2A7F68E74 (void);
// 0x0000008A System.String Meta.WitAi.Requests.WitVRequest::GetUserAgentHeader(Meta.WitAi.IWitRequestConfiguration)
extern void WitVRequest_GetUserAgentHeader_m58439F7735F03A0F871AE4F6B626817814735464 (void);
// 0x0000008B System.Boolean Meta.WitAi.Json.ColorConverter::get_CanRead()
extern void ColorConverter_get_CanRead_m6BA7E1A33F289174197CDC9472504788516030AC (void);
// 0x0000008C System.Boolean Meta.WitAi.Json.ColorConverter::get_CanWrite()
extern void ColorConverter_get_CanWrite_m2882801C1832AA3433F8862734DFDB2D11F0A8CA (void);
// 0x0000008D System.Boolean Meta.WitAi.Json.ColorConverter::CanConvert(System.Type)
extern void ColorConverter_CanConvert_mF6A94F71611BBCF9ADDCB1D5B7996CD1EF1BE1F8 (void);
// 0x0000008E System.Object Meta.WitAi.Json.ColorConverter::ReadJson(Meta.WitAi.Json.WitResponseNode,System.Type,System.Object)
extern void ColorConverter_ReadJson_m56167EE71B1F42659EAA4BAED37155C59EA764E5 (void);
// 0x0000008F Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.ColorConverter::WriteJson(System.Object)
extern void ColorConverter_WriteJson_m04D2BEB8964E516512AD8205C500D00DB638ADD0 (void);
// 0x00000090 System.Void Meta.WitAi.Json.ColorConverter::.ctor()
extern void ColorConverter__ctor_m806E5A48DA7D9E1508D2CC8230CB169A38943731 (void);
// 0x00000091 System.Boolean Meta.WitAi.Json.DateTimeConverter::get_CanRead()
extern void DateTimeConverter_get_CanRead_m9E90F893D1E98AD77631006DF2338944A1C03670 (void);
// 0x00000092 System.Boolean Meta.WitAi.Json.DateTimeConverter::get_CanWrite()
extern void DateTimeConverter_get_CanWrite_mBB56A0BF211282AE3DB9BBD34C199BE213982861 (void);
// 0x00000093 System.Boolean Meta.WitAi.Json.DateTimeConverter::CanConvert(System.Type)
extern void DateTimeConverter_CanConvert_m4C07AB765E9C480554C43C75DB48BA41AB36D742 (void);
// 0x00000094 System.Object Meta.WitAi.Json.DateTimeConverter::ReadJson(Meta.WitAi.Json.WitResponseNode,System.Type,System.Object)
extern void DateTimeConverter_ReadJson_mD8AFB276D86DDAA360E639895AAB31207823489E (void);
// 0x00000095 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.DateTimeConverter::WriteJson(System.Object)
extern void DateTimeConverter_WriteJson_m5C0BAB79CADD5E5F832057C4E6A9787B86B6622F (void);
// 0x00000096 System.Void Meta.WitAi.Json.DateTimeConverter::.ctor()
extern void DateTimeConverter__ctor_m2EFD9B80003DA80056F01787FB0F697F141DABDD (void);
// 0x00000097 System.Boolean Meta.WitAi.Json.HashSetConverter`1::get_CanRead()
// 0x00000098 System.Boolean Meta.WitAi.Json.HashSetConverter`1::get_CanWrite()
// 0x00000099 System.Boolean Meta.WitAi.Json.HashSetConverter`1::CanConvert(System.Type)
// 0x0000009A System.Object Meta.WitAi.Json.HashSetConverter`1::ReadJson(Meta.WitAi.Json.WitResponseNode,System.Type,System.Object)
// 0x0000009B Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.HashSetConverter`1::WriteJson(System.Object)
// 0x0000009C System.Void Meta.WitAi.Json.HashSetConverter`1::.ctor()
// 0x0000009D System.Boolean Meta.WitAi.Json.IJsonDeserializer::DeserializeObject(Meta.WitAi.Json.WitResponseClass)
// 0x0000009E System.Boolean Meta.WitAi.Json.IJsonSerializer::SerializeObject(Meta.WitAi.Json.WitResponseClass)
// 0x0000009F Meta.WitAi.Json.JsonConverter[] Meta.WitAi.Json.JsonConvert::get_DefaultConverters()
extern void JsonConvert_get_DefaultConverters_m7B0032C6B68BCA96DED146985811DA84A4AFF216 (void);
// 0x000000A0 System.Object Meta.WitAi.Json.JsonConvert::EnsureExists(System.Type,System.Object)
extern void JsonConvert_EnsureExists_m34B862CAA75A4DC8A0E4863A154F99483E6ADA9E (void);
// 0x000000A1 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.JsonConvert::DeserializeToken(System.String)
extern void JsonConvert_DeserializeToken_m1B7AF67114FB4FFEC5BFCADBB6820DBE3D7F8666 (void);
// 0x000000A2 System.Void Meta.WitAi.Json.JsonConvert::DeserializeObjectAsync(System.String,System.Action`2<IN_TYPE,System.Boolean>,Meta.WitAi.Json.JsonConverter[])
// 0x000000A3 System.Void Meta.WitAi.Json.JsonConvert::DeserializeObjectAsync(Meta.WitAi.Json.WitResponseNode,System.Action`2<IN_TYPE,System.Boolean>,Meta.WitAi.Json.JsonConverter[])
// 0x000000A4 IN_TYPE Meta.WitAi.Json.JsonConvert::DeserializeObject(System.String,Meta.WitAi.Json.JsonConverter[])
// 0x000000A5 IN_TYPE Meta.WitAi.Json.JsonConvert::DeserializeObject(Meta.WitAi.Json.WitResponseNode,Meta.WitAi.Json.JsonConverter[])
// 0x000000A6 System.Boolean Meta.WitAi.Json.JsonConvert::DeserializeIntoObject(IN_TYPE&,System.String,Meta.WitAi.Json.JsonConverter[])
// 0x000000A7 System.Boolean Meta.WitAi.Json.JsonConvert::DeserializeIntoObject(IN_TYPE&,Meta.WitAi.Json.WitResponseNode,Meta.WitAi.Json.JsonConverter[])
// 0x000000A8 System.Object Meta.WitAi.Json.JsonConvert::DeserializeToken(System.Type,System.Object,Meta.WitAi.Json.WitResponseNode,System.Text.StringBuilder,Meta.WitAi.Json.JsonConverter[])
extern void JsonConvert_DeserializeToken_mB12EA997DD32B3ACE6656B65A0287DDEE4204C4D (void);
// 0x000000A9 System.Object Meta.WitAi.Json.JsonConvert::DeserializeEnum(System.Type,System.Object,System.String,System.Text.StringBuilder)
extern void JsonConvert_DeserializeEnum_m2D6D337E8500810C18824336374A420FFFE8A558 (void);
// 0x000000AA ITEM_TYPE[] Meta.WitAi.Json.JsonConvert::DeserializeArray(System.Object,Meta.WitAi.Json.WitResponseNode,System.Text.StringBuilder,Meta.WitAi.Json.JsonConverter[])
// 0x000000AB System.Object Meta.WitAi.Json.JsonConvert::DeserializeClass(System.Type,System.Object,Meta.WitAi.Json.WitResponseClass,System.Text.StringBuilder,Meta.WitAi.Json.JsonConverter[])
extern void JsonConvert_DeserializeClass_m24309A50B11D8C4FE0BA0C29E07B885C8F2D250D (void);
// 0x000000AC System.Object Meta.WitAi.Json.JsonConvert::DeserializeDictionary(System.Type,System.Object,Meta.WitAi.Json.WitResponseClass,System.Text.StringBuilder,Meta.WitAi.Json.JsonConverter[])
extern void JsonConvert_DeserializeDictionary_mA7E4F44E2ACDAA268D06F84E1DC102C0E55FF3D6 (void);
// 0x000000AD System.String Meta.WitAi.Json.JsonConvert::SerializeObject(FROM_TYPE,Meta.WitAi.Json.JsonConverter[])
// 0x000000AE Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.JsonConvert::SerializeToken(FROM_TYPE,Meta.WitAi.Json.JsonConverter[])
// 0x000000AF Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.JsonConvert::SerializeToken(System.Type,System.Object,System.Text.StringBuilder,Meta.WitAi.Json.JsonConverter[])
extern void JsonConvert_SerializeToken_m499F2E95B66CA5D5A475E39F246FDF7B38F76E2C (void);
// 0x000000B0 System.Void Meta.WitAi.Json.JsonConvert::.cctor()
extern void JsonConvert__cctor_m6D4C1F52D3F436CC44218A44E41B9B8C90180487 (void);
// 0x000000B1 System.Void Meta.WitAi.Json.JsonConvert/<>c__DisplayClass6_0`1::.ctor()
// 0x000000B2 System.Boolean Meta.WitAi.Json.JsonConvert/<>c__DisplayClass6_0`1::<DeserializeObjectAsync>b__0()
// 0x000000B3 System.Void Meta.WitAi.Json.JsonConvert/<>c__DisplayClass6_0`1::<DeserializeObjectAsync>b__1(System.Boolean)
// 0x000000B4 System.Void Meta.WitAi.Json.JsonConvert/<>c__DisplayClass7_0`1::.ctor()
// 0x000000B5 System.Boolean Meta.WitAi.Json.JsonConvert/<>c__DisplayClass7_0`1::<DeserializeObjectAsync>b__0()
// 0x000000B6 System.Void Meta.WitAi.Json.JsonConvert/<>c__DisplayClass7_0`1::<DeserializeObjectAsync>b__1(System.Boolean)
// 0x000000B7 System.Void Meta.WitAi.Json.JsonConvert/<>c::.cctor()
extern void U3CU3Ec__cctor_m18BB15DA8C7F86F1036DF10049A047FF13949A78 (void);
// 0x000000B8 System.Void Meta.WitAi.Json.JsonConvert/<>c::.ctor()
extern void U3CU3Ec__ctor_mEF36652F13BCFC1EC3AE5783EE338870E2F79AE9 (void);
// 0x000000B9 System.Boolean Meta.WitAi.Json.JsonConvert/<>c::<DeserializeEnum>b__14_0(System.Reflection.MethodInfo)
extern void U3CU3Ec_U3CDeserializeEnumU3Eb__14_0_m60DF2C4DC62E88858ABC926EAE01C06A425115C9 (void);
// 0x000000BA System.Boolean Meta.WitAi.Json.JsonConvert/<>c::<DeserializeClass>b__16_0(System.Reflection.FieldInfo)
extern void U3CU3Ec_U3CDeserializeClassU3Eb__16_0_mCE6A239BE0087BE70D131DE1473A3DC22FF63A4E (void);
// 0x000000BB System.Boolean Meta.WitAi.Json.JsonConvert/<>c::<DeserializeClass>b__16_1(System.Reflection.PropertyInfo)
extern void U3CU3Ec_U3CDeserializeClassU3Eb__16_1_mB6DAB0BC584FA4777AC92B2DFF8056CF69BA3FA6 (void);
// 0x000000BC System.Boolean Meta.WitAi.Json.JsonConverter::get_CanRead()
extern void JsonConverter_get_CanRead_m0D0337361BBA3C6ABA3D3F1A3199347F433F6781 (void);
// 0x000000BD System.Boolean Meta.WitAi.Json.JsonConverter::get_CanWrite()
extern void JsonConverter_get_CanWrite_m5232AD00808BC3A406EFEFA603473DFE82A1AC72 (void);
// 0x000000BE System.Boolean Meta.WitAi.Json.JsonConverter::CanConvert(System.Type)
// 0x000000BF System.Object Meta.WitAi.Json.JsonConverter::ReadJson(Meta.WitAi.Json.WitResponseNode,System.Type,System.Object)
extern void JsonConverter_ReadJson_m8F6B56995D06D9A0C05364EE37537BFD3453991F (void);
// 0x000000C0 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.JsonConverter::WriteJson(System.Object)
extern void JsonConverter_WriteJson_mDE8DB3BAD12B58DC79FC6EEDBDA2C470E2BF485E (void);
// 0x000000C1 System.Void Meta.WitAi.Json.JsonConverter::.ctor()
extern void JsonConverter__ctor_mC9121064B1F93F5E907EDF233D40EC0CBC302B25 (void);
// 0x000000C2 System.String Meta.WitAi.Json.JsonPropertyAttribute::get_PropertyName()
extern void JsonPropertyAttribute_get_PropertyName_mEF2DC572AB5568F23749E61FF62E92A5748A0121 (void);
// 0x000000C3 System.Void Meta.WitAi.Json.JsonPropertyAttribute::set_PropertyName(System.String)
extern void JsonPropertyAttribute_set_PropertyName_mB079F70AD0296B76D4B8395B43DDC8F2CEDAFDBA (void);
// 0x000000C4 System.Object Meta.WitAi.Json.JsonPropertyAttribute::get_DefaultValue()
extern void JsonPropertyAttribute_get_DefaultValue_mD78E689C9EC517AFCA4E0F8E606062824E075FDA (void);
// 0x000000C5 System.Void Meta.WitAi.Json.JsonPropertyAttribute::set_DefaultValue(System.Object)
extern void JsonPropertyAttribute_set_DefaultValue_m51A3B98B7F4DB29DF9E1EAD8DAE8FEE346E2DF7E (void);
// 0x000000C6 System.Void Meta.WitAi.Json.JsonPropertyAttribute::.ctor(System.String)
extern void JsonPropertyAttribute__ctor_m4F66BBBF83BC759671E7923AA3E780DAA4E7E94F (void);
// 0x000000C7 System.Void Meta.WitAi.Json.JsonPropertyAttribute::.ctor(System.String,System.Object)
extern void JsonPropertyAttribute__ctor_m46B867941D1D018F5A4EEA7F14F259B229753B83 (void);
// 0x000000C8 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseJson::Parse(System.String)
extern void WitResponseJson_Parse_mE417A7A09EAD7189E912086EF8DEE9DFE4A6567B (void);
// 0x000000C9 System.Void Meta.WitAi.Json.WitResponseNode::Add(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_Add_m29D8906DA4C698B7D80F1F86DB1CE904C4B6D030 (void);
// 0x000000CA Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::get_Item(System.Int32)
extern void WitResponseNode_get_Item_mEB5205FD8A42FA9B270F1B9B96937CBF8EE184B2 (void);
// 0x000000CB System.Void Meta.WitAi.Json.WitResponseNode::set_Item(System.Int32,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_set_Item_mECAC385EB82F5273D6B28B187693E96110155548 (void);
// 0x000000CC Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::get_Item(System.String)
extern void WitResponseNode_get_Item_m5BF8C3A148006635AB42BB486B08FAA1C26575BF (void);
// 0x000000CD System.Void Meta.WitAi.Json.WitResponseNode::set_Item(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_set_Item_m0C3DDE61566EAD1E55DFF684A034A8A49DD542DD (void);
// 0x000000CE System.String Meta.WitAi.Json.WitResponseNode::get_Value()
extern void WitResponseNode_get_Value_m40A3D728DC3D7129DB7A3152B691836F67CDCC78 (void);
// 0x000000CF System.Void Meta.WitAi.Json.WitResponseNode::set_Value(System.String)
extern void WitResponseNode_set_Value_m580C71D577A96A750E21671793B6ED44A66716CA (void);
// 0x000000D0 System.Int32 Meta.WitAi.Json.WitResponseNode::get_Count()
extern void WitResponseNode_get_Count_mA9EBE5B8F8170D7ED335A273E9C50A4F7B91EDFE (void);
// 0x000000D1 System.Void Meta.WitAi.Json.WitResponseNode::Add(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_Add_mB8A4565AFD7F3697C8599E96DA4C00B2B372C20D (void);
// 0x000000D2 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::Remove(System.String)
extern void WitResponseNode_Remove_mF641E5E61801FAB44770E3A473CB94F2D207A15C (void);
// 0x000000D3 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::Remove(System.Int32)
extern void WitResponseNode_Remove_mA5DA9B1052B0FB5E5615A05DB1747ADAD78C0FB3 (void);
// 0x000000D4 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::Remove(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_Remove_m12C1A50193247D3EBD2E8B33710DA2DD9842FE30 (void);
// 0x000000D5 System.Collections.Generic.IEnumerable`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseNode::get_Childs()
extern void WitResponseNode_get_Childs_m717121EAB7095B6F617F93ADD6872A92674707AA (void);
// 0x000000D6 System.Collections.Generic.IEnumerable`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseNode::get_DeepChilds()
extern void WitResponseNode_get_DeepChilds_m3C8A1D680D6D2D65025EDBD017E695EBA09FAFF5 (void);
// 0x000000D7 System.String Meta.WitAi.Json.WitResponseNode::ToString()
extern void WitResponseNode_ToString_m3D445D2CF30C85801A49605C4C6A5C1712F793B4 (void);
// 0x000000D8 System.String Meta.WitAi.Json.WitResponseNode::ToString(System.String)
extern void WitResponseNode_ToString_m66D87595107D7F314691209D8B44F1203279F05C (void);
// 0x000000D9 System.Int32 Meta.WitAi.Json.WitResponseNode::get_AsInt()
extern void WitResponseNode_get_AsInt_m024AA9F3EC47061E2381DFBCEBC26371C451B5CF (void);
// 0x000000DA System.Void Meta.WitAi.Json.WitResponseNode::set_AsInt(System.Int32)
extern void WitResponseNode_set_AsInt_m33831C323A76432BEABE58F8E35CEA90F5445735 (void);
// 0x000000DB System.Single Meta.WitAi.Json.WitResponseNode::get_AsFloat()
extern void WitResponseNode_get_AsFloat_m927097B265B30F942C3A6857847665FE235787B9 (void);
// 0x000000DC System.Void Meta.WitAi.Json.WitResponseNode::set_AsFloat(System.Single)
extern void WitResponseNode_set_AsFloat_mF8F2BC7C194229DFB33094BCBCF9A197F6C6C588 (void);
// 0x000000DD System.Double Meta.WitAi.Json.WitResponseNode::get_AsDouble()
extern void WitResponseNode_get_AsDouble_mE345478726534C4A90DB6A112C31A750791E88EC (void);
// 0x000000DE System.Void Meta.WitAi.Json.WitResponseNode::set_AsDouble(System.Double)
extern void WitResponseNode_set_AsDouble_m752E687B6F5B140AB053C4FBAB0DCB27C89676D6 (void);
// 0x000000DF System.Boolean Meta.WitAi.Json.WitResponseNode::get_AsBool()
extern void WitResponseNode_get_AsBool_m6DC15B28EDFB12DBDB8FF8E30B51DC7A6AAC5F28 (void);
// 0x000000E0 System.Void Meta.WitAi.Json.WitResponseNode::set_AsBool(System.Boolean)
extern void WitResponseNode_set_AsBool_m0DD7E58848900E2EEDD53A49D0681B089913CF39 (void);
// 0x000000E1 Meta.WitAi.Json.WitResponseArray Meta.WitAi.Json.WitResponseNode::get_AsArray()
extern void WitResponseNode_get_AsArray_m784676147F5A1FCE06852FA64F7734238B336CEF (void);
// 0x000000E2 System.String[] Meta.WitAi.Json.WitResponseNode::get_AsStringArray()
extern void WitResponseNode_get_AsStringArray_m1929B213720A7A709E34179350673BE6C4F98472 (void);
// 0x000000E3 Meta.WitAi.Json.WitResponseClass Meta.WitAi.Json.WitResponseNode::get_AsObject()
extern void WitResponseNode_get_AsObject_m75B873A53748CE15CDD14FE1C68EAE8586D752C9 (void);
// 0x000000E4 T Meta.WitAi.Json.WitResponseNode::Cast(T)
// 0x000000E5 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::op_Implicit(System.String)
extern void WitResponseNode_op_Implicit_mB8EA8AF87370B2ED8C8D42BD96FFCF7734294FAC (void);
// 0x000000E6 System.String Meta.WitAi.Json.WitResponseNode::op_Implicit(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseNode_op_Implicit_m7AC5695C8699C246F516A32BB3654EED5A6D8911 (void);
// 0x000000E7 System.Boolean Meta.WitAi.Json.WitResponseNode::op_Equality(Meta.WitAi.Json.WitResponseNode,System.Object)
extern void WitResponseNode_op_Equality_m556CA10A38D4323CB11BF6BD64A0A22FA5055366 (void);
// 0x000000E8 System.Boolean Meta.WitAi.Json.WitResponseNode::op_Inequality(Meta.WitAi.Json.WitResponseNode,System.Object)
extern void WitResponseNode_op_Inequality_mB890519AF1C832EC1EEB1644A5B0E1D0F4C324F9 (void);
// 0x000000E9 System.Boolean Meta.WitAi.Json.WitResponseNode::Equals(System.Object)
extern void WitResponseNode_Equals_mFF70A626804C0712E4D98F3937EF5E3CC69B32A8 (void);
// 0x000000EA System.Int32 Meta.WitAi.Json.WitResponseNode::GetHashCode()
extern void WitResponseNode_GetHashCode_mAC54EE6F975835618C3E065D237A5D106CFAAC41 (void);
// 0x000000EB System.String Meta.WitAi.Json.WitResponseNode::Escape(System.String)
extern void WitResponseNode_Escape_m03F6DE13A95DD1A8C2B25E414A12A22FC14A1B4B (void);
// 0x000000EC Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::Parse(System.String)
extern void WitResponseNode_Parse_m7FC8CFF3EFB9D3B0F1BD5F6F0757035F86252542 (void);
// 0x000000ED System.Void Meta.WitAi.Json.WitResponseNode::Serialize(System.IO.BinaryWriter)
extern void WitResponseNode_Serialize_m230A781CE376919326F281846377306B8057A875 (void);
// 0x000000EE System.Void Meta.WitAi.Json.WitResponseNode::SaveToStream(System.IO.Stream)
extern void WitResponseNode_SaveToStream_m6C31F731D7150456EEB45235903258F26837C0D9 (void);
// 0x000000EF System.Void Meta.WitAi.Json.WitResponseNode::SaveToCompressedStream(System.IO.Stream)
extern void WitResponseNode_SaveToCompressedStream_m86FA6AEB787FB004374E62C0127DFF0A0F611C3E (void);
// 0x000000F0 System.Void Meta.WitAi.Json.WitResponseNode::SaveToCompressedFile(System.String)
extern void WitResponseNode_SaveToCompressedFile_m7B619C8603B7F32454D68231DC19B618E6C0BEFB (void);
// 0x000000F1 System.String Meta.WitAi.Json.WitResponseNode::SaveToCompressedBase64()
extern void WitResponseNode_SaveToCompressedBase64_m773829A70940A5D40CA31E08EB826FDA126890FA (void);
// 0x000000F2 System.Void Meta.WitAi.Json.WitResponseNode::SaveToFile(System.String)
extern void WitResponseNode_SaveToFile_m77E5FD343DAF070D7FF77345FB81C73497F704B8 (void);
// 0x000000F3 System.String Meta.WitAi.Json.WitResponseNode::SaveToBase64()
extern void WitResponseNode_SaveToBase64_mE3EB208A8BDF11697043FBA4849F29DB2A3526D8 (void);
// 0x000000F4 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::Deserialize(System.IO.BinaryReader)
extern void WitResponseNode_Deserialize_m138FA55DE68097AD00A894664114EB24A80E9CE0 (void);
// 0x000000F5 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromCompressedFile(System.String)
extern void WitResponseNode_LoadFromCompressedFile_mCA796D8F6202FE12C5F1290BAF702BC312AEDC4E (void);
// 0x000000F6 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromCompressedStream(System.IO.Stream)
extern void WitResponseNode_LoadFromCompressedStream_m2320AA646A68CC5EE0757B20EB328EA31DFB83C8 (void);
// 0x000000F7 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromCompressedBase64(System.String)
extern void WitResponseNode_LoadFromCompressedBase64_m549D1E7330369806CE3E33DC840A11D633D4DB22 (void);
// 0x000000F8 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromStream(System.IO.Stream)
extern void WitResponseNode_LoadFromStream_m13BB986ADE0374D27FD1629B1B90D72E23C10C6A (void);
// 0x000000F9 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromFile(System.String)
extern void WitResponseNode_LoadFromFile_m4CC0694987F0E8F7C86FC979466A248D5E18B32E (void);
// 0x000000FA Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode::LoadFromBase64(System.String)
extern void WitResponseNode_LoadFromBase64_mBE7314EAE256D8CB3AD615BD03649410041AA556 (void);
// 0x000000FB System.Void Meta.WitAi.Json.WitResponseNode::.ctor()
extern void WitResponseNode__ctor_mC4FB7662DDD3350001A2B6B50931748A05953B7B (void);
// 0x000000FC System.Void Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::.ctor(System.Int32)
extern void U3Cget_ChildsU3Ed__17__ctor_m7A92E3693E17CE7E6D1E5692F8C4959A9A711C2A (void);
// 0x000000FD System.Void Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.IDisposable.Dispose()
extern void U3Cget_ChildsU3Ed__17_System_IDisposable_Dispose_m6DDF83606276C09F26793524996CFCB0A7D9897C (void);
// 0x000000FE System.Boolean Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::MoveNext()
extern void U3Cget_ChildsU3Ed__17_MoveNext_m5516806BD78EDD680ED67BD5D9CBF1B8FCDA79B4 (void);
// 0x000000FF Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.Collections.Generic.IEnumerator<Meta.WitAi.Json.WitResponseNode>.get_Current()
extern void U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_m826F96A6640F68D994863FA335F1AB2719B4A9E8 (void);
// 0x00000100 System.Void Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_Reset_mC9F5BF2729285825E48FFD4D56AB280FF9AE20C0 (void);
// 0x00000101 System.Object Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_get_Current_m9684938739FB25877D5A1B6376ACFF90702617AE (void);
// 0x00000102 System.Collections.Generic.IEnumerator`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.Collections.Generic.IEnumerable<Meta.WitAi.Json.WitResponseNode>.GetEnumerator()
extern void U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m638574D9566D546CE1FA8156C49E622271A69E04 (void);
// 0x00000103 System.Collections.IEnumerator Meta.WitAi.Json.WitResponseNode/<get_Childs>d__17::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerable_GetEnumerator_m55CF60E5AAC2740B8806D8798993F4307585B275 (void);
// 0x00000104 System.Void Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::.ctor(System.Int32)
extern void U3Cget_DeepChildsU3Ed__19__ctor_m1ECA6AF267714944E0D88CC844C3024481B0C6F9 (void);
// 0x00000105 System.Void Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.IDisposable.Dispose()
extern void U3Cget_DeepChildsU3Ed__19_System_IDisposable_Dispose_m057C39F716CCFCB6EC09EB570622F3283AFC99A6 (void);
// 0x00000106 System.Boolean Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::MoveNext()
extern void U3Cget_DeepChildsU3Ed__19_MoveNext_mD05A17730B6D957244157C241083B484C0DDDE01 (void);
// 0x00000107 System.Void Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::<>m__Finally1()
extern void U3Cget_DeepChildsU3Ed__19_U3CU3Em__Finally1_m34EAF3C3EC3B5B50FBF66D3443C53572CAE2AFC9 (void);
// 0x00000108 System.Void Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::<>m__Finally2()
extern void U3Cget_DeepChildsU3Ed__19_U3CU3Em__Finally2_m734B4CEBA5FDA07D95296334838EF75AC796F34E (void);
// 0x00000109 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.Collections.Generic.IEnumerator<Meta.WitAi.Json.WitResponseNode>.get_Current()
extern void U3Cget_DeepChildsU3Ed__19_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_m82AA5AA38BCD89F425BFF1EA4553BFADFED80E61 (void);
// 0x0000010A System.Void Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.Collections.IEnumerator.Reset()
extern void U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerator_Reset_mFA4A0BF498C57BA45D789E929AFC71BF61DAC90B (void);
// 0x0000010B System.Object Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.Collections.IEnumerator.get_Current()
extern void U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerator_get_Current_m7A12CA35475E08BE8DC3ABB2DA8E7F4CC1E6E13F (void);
// 0x0000010C System.Collections.Generic.IEnumerator`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.Collections.Generic.IEnumerable<Meta.WitAi.Json.WitResponseNode>.GetEnumerator()
extern void U3Cget_DeepChildsU3Ed__19_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m974C9CD69CAC6CC231D47EF095087FB6AE3A3657 (void);
// 0x0000010D System.Collections.IEnumerator Meta.WitAi.Json.WitResponseNode/<get_DeepChilds>d__19::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerable_GetEnumerator_mE964ED7F36A034A941050E850DB5B296CCB36389 (void);
// 0x0000010E Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseArray::get_Item(System.Int32)
extern void WitResponseArray_get_Item_m927FFFE46DFDC0803F897C7396D30221080C61A7 (void);
// 0x0000010F System.Void Meta.WitAi.Json.WitResponseArray::set_Item(System.Int32,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseArray_set_Item_m27C3BAB5EA3B1BB4FEDCE88FA6873663982991BB (void);
// 0x00000110 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseArray::get_Item(System.String)
extern void WitResponseArray_get_Item_m7B53C8F8BD9A22A65F68218727330CFC8F3AF58D (void);
// 0x00000111 System.Void Meta.WitAi.Json.WitResponseArray::set_Item(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseArray_set_Item_mCDBFCE84ADABB704F25DBBF960E27DCA38294465 (void);
// 0x00000112 System.Int32 Meta.WitAi.Json.WitResponseArray::get_Count()
extern void WitResponseArray_get_Count_m3C0846E5646C8FDDBBCCEF276B524D13AAB658DA (void);
// 0x00000113 System.Void Meta.WitAi.Json.WitResponseArray::Add(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseArray_Add_mDC72A2B60BF5E3C870CBD364F9E10FD0B46BF5D8 (void);
// 0x00000114 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseArray::Remove(System.Int32)
extern void WitResponseArray_Remove_m9D56D4CF28E1912CE311E2BF41042219C2869CF4 (void);
// 0x00000115 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseArray::Remove(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseArray_Remove_mF9D743830FBFE9B3722661915ABB3E6013C9D69A (void);
// 0x00000116 System.Collections.Generic.IEnumerable`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseArray::get_Childs()
extern void WitResponseArray_get_Childs_m574A7FD2693EA36AFFD83098FEF5A8302C04272D (void);
// 0x00000117 System.Collections.IEnumerator Meta.WitAi.Json.WitResponseArray::GetEnumerator()
extern void WitResponseArray_GetEnumerator_mE3D7CAB439F65B7778D55123748DFC6C515D6026 (void);
// 0x00000118 System.String Meta.WitAi.Json.WitResponseArray::ToString()
extern void WitResponseArray_ToString_mDA58401450439B53B96BCA568DEEA801743A22AD (void);
// 0x00000119 System.String Meta.WitAi.Json.WitResponseArray::ToString(System.String)
extern void WitResponseArray_ToString_m9E2A94668564EF25411A7BD98961CD4E4B05F6A1 (void);
// 0x0000011A System.Void Meta.WitAi.Json.WitResponseArray::Serialize(System.IO.BinaryWriter)
extern void WitResponseArray_Serialize_mD50F05A3ADB0F34EA23332AA32FC54254AEF5589 (void);
// 0x0000011B System.Void Meta.WitAi.Json.WitResponseArray::.ctor()
extern void WitResponseArray__ctor_m721A235EE997F78DFEBD437510486DE59A685F55 (void);
// 0x0000011C System.Void Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::.ctor(System.Int32)
extern void U3Cget_ChildsU3Ed__13__ctor_m429A0436140CAAC11D1FEC5AE457F973E5CBCE81 (void);
// 0x0000011D System.Void Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.IDisposable.Dispose()
extern void U3Cget_ChildsU3Ed__13_System_IDisposable_Dispose_m77150F5238147EF1A1123553B144D32384FDF041 (void);
// 0x0000011E System.Boolean Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::MoveNext()
extern void U3Cget_ChildsU3Ed__13_MoveNext_mED66E2F0C7AC042B0DDA325CE0A625CCE9F84629 (void);
// 0x0000011F System.Void Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::<>m__Finally1()
extern void U3Cget_ChildsU3Ed__13_U3CU3Em__Finally1_mC36DE4425B467C1530E7B63FAFF3953BCB0F5A4A (void);
// 0x00000120 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.Collections.Generic.IEnumerator<Meta.WitAi.Json.WitResponseNode>.get_Current()
extern void U3Cget_ChildsU3Ed__13_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_mCCA6C7443157D72D027788498250E4190F7588BB (void);
// 0x00000121 System.Void Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildsU3Ed__13_System_Collections_IEnumerator_Reset_m951018C550B587C6BC6EB1028EA39DD11B9BFDF3 (void);
// 0x00000122 System.Object Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildsU3Ed__13_System_Collections_IEnumerator_get_Current_m15D840D5299CA52E41DFC537BBCA8114DFF3340B (void);
// 0x00000123 System.Collections.Generic.IEnumerator`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.Collections.Generic.IEnumerable<Meta.WitAi.Json.WitResponseNode>.GetEnumerator()
extern void U3Cget_ChildsU3Ed__13_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m5F25DA4843C4E27A1832287B6A8C0E97E2E900C6 (void);
// 0x00000124 System.Collections.IEnumerator Meta.WitAi.Json.WitResponseArray/<get_Childs>d__13::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildsU3Ed__13_System_Collections_IEnumerable_GetEnumerator_m0D4D4A2C8508D22357D51157A1DD0865F7562297 (void);
// 0x00000125 System.Void Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::.ctor(System.Int32)
extern void U3CGetEnumeratorU3Ed__14__ctor_m3E2ECECCB821D8BC7EC4F6AC5AA5266317FB0363 (void);
// 0x00000126 System.Void Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::System.IDisposable.Dispose()
extern void U3CGetEnumeratorU3Ed__14_System_IDisposable_Dispose_m8B46DC03D65B315AF464114378C6E71C2268AFD7 (void);
// 0x00000127 System.Boolean Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::MoveNext()
extern void U3CGetEnumeratorU3Ed__14_MoveNext_m3ACEEE39EBBE063061A2E69B85883B999B0BAA78 (void);
// 0x00000128 System.Void Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::<>m__Finally1()
extern void U3CGetEnumeratorU3Ed__14_U3CU3Em__Finally1_mE7D3B2D552B46B7CE8FC72BF74533B5957F988E7 (void);
// 0x00000129 System.Object Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CGetEnumeratorU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC7CE42F21A88CC604C4EE5C5F806AB3D537F3438 (void);
// 0x0000012A System.Void Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::System.Collections.IEnumerator.Reset()
extern void U3CGetEnumeratorU3Ed__14_System_Collections_IEnumerator_Reset_m630CFD8E7B2F011E087BBD24EDA563AC94B3D181 (void);
// 0x0000012B System.Object Meta.WitAi.Json.WitResponseArray/<GetEnumerator>d__14::System.Collections.IEnumerator.get_Current()
extern void U3CGetEnumeratorU3Ed__14_System_Collections_IEnumerator_get_Current_mBB676A0A25E054C8115154F7F3BA5FE44EDF1CE3 (void);
// 0x0000012C System.String[] Meta.WitAi.Json.WitResponseClass::get_ChildNodeNames()
extern void WitResponseClass_get_ChildNodeNames_m17643A6B0646BB4C0432A7ABE39A0EEE0FFA09FC (void);
// 0x0000012D System.Boolean Meta.WitAi.Json.WitResponseClass::HasChild(System.String)
extern void WitResponseClass_HasChild_mA300E73E9D4346D21FEDDC071B2D52538625A3FB (void);
// 0x0000012E Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass::get_Item(System.String)
extern void WitResponseClass_get_Item_m46C1E02FA07F165B10C5E55B22329F77C83F66CB (void);
// 0x0000012F System.Void Meta.WitAi.Json.WitResponseClass::set_Item(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseClass_set_Item_mB95FE232445471A1C68C8FF19CC1C361F9619E68 (void);
// 0x00000130 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass::get_Item(System.Int32)
extern void WitResponseClass_get_Item_m789E7BBCFB8C73602AEE9B3DA54628A03B15A74B (void);
// 0x00000131 System.Void Meta.WitAi.Json.WitResponseClass::set_Item(System.Int32,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseClass_set_Item_m559D8991F4C5F4F3830D9CB5267DCEE5006A3504 (void);
// 0x00000132 System.Int32 Meta.WitAi.Json.WitResponseClass::get_Count()
extern void WitResponseClass_get_Count_m04014274AF6AFFDB69D92A954D5666387C67A8F1 (void);
// 0x00000133 System.Void Meta.WitAi.Json.WitResponseClass::Add(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseClass_Add_m6561A55FFA76C268F5261E171853D5AB24FCBFB4 (void);
// 0x00000134 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass::Remove(System.String)
extern void WitResponseClass_Remove_m33C6F72D72F766ACF1081F8074C03F93409AE943 (void);
// 0x00000135 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass::Remove(System.Int32)
extern void WitResponseClass_Remove_mE01845757C9328C5CE82EE0F80899EE2483B6D76 (void);
// 0x00000136 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass::Remove(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseClass_Remove_m9BACA15EB93394E290B3854D2966110EA189F5FE (void);
// 0x00000137 System.Collections.Generic.IEnumerable`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseClass::get_Childs()
extern void WitResponseClass_get_Childs_mBF1BBBEFE5A4FB7B1D05B526034C9EC7372C1A27 (void);
// 0x00000138 System.Collections.IEnumerator Meta.WitAi.Json.WitResponseClass::GetEnumerator()
extern void WitResponseClass_GetEnumerator_m50FF38C23BACEA00930A2BE4E5789E20DDA5F3FB (void);
// 0x00000139 T Meta.WitAi.Json.WitResponseClass::GetChild(System.String,T)
// 0x0000013A System.String Meta.WitAi.Json.WitResponseClass::ToString()
extern void WitResponseClass_ToString_m88D914030920CBA87C43C06976D5FF9539718486 (void);
// 0x0000013B System.String Meta.WitAi.Json.WitResponseClass::ToString(System.String)
extern void WitResponseClass_ToString_m00C5C60A74D446F1FA202ABBEA9A9D754D4EDD8F (void);
// 0x0000013C System.Void Meta.WitAi.Json.WitResponseClass::Serialize(System.IO.BinaryWriter)
extern void WitResponseClass_Serialize_mBA795A5A5945066A8BE18B572B5D781FE932434D (void);
// 0x0000013D System.Void Meta.WitAi.Json.WitResponseClass::.ctor()
extern void WitResponseClass__ctor_mAD6E312EBFEC01A4819A7AF57D2E0D98163AAD47 (void);
// 0x0000013E System.Void Meta.WitAi.Json.WitResponseClass/<>c__DisplayClass15_0::.ctor()
extern void U3CU3Ec__DisplayClass15_0__ctor_m70566E35212CD98AC59D425A2CF4832FEC0F9F94 (void);
// 0x0000013F System.Boolean Meta.WitAi.Json.WitResponseClass/<>c__DisplayClass15_0::<Remove>b__0(System.Collections.Generic.KeyValuePair`2<System.String,Meta.WitAi.Json.WitResponseNode>)
extern void U3CU3Ec__DisplayClass15_0_U3CRemoveU3Eb__0_mAD41BE11BCE3E900BFC3DCF57DF0CDCEB67618BB (void);
// 0x00000140 System.Void Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::.ctor(System.Int32)
extern void U3Cget_ChildsU3Ed__17__ctor_m12B9ABD0288987CD61E2BA7D036767AE1BF4D0BE (void);
// 0x00000141 System.Void Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.IDisposable.Dispose()
extern void U3Cget_ChildsU3Ed__17_System_IDisposable_Dispose_m251435C763D9BD1F83DA693B60652B15C0D6412B (void);
// 0x00000142 System.Boolean Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::MoveNext()
extern void U3Cget_ChildsU3Ed__17_MoveNext_m6EDCA79501326B1ABA3BAC7D4CA09CCC28CE5F58 (void);
// 0x00000143 System.Void Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::<>m__Finally1()
extern void U3Cget_ChildsU3Ed__17_U3CU3Em__Finally1_m0CEC896D7B08ACC1EE2FD7E652B9E7F0C034A3CC (void);
// 0x00000144 Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.Collections.Generic.IEnumerator<Meta.WitAi.Json.WitResponseNode>.get_Current()
extern void U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_mB3A70175F3C17A89A9797E27574A99B95C0D7B6D (void);
// 0x00000145 System.Void Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_Reset_mE1C1598BCB643AE91F487DFDC674CCB620D50099 (void);
// 0x00000146 System.Object Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_get_Current_mCD4D28D5213447AC15E46908877BDCBDFEF0FE41 (void);
// 0x00000147 System.Collections.Generic.IEnumerator`1<Meta.WitAi.Json.WitResponseNode> Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.Collections.Generic.IEnumerable<Meta.WitAi.Json.WitResponseNode>.GetEnumerator()
extern void U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_mB45B52244BD5D55A8882EEDEEA2537D9CDF73038 (void);
// 0x00000148 System.Collections.IEnumerator Meta.WitAi.Json.WitResponseClass/<get_Childs>d__17::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildsU3Ed__17_System_Collections_IEnumerable_GetEnumerator_mA94336900DAAE3CBBBB867857026C11EEDED92BC (void);
// 0x00000149 System.Void Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::.ctor(System.Int32)
extern void U3CGetEnumeratorU3Ed__18__ctor_m76216DA4E7DA7307BEAD2051640156E3FF114BAC (void);
// 0x0000014A System.Void Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::System.IDisposable.Dispose()
extern void U3CGetEnumeratorU3Ed__18_System_IDisposable_Dispose_m4C26F7E170E59A2FFB51CC5EA1C9E4B3FAB74013 (void);
// 0x0000014B System.Boolean Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::MoveNext()
extern void U3CGetEnumeratorU3Ed__18_MoveNext_m924931A590B530D38EE346F596B85484107A43A2 (void);
// 0x0000014C System.Void Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::<>m__Finally1()
extern void U3CGetEnumeratorU3Ed__18_U3CU3Em__Finally1_m8E677E16C3DA39A359DDD922234114FD8FE583CF (void);
// 0x0000014D System.Object Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CGetEnumeratorU3Ed__18_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC2BDB5B90BCC1F22D345F711D64DD290BC239A7D (void);
// 0x0000014E System.Void Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::System.Collections.IEnumerator.Reset()
extern void U3CGetEnumeratorU3Ed__18_System_Collections_IEnumerator_Reset_m04F4FC789272FD7A8ABE9AD024086B4594C2594A (void);
// 0x0000014F System.Object Meta.WitAi.Json.WitResponseClass/<GetEnumerator>d__18::System.Collections.IEnumerator.get_Current()
extern void U3CGetEnumeratorU3Ed__18_System_Collections_IEnumerator_get_Current_m79C6A5ACEEAB2BB4A1DF627A2D8AF060A24B5BAE (void);
// 0x00000150 System.String Meta.WitAi.Json.WitResponseData::get_Value()
extern void WitResponseData_get_Value_m0975849486729B3D273D4E37707F857C5D6FFC02 (void);
// 0x00000151 System.Void Meta.WitAi.Json.WitResponseData::set_Value(System.String)
extern void WitResponseData_set_Value_m95872341BCA728770E707806BD3E27AC58B4F8A4 (void);
// 0x00000152 System.Void Meta.WitAi.Json.WitResponseData::.ctor(System.String)
extern void WitResponseData__ctor_mC5CAD7423156DB2AFA917797D3C239BDF94A0BAD (void);
// 0x00000153 System.Void Meta.WitAi.Json.WitResponseData::.ctor(System.Single)
extern void WitResponseData__ctor_mF2E1CC4ECA3A729D104130CCB5CCB873C75F86C2 (void);
// 0x00000154 System.Void Meta.WitAi.Json.WitResponseData::.ctor(System.Double)
extern void WitResponseData__ctor_mC9CE8379EAC42B7F85910B573447E05117CE2A81 (void);
// 0x00000155 System.Void Meta.WitAi.Json.WitResponseData::.ctor(System.Boolean)
extern void WitResponseData__ctor_m61443D4A59044E96DC07C970FD2C03C7F9F7F782 (void);
// 0x00000156 System.Void Meta.WitAi.Json.WitResponseData::.ctor(System.Int32)
extern void WitResponseData__ctor_m0A2E4A8270DB755B5D7172F178890C323FB22290 (void);
// 0x00000157 System.String Meta.WitAi.Json.WitResponseData::ToString()
extern void WitResponseData_ToString_m7093EC5D51B180ECA77D88196C00FB4FCE9BE5D2 (void);
// 0x00000158 System.String Meta.WitAi.Json.WitResponseData::ToString(System.String)
extern void WitResponseData_ToString_m8E4076FBB7CE6838EA2F55F39E6740929581967E (void);
// 0x00000159 System.Void Meta.WitAi.Json.WitResponseData::Serialize(System.IO.BinaryWriter)
extern void WitResponseData_Serialize_m96CF5AC981F31FD000115E5BCE1CB79737369BA0 (void);
// 0x0000015A System.Void Meta.WitAi.Json.WitResponseLazyCreator::.ctor(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator__ctor_mDABB3CE3048D2FB3FC72597DF35ABD46824DC7B6 (void);
// 0x0000015B System.Void Meta.WitAi.Json.WitResponseLazyCreator::.ctor(Meta.WitAi.Json.WitResponseNode,System.String)
extern void WitResponseLazyCreator__ctor_m806225C5DE01971257BC07EEFBD8D5FCD2522175 (void);
// 0x0000015C System.Void Meta.WitAi.Json.WitResponseLazyCreator::Set(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator_Set_mE5ED8C6DDB40D47373E29A6F3CE3FD453FA21458 (void);
// 0x0000015D Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseLazyCreator::get_Item(System.Int32)
extern void WitResponseLazyCreator_get_Item_m10F2D23CB786080CCE534BAC1527D7AB606C71CB (void);
// 0x0000015E System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_Item(System.Int32,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator_set_Item_m79594FDE487845703B9B7F79323FC6310C11620D (void);
// 0x0000015F Meta.WitAi.Json.WitResponseNode Meta.WitAi.Json.WitResponseLazyCreator::get_Item(System.String)
extern void WitResponseLazyCreator_get_Item_m0FFB198C00D3D5EC389B69C30AE09AF06586C631 (void);
// 0x00000160 System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_Item(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator_set_Item_m725459A2CE4DFABF6820B5363B6C436A0F84DE10 (void);
// 0x00000161 System.Void Meta.WitAi.Json.WitResponseLazyCreator::Add(Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator_Add_m9FF2438CD8A3F7C63F039757C9DC452AEB349D7B (void);
// 0x00000162 System.Void Meta.WitAi.Json.WitResponseLazyCreator::Add(System.String,Meta.WitAi.Json.WitResponseNode)
extern void WitResponseLazyCreator_Add_mCEF57F8B2B20499AA785B8368B76CA34057DCC37 (void);
// 0x00000163 System.Boolean Meta.WitAi.Json.WitResponseLazyCreator::op_Equality(Meta.WitAi.Json.WitResponseLazyCreator,System.Object)
extern void WitResponseLazyCreator_op_Equality_m33785B9091FDDFD763DC36859F395F6125DC484F (void);
// 0x00000164 System.Boolean Meta.WitAi.Json.WitResponseLazyCreator::op_Inequality(Meta.WitAi.Json.WitResponseLazyCreator,System.Object)
extern void WitResponseLazyCreator_op_Inequality_mE9C843DDFCFE39CBF1CA64595685E78EA4C2853D (void);
// 0x00000165 System.Boolean Meta.WitAi.Json.WitResponseLazyCreator::Equals(System.Object)
extern void WitResponseLazyCreator_Equals_m3F855190140F333CE7DE73AF8F7D0416C9565C2E (void);
// 0x00000166 System.Int32 Meta.WitAi.Json.WitResponseLazyCreator::GetHashCode()
extern void WitResponseLazyCreator_GetHashCode_m5BFA3A0F74348EB2EA8CBA562560EB7E59BDC14E (void);
// 0x00000167 System.String Meta.WitAi.Json.WitResponseLazyCreator::ToString()
extern void WitResponseLazyCreator_ToString_m50E84D2603E3FCA2E03780E40B4470B946EAB6A6 (void);
// 0x00000168 System.String Meta.WitAi.Json.WitResponseLazyCreator::ToString(System.String)
extern void WitResponseLazyCreator_ToString_mBA8C042FD615F473466BE9FF11DA64E1D32F6A54 (void);
// 0x00000169 System.Int32 Meta.WitAi.Json.WitResponseLazyCreator::get_AsInt()
extern void WitResponseLazyCreator_get_AsInt_m9832160B8EDDE9DA685242FF3E95CABCDF9CD292 (void);
// 0x0000016A System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_AsInt(System.Int32)
extern void WitResponseLazyCreator_set_AsInt_m4DADF35E8FF2BE8C29A1D500FF06EFDF0547562C (void);
// 0x0000016B System.Single Meta.WitAi.Json.WitResponseLazyCreator::get_AsFloat()
extern void WitResponseLazyCreator_get_AsFloat_m29FE6CE3C5010431FB4FE58D5BCC3231846F327D (void);
// 0x0000016C System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_AsFloat(System.Single)
extern void WitResponseLazyCreator_set_AsFloat_mA3DF95778AEED4EC889F60C5712E376B446AB86B (void);
// 0x0000016D System.Double Meta.WitAi.Json.WitResponseLazyCreator::get_AsDouble()
extern void WitResponseLazyCreator_get_AsDouble_m586C0C0F3E95273F6FEA3E6089B8004817EF0C4A (void);
// 0x0000016E System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_AsDouble(System.Double)
extern void WitResponseLazyCreator_set_AsDouble_m60421A9649FE75462BD9ABA38670B256FB11BF93 (void);
// 0x0000016F System.Boolean Meta.WitAi.Json.WitResponseLazyCreator::get_AsBool()
extern void WitResponseLazyCreator_get_AsBool_m050753D7DD79B6E7A7CC22F47CD18D30CBF31274 (void);
// 0x00000170 System.Void Meta.WitAi.Json.WitResponseLazyCreator::set_AsBool(System.Boolean)
extern void WitResponseLazyCreator_set_AsBool_m302B40878819EE83ECEA42F6B38C9B39516A10EF (void);
// 0x00000171 Meta.WitAi.Json.WitResponseArray Meta.WitAi.Json.WitResponseLazyCreator::get_AsArray()
extern void WitResponseLazyCreator_get_AsArray_m0E5FC1BCF1EF029788E36B6555CCDE23E202DDDA (void);
// 0x00000172 Meta.WitAi.Json.WitResponseClass Meta.WitAi.Json.WitResponseLazyCreator::get_AsObject()
extern void WitResponseLazyCreator_get_AsObject_m5ED9930AD5553B2C3682A44DC592AE0CD87F978B (void);
// 0x00000173 System.Void Meta.WitAi.Json.JSONParseException::.ctor(System.String)
extern void JSONParseException__ctor_mBFCD4AD2D31AB830D846E482EDBD04B6BE05F55B (void);
// 0x00000174 System.Boolean Meta.WitAi.Data.Info.WitEntityInfo::Equals(System.Object)
extern void WitEntityInfo_Equals_m4CE8855D9523C6F2B2B5718A63E3E4C2AE580212 (void);
// 0x00000175 System.Boolean Meta.WitAi.Data.Info.WitEntityInfo::Equals(Meta.WitAi.Data.Info.WitEntityInfo)
extern void WitEntityInfo_Equals_mC9768DC406175E7301DAFC503ABC99D906F6D889 (void);
// 0x00000176 System.Int32 Meta.WitAi.Data.Info.WitEntityInfo::GetHashCode()
extern void WitEntityInfo_GetHashCode_m4DDA6D7DE01355529D97A269415B2171924475A0 (void);
// 0x00000177 System.Void Meta.WitAi.Data.Info.WitEntityKeywordInfo::.ctor(System.String,System.Collections.Generic.List`1<System.String>)
extern void WitEntityKeywordInfo__ctor_mA93926A5D99F4E5286B81F04B19A5723780BBEB7 (void);
// 0x00000178 System.Boolean Meta.WitAi.Data.Info.WitEntityKeywordInfo::Equals(System.Object)
extern void WitEntityKeywordInfo_Equals_mE64ACAA27AC5ECB36A5C85BF91F96B72689EDAC6 (void);
// 0x00000179 System.Boolean Meta.WitAi.Data.Info.WitEntityKeywordInfo::Equals(Meta.WitAi.Data.Info.WitEntityKeywordInfo)
extern void WitEntityKeywordInfo_Equals_m52AD825EB33298C78E5B95757F12815F616AB0F8 (void);
// 0x0000017A System.Int32 Meta.WitAi.Data.Info.WitEntityKeywordInfo::GetHashCode()
extern void WitEntityKeywordInfo_GetHashCode_m0B3B41449D60F7253E3B66634C39320F09320427 (void);
// 0x0000017B System.Void Meta.WitAi.Data.Info.WitTraitInfo::.ctor()
extern void WitTraitInfo__ctor_m55F786DE2C051C2BC4320576E0D96316417F62CA (void);
static Il2CppMethodPointer s_methodPointers[379] = 
{
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CoroutineUtility_StartCoroutine_m5680A02AF835BAFFC3A54F57446E7594EEB832B8,
	CoroutineUtility_GetPerformer_mA455E68F266B8A2DB7BDD6BDA7ACCA29E7F22C67,
	CoroutinePerformer_get_IsRunning_m19E6CECFFAC5B06651F463FEF2C63C5394FFE227,
	CoroutinePerformer_set_IsRunning_m897C40657C00115C43D53CBEF4C3143B9A9B23A1,
	CoroutinePerformer_Awake_m903BD197AF349AA78E509053AC670749F15E4E64,
	CoroutinePerformer_CoroutineBegin_m168F0759DFBF0128EE9C1BB3855D5EE5C12E2F32,
	CoroutinePerformer_CoroutineIterateEnumerator_m110D9685700AD6EA9D7FD07C9D87CFF46F6772D0,
	CoroutinePerformer_Update_mF318B1FD0CA4DF28A2AE2F05A3D78461EDE43B5F,
	CoroutinePerformer_CoroutineIterateUpdate_m6E65F4FACA2E969CC66A5FF3BC6A7FADC5C1F944,
	CoroutinePerformer_MoveNext_m79ADEA3A1DFA04FCB54C5812BD0BF230052C4A49,
	CoroutinePerformer_OnDestroy_m51550C2552E781808BB4A6ED7CC3D5C241B248B7,
	CoroutinePerformer_CoroutineCancel_m51E365ADABD833BDC0ED8020BF6400F3D87A3E14,
	CoroutinePerformer_CoroutineComplete_mAD804B2B7CCCF5FD9B27548D3AE9A03DC6589E12,
	CoroutinePerformer_CoroutineUnload_mB36A94A478413E587602AEF7801242E27CC57041,
	CoroutinePerformer__ctor_m38757CB7375B7289938A5B9381AEB2321E4794E9,
	U3CCoroutineIterateEnumeratorU3Ed__9__ctor_m004DE712531EB1CC04344B1CF1FC4D087B69560F,
	U3CCoroutineIterateEnumeratorU3Ed__9_System_IDisposable_Dispose_mADE839050C9C4523150F56B0A6D34D437A44BA21,
	U3CCoroutineIterateEnumeratorU3Ed__9_MoveNext_m4389ECBDACF6356F0675DDC17FBBF3ACA9BE2BE6,
	U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCFEED8F504F0EB8227AB65BC8FA0D346D86CA6B2,
	U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_IEnumerator_Reset_mF0CD85E8E99747845372CCE5C8A0399A09401B10,
	U3CCoroutineIterateEnumeratorU3Ed__9_System_Collections_IEnumerator_get_Current_m32F9100BB3E02E28735715AB1CA4C656A43E8C84,
	NULL,
	ThreadUtility_PerformInBackground_m5225CF8D107EF69D434F52633F1A62BC64B4AF1A,
	ThreadPerformer_get_IsRunning_m8783C25140FE776DD1BD48DE782F3AEEFD449D89,
	ThreadPerformer_set_IsRunning_mC46576DF9ADFFB9A57D8523B3A4CD7A839BCF515,
	ThreadPerformer__ctor_m38152742FAFF310C8EC305BF1EC5862B9F57A3EC,
	ThreadPerformer_Work_mC4239E321130800C9C6E7B9E71B5F80A6D0A8DDF,
	ThreadPerformer_WaitForCompletion_m84A642BDA2546E959CB5FEE31563C2910DD15FC1,
	ThreadPerformer_IsTimedOut_m9FF4CD7F3951668149BAB121C11CEB6E51710810,
	ThreadPerformer_Quit_mCAE2EBA8A920018BDD42EFEAF778E094F851365D,
	U3CWaitForCompletionU3Ed__12__ctor_mA2EC205F9BC60B2434F8742AA2DE6B46445BB015,
	U3CWaitForCompletionU3Ed__12_System_IDisposable_Dispose_m3B0C465A7782AFA1F20BAF8852C88906B76C1EDE,
	U3CWaitForCompletionU3Ed__12_MoveNext_mD36C6466A88B687522ABCE8A64EE7DAAFB125DBA,
	U3CWaitForCompletionU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE7327EBB09EAC46C920610F63BA0EDD5D6F759CF,
	U3CWaitForCompletionU3Ed__12_System_Collections_IEnumerator_Reset_m050E5036651E75800B1C8DBF4CE0F417DCBCCE3E,
	U3CWaitForCompletionU3Ed__12_System_Collections_IEnumerator_get_Current_mEB5D836A53F9E76B434351EECC0F450CEAFBC364,
	VLog_get_SuppressErrors_m7822CA1B52753AD2CEA6D1F53C848C733BFC0DF3,
	VLog_set_SuppressErrors_m3CC6ED42BE850D8CEAB0D6B8ECAEF4F196BC850E,
	VLog_add_OnPreLog_m80E921053B5B27C2C94B805E2102598E6D702A94,
	VLog_remove_OnPreLog_m4D59F8243A80F8F713C89C481C133C79864647C6,
	VLog_D_mB02A9F04675FF3F84DC071AC2427B6933782AD37,
	VLog_D_m133AFAEBCDE1687214E2E4C38905D6690105F9E4,
	VLog_W_m7943297ED32FD0E92544C324E6793089056A2344,
	VLog_W_m97F796A4C02E724416AFDB19E1B91C1C9F284575,
	VLog_E_m72B89ED9282703998618195366B61B9F26A40AC1,
	VLog_E_m407BD08603D66FB6F1173E8E2F172395E461334C,
	VLog_Log_m77583BC27FFECD24FBCD8BCCC77D29253E1C5DA6,
	VLog_GetCallingCategory_mD8F04E537A19B1E7E38B26B71869A5523567F3AE,
	VLog_WrapWithCallingLink_mB3F632BBAF9E033A864DCB1A04E19A3D0091DB67,
	VLog_WrapWithLogColor_m099596C358459A020271465417A1CDA6CB0B6FB5,
	VRequest_get_Timeout_m0C2A0B6850A5377DF0439A1BE30E3FCD98FCD225,
	VRequest_set_Timeout_mB1621F4CBAEBF2E3F8FE30866911BE2915A2E87B,
	VRequest_get_IsComplete_m81474D77CDD9BDFEDDF752B12A81D0794FB1BE0C,
	VRequest_set_IsComplete_mC5583B96C76FD15B52AE82B4D055B26783B9B9B1,
	VRequest_get_IsPerforming_mB8C0D61A2D99A3CE2D4CF74C89D82827BD239393,
	VRequest_get_Progress_mC18867D610CA62C3373ED2AFBA5BCD70D6E9FAD8,
	VRequest_Request_m684F5A0DF9F66FAC7A2B53EDE5E7D11634014893,
	VRequest_CleanUrl_m5876C13024534312528195DB22E81CD8C06D7430,
	VRequest_GetHeaders_m5DE012C50EDAA025BCE7EB3839E3147642D055A0,
	VRequest_PerformUpdate_mAC5A928ACD1D56ECF2FB316E604A6A0381927567,
	VRequest_Begin_m3863AA40526B8AD5F9222AEBE286772BF2833075,
	VRequest_Complete_mAD054B7711A37664EB212EF1DAA32CDAA09E3287,
	VRequest_Cancel_mC26F1718B30082B2F939CE3898AF4481F897FDB2,
	VRequest_Unload_mC59B7F890F95E41EA11D4165DF259F5CF2AF54EA,
	VRequest_RequestFileHeaders_m11ECE714308E5E494427593E2C70E18217114844,
	VRequest_RequestFile_m1E29DDF0B87DC09A7DBA6C27A08554CB643A4A07,
	VRequest_RequestFileDownload_m2E5FBE78A57283210AF091B14F5756B3CECE1B70,
	VRequest_RequestFileExists_m10362277B1273A6C217E9BABAC916476D0E24778,
	VRequest_RequestText_mF65A05F3294E36C3C5C058144580DD657D21B272,
	NULL,
	NULL,
	NULL,
	NULL,
	VRequest_RequestAudioClip_mD290A894976F216133BCBD84FEEC8A5910FEAEBD,
	VRequest_RequestAudioClip_m889F3CDCDB4752DCB79529692CCB23459C855800,
	VRequest__ctor_m2CBEC55394F069C557B77F74AEC80508F65C8537,
	VRequest__cctor_m3A9D35BF41950AE968FB9F11758C217790220A3E,
	RequestProgressDelegate__ctor_m3E241D94035D7034B4DEF78A048A4B909EEEC20F,
	RequestProgressDelegate_Invoke_m26170A39DD5E2DBC99E324679C632FDE0AFEE46C,
	RequestProgressDelegate_BeginInvoke_m384DB7AB3E11756EFC97B3AB16D850BC3D5BCE97,
	RequestProgressDelegate_EndInvoke_m1041D2E110074E4C4B527C17CFC53D015A0FB882,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CPerformUpdateU3Ed__26__ctor_m36004B10B24E5820CAA8267A74C8639F4F49C42D,
	U3CPerformUpdateU3Ed__26_System_IDisposable_Dispose_m10CEBD93AA93069E54239BFD088F261FE213FDB0,
	U3CPerformUpdateU3Ed__26_MoveNext_mF980F4BB747AA453FC6648A31220E8330D71BA54,
	U3CPerformUpdateU3Ed__26_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m21781DF1DF684FC71313A014D72F7B31166516DA,
	U3CPerformUpdateU3Ed__26_System_Collections_IEnumerator_Reset_mDB7A136F0EAA8377B7766F8FF8498228EEAF96B6,
	U3CPerformUpdateU3Ed__26_System_Collections_IEnumerator_get_Current_m9373FBB805C95D909D98E1FD4A110E355DD13EFB,
	U3CU3Ec__DisplayClass31_0__ctor_mF2C81670D1D5DD2E7449A0B3FAA0197145AB74D7,
	U3CU3Ec__DisplayClass31_0_U3CRequestFileHeadersU3Eb__0_mD9F2AE383EC094E82C9F2C3955DD98D847825AD9,
	U3CU3Ec__DisplayClass32_0__ctor_m2D6905D9649DE06DF13C6E60BAC6D795F3C04709,
	U3CU3Ec__DisplayClass32_0_U3CRequestFileU3Eb__0_m7D7D386DA31FB031DCB29A62C1EEEAB325BBC20E,
	U3CU3Ec__DisplayClass33_0__ctor_m92E90653A2F0749092E188A03B2CC797C77C2CD6,
	U3CU3Ec__DisplayClass33_0_U3CRequestFileDownloadU3Eb__0_mB18717AD9CED1D355A6ACE75D0B0FCE7CBB3A129,
	U3CU3Ec__DisplayClass34_0__ctor_m08ADDADD2801B43292565C0D4180D0DEC1BC5273,
	U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__0_mA9D99FB63B3360672F826527A4F0DA37C7948D56,
	U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__1_m52676EA887466195248E2A8C023CDDC30AE88FDA,
	U3CU3Ec__DisplayClass34_0_U3CRequestFileExistsU3Eb__2_m3A9A88711FA1AB800141A5C783001E0525134A24,
	U3CU3Ec__DisplayClass35_0__ctor_m99CA6D4A98B8562CB0BCCC4631EDDA81CE34664A,
	U3CU3Ec__DisplayClass35_0_U3CRequestTextU3Eb__0_mB583A33D1C989534D7DD9C0D6C2B8D4DFE5626F1,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__DisplayClass40_0__ctor_m2840E881AD97DFDA0A7BD75190F2848F6B373FF8,
	U3CU3Ec__DisplayClass40_0_U3CRequestAudioClipU3Eb__0_mF7330104481698419DDB25B7CB4A7EF7D451F7C8,
	WitMessageVRequest__ctor_mFC7436091A46F29F5171AC007CD2FB554404D3CC,
	WitMessageVRequest_MessageRequest_mF48587E2F9305DB73FBC30A382D9C2D099BA702F,
	WitTTSVRequest__ctor_mE43EC29E3525BEC8516493C873894135017E6FB6,
	WitTTSVRequest_GetUnityRequest_mE62D08FFE6CA6BAFA6ACE487837354A2672308E3,
	WitTTSVRequest_RequestStream_m543A1147518C743CEB7925E4B69D72A1C9784508,
	WitTTSVRequest_RequestDownload_mC18DF9CEEB421F2A33282F36F70844C508731D3B,
	WitTTSVRequest__cctor_mDAA3B8F2C6377AA62732ACB19F26C27C420C6C1A,
	WitVRequest_add_OnProvideCustomUri_mE50119C857E73845F9EF84573EFB9BFB3E75D538,
	WitVRequest_remove_OnProvideCustomUri_mB41DA656E7463EF519D71625058E4994334A3AC1,
	WitVRequest_add_OnProvideCustomHeaders_mA252E19E936B0DFDE47D63DF259CD44363AF86A4,
	WitVRequest_remove_OnProvideCustomHeaders_mC7531AEA066356C3FB022E2FBE6431856E57FFB2,
	WitVRequest_add_OnProvideCustomUserAgent_m0ADDFB64122A96484E3714F6C73F60B9E120175F,
	WitVRequest_remove_OnProvideCustomUserAgent_m226B1C965F1A3279806A45939F7C92091271553B,
	WitVRequest_get_Configuration_m249A5C4BF1B892702955A74A30BBFA082E5F124F,
	WitVRequest__ctor_mF6B376A37B660B28858C9BE5165972E24A151186,
	WitVRequest_GetUri_m2B02986E00CD6AB6903AA77A2418494D1494B468,
	WitVRequest_GetHeaders_m9E469964828B68DB649BE59D9E53A3C06E68DE05,
	WitVRequest_Request_mA56EBEE3E3EB8F4C8D0C29B1CE5C60C4289FEB65,
	NULL,
	NULL,
	WitVRequest_GetWitUri_m2AAB406E20FA195917B5754ACFDCA1EDD7364622,
	WitVRequest_GetWitHeaders_m3CB0711D7370D325D875678A1628C885E1CA53C5,
	WitVRequest_GetAuthorizationHeader_m1E4D1D86D4B3E55CB44909166197B1C2A7F68E74,
	WitVRequest_GetUserAgentHeader_m58439F7735F03A0F871AE4F6B626817814735464,
	ColorConverter_get_CanRead_m6BA7E1A33F289174197CDC9472504788516030AC,
	ColorConverter_get_CanWrite_m2882801C1832AA3433F8862734DFDB2D11F0A8CA,
	ColorConverter_CanConvert_mF6A94F71611BBCF9ADDCB1D5B7996CD1EF1BE1F8,
	ColorConverter_ReadJson_m56167EE71B1F42659EAA4BAED37155C59EA764E5,
	ColorConverter_WriteJson_m04D2BEB8964E516512AD8205C500D00DB638ADD0,
	ColorConverter__ctor_m806E5A48DA7D9E1508D2CC8230CB169A38943731,
	DateTimeConverter_get_CanRead_m9E90F893D1E98AD77631006DF2338944A1C03670,
	DateTimeConverter_get_CanWrite_mBB56A0BF211282AE3DB9BBD34C199BE213982861,
	DateTimeConverter_CanConvert_m4C07AB765E9C480554C43C75DB48BA41AB36D742,
	DateTimeConverter_ReadJson_mD8AFB276D86DDAA360E639895AAB31207823489E,
	DateTimeConverter_WriteJson_m5C0BAB79CADD5E5F832057C4E6A9787B86B6622F,
	DateTimeConverter__ctor_m2EFD9B80003DA80056F01787FB0F697F141DABDD,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	JsonConvert_get_DefaultConverters_m7B0032C6B68BCA96DED146985811DA84A4AFF216,
	JsonConvert_EnsureExists_m34B862CAA75A4DC8A0E4863A154F99483E6ADA9E,
	JsonConvert_DeserializeToken_m1B7AF67114FB4FFEC5BFCADBB6820DBE3D7F8666,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	JsonConvert_DeserializeToken_mB12EA997DD32B3ACE6656B65A0287DDEE4204C4D,
	JsonConvert_DeserializeEnum_m2D6D337E8500810C18824336374A420FFFE8A558,
	NULL,
	JsonConvert_DeserializeClass_m24309A50B11D8C4FE0BA0C29E07B885C8F2D250D,
	JsonConvert_DeserializeDictionary_mA7E4F44E2ACDAA268D06F84E1DC102C0E55FF3D6,
	NULL,
	NULL,
	JsonConvert_SerializeToken_m499F2E95B66CA5D5A475E39F246FDF7B38F76E2C,
	JsonConvert__cctor_m6D4C1F52D3F436CC44218A44E41B9B8C90180487,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__cctor_m18BB15DA8C7F86F1036DF10049A047FF13949A78,
	U3CU3Ec__ctor_mEF36652F13BCFC1EC3AE5783EE338870E2F79AE9,
	U3CU3Ec_U3CDeserializeEnumU3Eb__14_0_m60DF2C4DC62E88858ABC926EAE01C06A425115C9,
	U3CU3Ec_U3CDeserializeClassU3Eb__16_0_mCE6A239BE0087BE70D131DE1473A3DC22FF63A4E,
	U3CU3Ec_U3CDeserializeClassU3Eb__16_1_mB6DAB0BC584FA4777AC92B2DFF8056CF69BA3FA6,
	JsonConverter_get_CanRead_m0D0337361BBA3C6ABA3D3F1A3199347F433F6781,
	JsonConverter_get_CanWrite_m5232AD00808BC3A406EFEFA603473DFE82A1AC72,
	NULL,
	JsonConverter_ReadJson_m8F6B56995D06D9A0C05364EE37537BFD3453991F,
	JsonConverter_WriteJson_mDE8DB3BAD12B58DC79FC6EEDBDA2C470E2BF485E,
	JsonConverter__ctor_mC9121064B1F93F5E907EDF233D40EC0CBC302B25,
	JsonPropertyAttribute_get_PropertyName_mEF2DC572AB5568F23749E61FF62E92A5748A0121,
	JsonPropertyAttribute_set_PropertyName_mB079F70AD0296B76D4B8395B43DDC8F2CEDAFDBA,
	JsonPropertyAttribute_get_DefaultValue_mD78E689C9EC517AFCA4E0F8E606062824E075FDA,
	JsonPropertyAttribute_set_DefaultValue_m51A3B98B7F4DB29DF9E1EAD8DAE8FEE346E2DF7E,
	JsonPropertyAttribute__ctor_m4F66BBBF83BC759671E7923AA3E780DAA4E7E94F,
	JsonPropertyAttribute__ctor_m46B867941D1D018F5A4EEA7F14F259B229753B83,
	WitResponseJson_Parse_mE417A7A09EAD7189E912086EF8DEE9DFE4A6567B,
	WitResponseNode_Add_m29D8906DA4C698B7D80F1F86DB1CE904C4B6D030,
	WitResponseNode_get_Item_mEB5205FD8A42FA9B270F1B9B96937CBF8EE184B2,
	WitResponseNode_set_Item_mECAC385EB82F5273D6B28B187693E96110155548,
	WitResponseNode_get_Item_m5BF8C3A148006635AB42BB486B08FAA1C26575BF,
	WitResponseNode_set_Item_m0C3DDE61566EAD1E55DFF684A034A8A49DD542DD,
	WitResponseNode_get_Value_m40A3D728DC3D7129DB7A3152B691836F67CDCC78,
	WitResponseNode_set_Value_m580C71D577A96A750E21671793B6ED44A66716CA,
	WitResponseNode_get_Count_mA9EBE5B8F8170D7ED335A273E9C50A4F7B91EDFE,
	WitResponseNode_Add_mB8A4565AFD7F3697C8599E96DA4C00B2B372C20D,
	WitResponseNode_Remove_mF641E5E61801FAB44770E3A473CB94F2D207A15C,
	WitResponseNode_Remove_mA5DA9B1052B0FB5E5615A05DB1747ADAD78C0FB3,
	WitResponseNode_Remove_m12C1A50193247D3EBD2E8B33710DA2DD9842FE30,
	WitResponseNode_get_Childs_m717121EAB7095B6F617F93ADD6872A92674707AA,
	WitResponseNode_get_DeepChilds_m3C8A1D680D6D2D65025EDBD017E695EBA09FAFF5,
	WitResponseNode_ToString_m3D445D2CF30C85801A49605C4C6A5C1712F793B4,
	WitResponseNode_ToString_m66D87595107D7F314691209D8B44F1203279F05C,
	WitResponseNode_get_AsInt_m024AA9F3EC47061E2381DFBCEBC26371C451B5CF,
	WitResponseNode_set_AsInt_m33831C323A76432BEABE58F8E35CEA90F5445735,
	WitResponseNode_get_AsFloat_m927097B265B30F942C3A6857847665FE235787B9,
	WitResponseNode_set_AsFloat_mF8F2BC7C194229DFB33094BCBCF9A197F6C6C588,
	WitResponseNode_get_AsDouble_mE345478726534C4A90DB6A112C31A750791E88EC,
	WitResponseNode_set_AsDouble_m752E687B6F5B140AB053C4FBAB0DCB27C89676D6,
	WitResponseNode_get_AsBool_m6DC15B28EDFB12DBDB8FF8E30B51DC7A6AAC5F28,
	WitResponseNode_set_AsBool_m0DD7E58848900E2EEDD53A49D0681B089913CF39,
	WitResponseNode_get_AsArray_m784676147F5A1FCE06852FA64F7734238B336CEF,
	WitResponseNode_get_AsStringArray_m1929B213720A7A709E34179350673BE6C4F98472,
	WitResponseNode_get_AsObject_m75B873A53748CE15CDD14FE1C68EAE8586D752C9,
	NULL,
	WitResponseNode_op_Implicit_mB8EA8AF87370B2ED8C8D42BD96FFCF7734294FAC,
	WitResponseNode_op_Implicit_m7AC5695C8699C246F516A32BB3654EED5A6D8911,
	WitResponseNode_op_Equality_m556CA10A38D4323CB11BF6BD64A0A22FA5055366,
	WitResponseNode_op_Inequality_mB890519AF1C832EC1EEB1644A5B0E1D0F4C324F9,
	WitResponseNode_Equals_mFF70A626804C0712E4D98F3937EF5E3CC69B32A8,
	WitResponseNode_GetHashCode_mAC54EE6F975835618C3E065D237A5D106CFAAC41,
	WitResponseNode_Escape_m03F6DE13A95DD1A8C2B25E414A12A22FC14A1B4B,
	WitResponseNode_Parse_m7FC8CFF3EFB9D3B0F1BD5F6F0757035F86252542,
	WitResponseNode_Serialize_m230A781CE376919326F281846377306B8057A875,
	WitResponseNode_SaveToStream_m6C31F731D7150456EEB45235903258F26837C0D9,
	WitResponseNode_SaveToCompressedStream_m86FA6AEB787FB004374E62C0127DFF0A0F611C3E,
	WitResponseNode_SaveToCompressedFile_m7B619C8603B7F32454D68231DC19B618E6C0BEFB,
	WitResponseNode_SaveToCompressedBase64_m773829A70940A5D40CA31E08EB826FDA126890FA,
	WitResponseNode_SaveToFile_m77E5FD343DAF070D7FF77345FB81C73497F704B8,
	WitResponseNode_SaveToBase64_mE3EB208A8BDF11697043FBA4849F29DB2A3526D8,
	WitResponseNode_Deserialize_m138FA55DE68097AD00A894664114EB24A80E9CE0,
	WitResponseNode_LoadFromCompressedFile_mCA796D8F6202FE12C5F1290BAF702BC312AEDC4E,
	WitResponseNode_LoadFromCompressedStream_m2320AA646A68CC5EE0757B20EB328EA31DFB83C8,
	WitResponseNode_LoadFromCompressedBase64_m549D1E7330369806CE3E33DC840A11D633D4DB22,
	WitResponseNode_LoadFromStream_m13BB986ADE0374D27FD1629B1B90D72E23C10C6A,
	WitResponseNode_LoadFromFile_m4CC0694987F0E8F7C86FC979466A248D5E18B32E,
	WitResponseNode_LoadFromBase64_mBE7314EAE256D8CB3AD615BD03649410041AA556,
	WitResponseNode__ctor_mC4FB7662DDD3350001A2B6B50931748A05953B7B,
	U3Cget_ChildsU3Ed__17__ctor_m7A92E3693E17CE7E6D1E5692F8C4959A9A711C2A,
	U3Cget_ChildsU3Ed__17_System_IDisposable_Dispose_m6DDF83606276C09F26793524996CFCB0A7D9897C,
	U3Cget_ChildsU3Ed__17_MoveNext_m5516806BD78EDD680ED67BD5D9CBF1B8FCDA79B4,
	U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_m826F96A6640F68D994863FA335F1AB2719B4A9E8,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_Reset_mC9F5BF2729285825E48FFD4D56AB280FF9AE20C0,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_get_Current_m9684938739FB25877D5A1B6376ACFF90702617AE,
	U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m638574D9566D546CE1FA8156C49E622271A69E04,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerable_GetEnumerator_m55CF60E5AAC2740B8806D8798993F4307585B275,
	U3Cget_DeepChildsU3Ed__19__ctor_m1ECA6AF267714944E0D88CC844C3024481B0C6F9,
	U3Cget_DeepChildsU3Ed__19_System_IDisposable_Dispose_m057C39F716CCFCB6EC09EB570622F3283AFC99A6,
	U3Cget_DeepChildsU3Ed__19_MoveNext_mD05A17730B6D957244157C241083B484C0DDDE01,
	U3Cget_DeepChildsU3Ed__19_U3CU3Em__Finally1_m34EAF3C3EC3B5B50FBF66D3443C53572CAE2AFC9,
	U3Cget_DeepChildsU3Ed__19_U3CU3Em__Finally2_m734B4CEBA5FDA07D95296334838EF75AC796F34E,
	U3Cget_DeepChildsU3Ed__19_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_m82AA5AA38BCD89F425BFF1EA4553BFADFED80E61,
	U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerator_Reset_mFA4A0BF498C57BA45D789E929AFC71BF61DAC90B,
	U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerator_get_Current_m7A12CA35475E08BE8DC3ABB2DA8E7F4CC1E6E13F,
	U3Cget_DeepChildsU3Ed__19_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m974C9CD69CAC6CC231D47EF095087FB6AE3A3657,
	U3Cget_DeepChildsU3Ed__19_System_Collections_IEnumerable_GetEnumerator_mE964ED7F36A034A941050E850DB5B296CCB36389,
	WitResponseArray_get_Item_m927FFFE46DFDC0803F897C7396D30221080C61A7,
	WitResponseArray_set_Item_m27C3BAB5EA3B1BB4FEDCE88FA6873663982991BB,
	WitResponseArray_get_Item_m7B53C8F8BD9A22A65F68218727330CFC8F3AF58D,
	WitResponseArray_set_Item_mCDBFCE84ADABB704F25DBBF960E27DCA38294465,
	WitResponseArray_get_Count_m3C0846E5646C8FDDBBCCEF276B524D13AAB658DA,
	WitResponseArray_Add_mDC72A2B60BF5E3C870CBD364F9E10FD0B46BF5D8,
	WitResponseArray_Remove_m9D56D4CF28E1912CE311E2BF41042219C2869CF4,
	WitResponseArray_Remove_mF9D743830FBFE9B3722661915ABB3E6013C9D69A,
	WitResponseArray_get_Childs_m574A7FD2693EA36AFFD83098FEF5A8302C04272D,
	WitResponseArray_GetEnumerator_mE3D7CAB439F65B7778D55123748DFC6C515D6026,
	WitResponseArray_ToString_mDA58401450439B53B96BCA568DEEA801743A22AD,
	WitResponseArray_ToString_m9E2A94668564EF25411A7BD98961CD4E4B05F6A1,
	WitResponseArray_Serialize_mD50F05A3ADB0F34EA23332AA32FC54254AEF5589,
	WitResponseArray__ctor_m721A235EE997F78DFEBD437510486DE59A685F55,
	U3Cget_ChildsU3Ed__13__ctor_m429A0436140CAAC11D1FEC5AE457F973E5CBCE81,
	U3Cget_ChildsU3Ed__13_System_IDisposable_Dispose_m77150F5238147EF1A1123553B144D32384FDF041,
	U3Cget_ChildsU3Ed__13_MoveNext_mED66E2F0C7AC042B0DDA325CE0A625CCE9F84629,
	U3Cget_ChildsU3Ed__13_U3CU3Em__Finally1_mC36DE4425B467C1530E7B63FAFF3953BCB0F5A4A,
	U3Cget_ChildsU3Ed__13_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_mCCA6C7443157D72D027788498250E4190F7588BB,
	U3Cget_ChildsU3Ed__13_System_Collections_IEnumerator_Reset_m951018C550B587C6BC6EB1028EA39DD11B9BFDF3,
	U3Cget_ChildsU3Ed__13_System_Collections_IEnumerator_get_Current_m15D840D5299CA52E41DFC537BBCA8114DFF3340B,
	U3Cget_ChildsU3Ed__13_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_m5F25DA4843C4E27A1832287B6A8C0E97E2E900C6,
	U3Cget_ChildsU3Ed__13_System_Collections_IEnumerable_GetEnumerator_m0D4D4A2C8508D22357D51157A1DD0865F7562297,
	U3CGetEnumeratorU3Ed__14__ctor_m3E2ECECCB821D8BC7EC4F6AC5AA5266317FB0363,
	U3CGetEnumeratorU3Ed__14_System_IDisposable_Dispose_m8B46DC03D65B315AF464114378C6E71C2268AFD7,
	U3CGetEnumeratorU3Ed__14_MoveNext_m3ACEEE39EBBE063061A2E69B85883B999B0BAA78,
	U3CGetEnumeratorU3Ed__14_U3CU3Em__Finally1_mE7D3B2D552B46B7CE8FC72BF74533B5957F988E7,
	U3CGetEnumeratorU3Ed__14_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC7CE42F21A88CC604C4EE5C5F806AB3D537F3438,
	U3CGetEnumeratorU3Ed__14_System_Collections_IEnumerator_Reset_m630CFD8E7B2F011E087BBD24EDA563AC94B3D181,
	U3CGetEnumeratorU3Ed__14_System_Collections_IEnumerator_get_Current_mBB676A0A25E054C8115154F7F3BA5FE44EDF1CE3,
	WitResponseClass_get_ChildNodeNames_m17643A6B0646BB4C0432A7ABE39A0EEE0FFA09FC,
	WitResponseClass_HasChild_mA300E73E9D4346D21FEDDC071B2D52538625A3FB,
	WitResponseClass_get_Item_m46C1E02FA07F165B10C5E55B22329F77C83F66CB,
	WitResponseClass_set_Item_mB95FE232445471A1C68C8FF19CC1C361F9619E68,
	WitResponseClass_get_Item_m789E7BBCFB8C73602AEE9B3DA54628A03B15A74B,
	WitResponseClass_set_Item_m559D8991F4C5F4F3830D9CB5267DCEE5006A3504,
	WitResponseClass_get_Count_m04014274AF6AFFDB69D92A954D5666387C67A8F1,
	WitResponseClass_Add_m6561A55FFA76C268F5261E171853D5AB24FCBFB4,
	WitResponseClass_Remove_m33C6F72D72F766ACF1081F8074C03F93409AE943,
	WitResponseClass_Remove_mE01845757C9328C5CE82EE0F80899EE2483B6D76,
	WitResponseClass_Remove_m9BACA15EB93394E290B3854D2966110EA189F5FE,
	WitResponseClass_get_Childs_mBF1BBBEFE5A4FB7B1D05B526034C9EC7372C1A27,
	WitResponseClass_GetEnumerator_m50FF38C23BACEA00930A2BE4E5789E20DDA5F3FB,
	NULL,
	WitResponseClass_ToString_m88D914030920CBA87C43C06976D5FF9539718486,
	WitResponseClass_ToString_m00C5C60A74D446F1FA202ABBEA9A9D754D4EDD8F,
	WitResponseClass_Serialize_mBA795A5A5945066A8BE18B572B5D781FE932434D,
	WitResponseClass__ctor_mAD6E312EBFEC01A4819A7AF57D2E0D98163AAD47,
	U3CU3Ec__DisplayClass15_0__ctor_m70566E35212CD98AC59D425A2CF4832FEC0F9F94,
	U3CU3Ec__DisplayClass15_0_U3CRemoveU3Eb__0_mAD41BE11BCE3E900BFC3DCF57DF0CDCEB67618BB,
	U3Cget_ChildsU3Ed__17__ctor_m12B9ABD0288987CD61E2BA7D036767AE1BF4D0BE,
	U3Cget_ChildsU3Ed__17_System_IDisposable_Dispose_m251435C763D9BD1F83DA693B60652B15C0D6412B,
	U3Cget_ChildsU3Ed__17_MoveNext_m6EDCA79501326B1ABA3BAC7D4CA09CCC28CE5F58,
	U3Cget_ChildsU3Ed__17_U3CU3Em__Finally1_m0CEC896D7B08ACC1EE2FD7E652B9E7F0C034A3CC,
	U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumeratorU3CMeta_WitAi_Json_WitResponseNodeU3E_get_Current_mB3A70175F3C17A89A9797E27574A99B95C0D7B6D,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_Reset_mE1C1598BCB643AE91F487DFDC674CCB620D50099,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerator_get_Current_mCD4D28D5213447AC15E46908877BDCBDFEF0FE41,
	U3Cget_ChildsU3Ed__17_System_Collections_Generic_IEnumerableU3CMeta_WitAi_Json_WitResponseNodeU3E_GetEnumerator_mB45B52244BD5D55A8882EEDEEA2537D9CDF73038,
	U3Cget_ChildsU3Ed__17_System_Collections_IEnumerable_GetEnumerator_mA94336900DAAE3CBBBB867857026C11EEDED92BC,
	U3CGetEnumeratorU3Ed__18__ctor_m76216DA4E7DA7307BEAD2051640156E3FF114BAC,
	U3CGetEnumeratorU3Ed__18_System_IDisposable_Dispose_m4C26F7E170E59A2FFB51CC5EA1C9E4B3FAB74013,
	U3CGetEnumeratorU3Ed__18_MoveNext_m924931A590B530D38EE346F596B85484107A43A2,
	U3CGetEnumeratorU3Ed__18_U3CU3Em__Finally1_m8E677E16C3DA39A359DDD922234114FD8FE583CF,
	U3CGetEnumeratorU3Ed__18_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC2BDB5B90BCC1F22D345F711D64DD290BC239A7D,
	U3CGetEnumeratorU3Ed__18_System_Collections_IEnumerator_Reset_m04F4FC789272FD7A8ABE9AD024086B4594C2594A,
	U3CGetEnumeratorU3Ed__18_System_Collections_IEnumerator_get_Current_m79C6A5ACEEAB2BB4A1DF627A2D8AF060A24B5BAE,
	WitResponseData_get_Value_m0975849486729B3D273D4E37707F857C5D6FFC02,
	WitResponseData_set_Value_m95872341BCA728770E707806BD3E27AC58B4F8A4,
	WitResponseData__ctor_mC5CAD7423156DB2AFA917797D3C239BDF94A0BAD,
	WitResponseData__ctor_mF2E1CC4ECA3A729D104130CCB5CCB873C75F86C2,
	WitResponseData__ctor_mC9CE8379EAC42B7F85910B573447E05117CE2A81,
	WitResponseData__ctor_m61443D4A59044E96DC07C970FD2C03C7F9F7F782,
	WitResponseData__ctor_m0A2E4A8270DB755B5D7172F178890C323FB22290,
	WitResponseData_ToString_m7093EC5D51B180ECA77D88196C00FB4FCE9BE5D2,
	WitResponseData_ToString_m8E4076FBB7CE6838EA2F55F39E6740929581967E,
	WitResponseData_Serialize_m96CF5AC981F31FD000115E5BCE1CB79737369BA0,
	WitResponseLazyCreator__ctor_mDABB3CE3048D2FB3FC72597DF35ABD46824DC7B6,
	WitResponseLazyCreator__ctor_m806225C5DE01971257BC07EEFBD8D5FCD2522175,
	WitResponseLazyCreator_Set_mE5ED8C6DDB40D47373E29A6F3CE3FD453FA21458,
	WitResponseLazyCreator_get_Item_m10F2D23CB786080CCE534BAC1527D7AB606C71CB,
	WitResponseLazyCreator_set_Item_m79594FDE487845703B9B7F79323FC6310C11620D,
	WitResponseLazyCreator_get_Item_m0FFB198C00D3D5EC389B69C30AE09AF06586C631,
	WitResponseLazyCreator_set_Item_m725459A2CE4DFABF6820B5363B6C436A0F84DE10,
	WitResponseLazyCreator_Add_m9FF2438CD8A3F7C63F039757C9DC452AEB349D7B,
	WitResponseLazyCreator_Add_mCEF57F8B2B20499AA785B8368B76CA34057DCC37,
	WitResponseLazyCreator_op_Equality_m33785B9091FDDFD763DC36859F395F6125DC484F,
	WitResponseLazyCreator_op_Inequality_mE9C843DDFCFE39CBF1CA64595685E78EA4C2853D,
	WitResponseLazyCreator_Equals_m3F855190140F333CE7DE73AF8F7D0416C9565C2E,
	WitResponseLazyCreator_GetHashCode_m5BFA3A0F74348EB2EA8CBA562560EB7E59BDC14E,
	WitResponseLazyCreator_ToString_m50E84D2603E3FCA2E03780E40B4470B946EAB6A6,
	WitResponseLazyCreator_ToString_mBA8C042FD615F473466BE9FF11DA64E1D32F6A54,
	WitResponseLazyCreator_get_AsInt_m9832160B8EDDE9DA685242FF3E95CABCDF9CD292,
	WitResponseLazyCreator_set_AsInt_m4DADF35E8FF2BE8C29A1D500FF06EFDF0547562C,
	WitResponseLazyCreator_get_AsFloat_m29FE6CE3C5010431FB4FE58D5BCC3231846F327D,
	WitResponseLazyCreator_set_AsFloat_mA3DF95778AEED4EC889F60C5712E376B446AB86B,
	WitResponseLazyCreator_get_AsDouble_m586C0C0F3E95273F6FEA3E6089B8004817EF0C4A,
	WitResponseLazyCreator_set_AsDouble_m60421A9649FE75462BD9ABA38670B256FB11BF93,
	WitResponseLazyCreator_get_AsBool_m050753D7DD79B6E7A7CC22F47CD18D30CBF31274,
	WitResponseLazyCreator_set_AsBool_m302B40878819EE83ECEA42F6B38C9B39516A10EF,
	WitResponseLazyCreator_get_AsArray_m0E5FC1BCF1EF029788E36B6555CCDE23E202DDDA,
	WitResponseLazyCreator_get_AsObject_m5ED9930AD5553B2C3682A44DC592AE0CD87F978B,
	JSONParseException__ctor_mBFCD4AD2D31AB830D846E482EDBD04B6BE05F55B,
	WitEntityInfo_Equals_m4CE8855D9523C6F2B2B5718A63E3E4C2AE580212,
	WitEntityInfo_Equals_mC9768DC406175E7301DAFC503ABC99D906F6D889,
	WitEntityInfo_GetHashCode_m4DDA6D7DE01355529D97A269415B2171924475A0,
	WitEntityKeywordInfo__ctor_mA93926A5D99F4E5286B81F04B19A5723780BBEB7,
	WitEntityKeywordInfo_Equals_mE64ACAA27AC5ECB36A5C85BF91F96B72689EDAC6,
	WitEntityKeywordInfo_Equals_m52AD825EB33298C78E5B95757F12815F616AB0F8,
	WitEntityKeywordInfo_GetHashCode_m0B3B41449D60F7253E3B66634C39320F09320427,
	WitTraitInfo__ctor_m55F786DE2C051C2BC4320576E0D96316417F62CA,
};
extern void WitEntityInfo_Equals_m4CE8855D9523C6F2B2B5718A63E3E4C2AE580212_AdjustorThunk (void);
extern void WitEntityInfo_Equals_mC9768DC406175E7301DAFC503ABC99D906F6D889_AdjustorThunk (void);
extern void WitEntityInfo_GetHashCode_m4DDA6D7DE01355529D97A269415B2171924475A0_AdjustorThunk (void);
extern void WitEntityKeywordInfo__ctor_mA93926A5D99F4E5286B81F04B19A5723780BBEB7_AdjustorThunk (void);
extern void WitEntityKeywordInfo_Equals_mE64ACAA27AC5ECB36A5C85BF91F96B72689EDAC6_AdjustorThunk (void);
extern void WitEntityKeywordInfo_Equals_m52AD825EB33298C78E5B95757F12815F616AB0F8_AdjustorThunk (void);
extern void WitEntityKeywordInfo_GetHashCode_m0B3B41449D60F7253E3B66634C39320F09320427_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[7] = 
{
	{ 0x06000174, WitEntityInfo_Equals_m4CE8855D9523C6F2B2B5718A63E3E4C2AE580212_AdjustorThunk },
	{ 0x06000175, WitEntityInfo_Equals_mC9768DC406175E7301DAFC503ABC99D906F6D889_AdjustorThunk },
	{ 0x06000176, WitEntityInfo_GetHashCode_m4DDA6D7DE01355529D97A269415B2171924475A0_AdjustorThunk },
	{ 0x06000177, WitEntityKeywordInfo__ctor_mA93926A5D99F4E5286B81F04B19A5723780BBEB7_AdjustorThunk },
	{ 0x06000178, WitEntityKeywordInfo_Equals_mE64ACAA27AC5ECB36A5C85BF91F96B72689EDAC6_AdjustorThunk },
	{ 0x06000179, WitEntityKeywordInfo_Equals_m52AD825EB33298C78E5B95757F12815F616AB0F8_AdjustorThunk },
	{ 0x0600017A, WitEntityKeywordInfo_GetHashCode_m0B3B41449D60F7253E3B66634C39320F09320427_AdjustorThunk },
};
static const int32_t s_InvokerIndices[379] = 
{
	0,
	0,
	0,
	0,
	0,
	7820,
	8773,
	5610,
	4589,
	5809,
	2720,
	5697,
	5809,
	5809,
	3411,
	5809,
	5809,
	5809,
	5809,
	5809,
	4648,
	5809,
	5610,
	5697,
	5809,
	5697,
	0,
	7205,
	5610,
	4589,
	1567,
	5809,
	5697,
	3346,
	5809,
	4648,
	5809,
	5610,
	5697,
	5809,
	5697,
	8750,
	8618,
	8626,
	8626,
	8626,
	8093,
	8626,
	8093,
	8626,
	8093,
	7405,
	8773,
	8087,
	7448,
	5664,
	4648,
	5610,
	4589,
	5610,
	5740,
	1217,
	4185,
	5697,
	5697,
	5809,
	5809,
	5809,
	5809,
	1744,
	1217,
	627,
	1744,
	1217,
	0,
	0,
	0,
	0,
	323,
	323,
	5809,
	8805,
	2730,
	4721,
	1368,
	4680,
	0,
	0,
	0,
	0,
	4648,
	5809,
	5610,
	5697,
	5809,
	5697,
	5809,
	2733,
	5809,
	2733,
	5809,
	2733,
	5809,
	2733,
	2733,
	4721,
	5809,
	2733,
	0,
	0,
	0,
	0,
	5809,
	2733,
	4680,
	1217,
	4680,
	2159,
	627,
	327,
	8805,
	8626,
	8626,
	8626,
	8626,
	8626,
	8626,
	5697,
	2720,
	2159,
	5697,
	1217,
	0,
	0,
	7203,
	7820,
	7820,
	8452,
	5610,
	5610,
	3411,
	1360,
	4185,
	5809,
	5610,
	5610,
	3411,
	1360,
	4185,
	5809,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	8773,
	7830,
	8452,
	0,
	0,
	0,
	0,
	0,
	0,
	6367,
	6797,
	0,
	6367,
	6367,
	0,
	0,
	6797,
	8805,
	0,
	0,
	0,
	0,
	0,
	0,
	8805,
	5809,
	3411,
	3411,
	3411,
	5610,
	5610,
	0,
	1360,
	4185,
	5809,
	5697,
	4680,
	5697,
	4680,
	4680,
	2733,
	8452,
	2733,
	4180,
	2526,
	4185,
	2733,
	5697,
	4680,
	5664,
	4680,
	4185,
	4180,
	4185,
	5697,
	5697,
	5697,
	4185,
	5664,
	4648,
	5740,
	4721,
	5629,
	4613,
	5610,
	4589,
	5697,
	5697,
	5697,
	0,
	8452,
	8452,
	7610,
	7610,
	3411,
	5664,
	8452,
	8452,
	4680,
	4680,
	4680,
	4680,
	5697,
	4680,
	5697,
	8452,
	8452,
	8452,
	8452,
	8452,
	8452,
	8452,
	5809,
	4648,
	5809,
	5610,
	5697,
	5809,
	5697,
	5697,
	5697,
	4648,
	5809,
	5610,
	5809,
	5809,
	5697,
	5809,
	5697,
	5697,
	5697,
	4180,
	2526,
	4185,
	2733,
	5664,
	2733,
	4180,
	4185,
	5697,
	5697,
	5697,
	4185,
	4680,
	5809,
	4648,
	5809,
	5610,
	5809,
	5697,
	5809,
	5697,
	5697,
	5697,
	4648,
	5809,
	5610,
	5809,
	5697,
	5809,
	5697,
	5697,
	3411,
	4185,
	2733,
	4180,
	2526,
	5664,
	2733,
	4185,
	4180,
	4185,
	5697,
	5697,
	0,
	5697,
	4185,
	4680,
	5809,
	5809,
	3174,
	4648,
	5809,
	5610,
	5809,
	5697,
	5809,
	5697,
	5697,
	5697,
	4648,
	5809,
	5610,
	5809,
	5697,
	5809,
	5697,
	5697,
	4680,
	4680,
	4721,
	4613,
	4589,
	4648,
	5697,
	4185,
	4680,
	4680,
	2733,
	4680,
	4180,
	2526,
	4185,
	2733,
	4680,
	2733,
	7610,
	7610,
	3411,
	5664,
	5697,
	4185,
	5664,
	4648,
	5740,
	4721,
	5629,
	4613,
	5610,
	4589,
	5697,
	5697,
	4680,
	3411,
	3518,
	5664,
	2733,
	3411,
	3519,
	5664,
	5809,
};
static const Il2CppTokenRangePair s_rgctxIndices[23] = 
{
	{ 0x02000016, { 7, 8 } },
	{ 0x02000017, { 15, 2 } },
	{ 0x0200001E, { 19, 12 } },
	{ 0x02000022, { 59, 3 } },
	{ 0x02000023, { 62, 3 } },
	{ 0x0600001B, { 0, 1 } },
	{ 0x0600004B, { 1, 3 } },
	{ 0x0600004C, { 4, 1 } },
	{ 0x0600004D, { 5, 1 } },
	{ 0x0600004E, { 6, 1 } },
	{ 0x06000085, { 17, 1 } },
	{ 0x06000086, { 18, 1 } },
	{ 0x060000A2, { 31, 6 } },
	{ 0x060000A3, { 37, 6 } },
	{ 0x060000A4, { 43, 3 } },
	{ 0x060000A5, { 46, 3 } },
	{ 0x060000A6, { 49, 1 } },
	{ 0x060000A7, { 50, 2 } },
	{ 0x060000AA, { 52, 4 } },
	{ 0x060000AD, { 56, 1 } },
	{ 0x060000AE, { 57, 2 } },
	{ 0x060000E4, { 65, 2 } },
	{ 0x06000139, { 67, 1 } },
};
extern const uint32_t g_rgctx_Enumerable_SequenceEqual_TisTSource_tFA0327F5BD4FB1BDABD580592A8059CF88E4D586_m2F95819DFAC24093EEA0476A9ABE8FCD250B60D5;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_0_1_t3D863B4D4E2127F8CDDB43F413E46741B345708F;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_0_1__ctor_m512DE04C0D2083A38800D36B642E4FED33CD7841;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_0_1_U3CRequestJsonU3Eb__0_mB670E88837DB0AA1D1567B6686A736EB68CB0D0C;
extern const uint32_t g_rgctx_VRequest_RequestJson_TisTData_t9F17DDD53FA402F45BF75C94A0A41D76E1C98158_mC748E240EB65EA9A86C9F3F13D04E3DA535D22C4;
extern const uint32_t g_rgctx_VRequest_RequestJson_TisTData_tC4343733838FD23EB6D898D1BEEA306C0CE8E976_m07B67715B3A16B12417A49FF1CEC47536AD198CA;
extern const uint32_t g_rgctx_VRequest_RequestJson_TisTData_t03774D85DE86415F00CC0F22F31EA7F8640AE0C4_mE72D976E417E156D1106565647B3FB651228FD33;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_1_1_t2CDD2629EBDC61F5D78019858DFA0E7895234680;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_1_1__ctor_mC50C0B0C86D2420A60E88F078BEED1B3AFE581C5;
extern const uint32_t g_rgctx_RequestCompleteDelegate_1_t9883B4FED8247DE39F0F6D26BBD421DC02C9B0C5;
extern const uint32_t g_rgctx_RequestCompleteDelegate_1_Invoke_m51FFC09CF371B97CCFAEE1FE377A0E284F09257F;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass36_1_1_U3CRequestJsonU3Eb__1_m34BD0846A90C0C50B64E8AA48544CE1937614226;
extern const uint32_t g_rgctx_Action_2_t5680B761299BDEBDE7A012225ED878AB47F587F0;
extern const uint32_t g_rgctx_Action_2__ctor_mA2EEDF7F2CE580559D72DAB106C3D12389647440;
extern const uint32_t g_rgctx_JsonConvert_DeserializeObjectAsync_TisTData_t2309277FE317767E673B25963A2BFEE7B69D4781_m00916F85490FC45887559293D727E27F0C0A2689;
extern const uint32_t g_rgctx_RequestCompleteDelegate_1_tD501C36789410DA75D601132EFCC958CA0A0E861;
extern const uint32_t g_rgctx_RequestCompleteDelegate_1_Invoke_mFC550015799FFEC1A72D0225F3CCEB7EC24D5144;
extern const uint32_t g_rgctx_VRequest_RequestJson_TisTData_tF6445909900CA29639D08A89EE8147804B313DCF_m411DA0C349E51B4B332806924528424411BADCF9;
extern const uint32_t g_rgctx_VRequest_RequestJson_TisTData_tA357FD795EDCC41F2292C0E0407948C874844A8E_m1C637C2A09E23BAC67D3BC24D3101CF120CBFD96;
extern const uint32_t g_rgctx_HashSet_1_t2DD5B136BE5B9CE42224D9456D738812CCC0EDA4;
extern const uint32_t g_rgctx_HashSet_1_t2DD5B136BE5B9CE42224D9456D738812CCC0EDA4;
extern const uint32_t g_rgctx_HashSet_1__ctor_m8446056EA2DE7FA08CBAE5450924C5ACBFBD4B5A;
extern const uint32_t g_rgctx_WitResponseNode_Cast_TisT_t2D42AF85191E0191B37DF6DFF6669395FECEE81B_mCB665F44B26A12C1BFADE07B38387A3CF15DB231;
extern const uint32_t g_rgctx_HashSet_1_Add_m0D2491EE7549BA8B4CF7594236D9BAB615945DC7;
extern const uint32_t g_rgctx_HashSet_1_GetEnumerator_m3B78092878D414DAAB1493BFD9E8A63503994452;
extern const uint32_t g_rgctx_Enumerator_get_Current_m84CB662CC9C87417F628A5CF06E3C220AC41BD3A;
extern const uint32_t g_rgctx_T_t2D42AF85191E0191B37DF6DFF6669395FECEE81B;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t2D42AF85191E0191B37DF6DFF6669395FECEE81B_Object_ToString_mF8AC1EB9D85AB52EC8FD8B8BDD131E855E69673F;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mFE5A57DA3AF156373825C42345019029FC8D1F7C;
extern const uint32_t g_rgctx_Enumerator_t3B40F6C27CB62299453425DE5720583E98E54E3D;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t3B40F6C27CB62299453425DE5720583E98E54E3D_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass6_0_1_tC11530953042A3DE5BCEAAFC43233C425C5D2B82;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass6_0_1__ctor_m048149CFF158DBE0D081BD73917FA5FF52E29D1E;
extern const uint32_t g_rgctx_IN_TYPE_tD7E07A7DA4ECA9ED98B7A482C8633F908A4F5A9D;
extern const uint32_t g_rgctx_IN_TYPE_tD7E07A7DA4ECA9ED98B7A482C8633F908A4F5A9D;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass6_0_1_U3CDeserializeObjectAsyncU3Eb__0_m135ECABDBE62BF8C30612BAFF830797467C04358;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass6_0_1_U3CDeserializeObjectAsyncU3Eb__1_mA1913154A3D2D4ADFA3C899B4DC979F003223282;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass7_0_1_tB1CF6E278C26647F300FDE6861E9E7E5D9232C3F;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass7_0_1__ctor_m8CBAAE6BB2B8EB3ABF3A4C2F9D4D82EA1FB0778D;
extern const uint32_t g_rgctx_IN_TYPE_tFABB563ED7DB19328032C482AB0477D75003FA9C;
extern const uint32_t g_rgctx_IN_TYPE_tFABB563ED7DB19328032C482AB0477D75003FA9C;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass7_0_1_U3CDeserializeObjectAsyncU3Eb__0_m38959B44A0B35F49811BBC9FE7E5AA24C54B19B3;
extern const uint32_t g_rgctx_U3CU3Ec__DisplayClass7_0_1_U3CDeserializeObjectAsyncU3Eb__1_m1DFA51FB72D3535556A6E207E951C43339AA3539;
extern const uint32_t g_rgctx_IN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3;
extern const uint32_t g_rgctx_IN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3;
extern const uint32_t g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3_mB4F17A688523DF8B2E4894D70FC007C8FED244DB;
extern const uint32_t g_rgctx_IN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04;
extern const uint32_t g_rgctx_IN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04;
extern const uint32_t g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04_m8DBADFFBE776290F97A8704B666F9F348B3572D6;
extern const uint32_t g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t29E3C00E637770CAE35C54462073A9B5FFE62D41_m32BDC5C7C1309E5D4799962FB5237CA69F1F6732;
extern const uint32_t g_rgctx_IN_TYPE_t6F3541AED2CEA8C0D0C4AF4028801B97F2BA4735;
extern const uint32_t g_rgctx_IN_TYPE_t6F3541AED2CEA8C0D0C4AF4028801B97F2BA4735;
extern const uint32_t g_rgctx_ITEM_TYPEU5BU5D_t62AA8F456903FB8998BC3CF39CB8C24B26CC6F2C;
extern const uint32_t g_rgctx_ITEM_TYPEU5BU5D_t62AA8F456903FB8998BC3CF39CB8C24B26CC6F2C;
extern const uint32_t g_rgctx_ITEM_TYPE_t93DF867F5BF8B8DFABB7E16C3C6006CAE626ECC9;
extern const uint32_t g_rgctx_ITEM_TYPE_t93DF867F5BF8B8DFABB7E16C3C6006CAE626ECC9;
extern const uint32_t g_rgctx_JsonConvert_SerializeToken_TisFROM_TYPE_tCBA11A0A0B4DBAEC7AB66F3AAF918BB714FD6AF5_mEE70EA3463E9C7CAFB08F534AAD69842CD5E93CC;
extern const uint32_t g_rgctx_FROM_TYPE_t4A6CEAACBF4B3BD03D0F1CB6A6AE6A4CBC60FF85;
extern const uint32_t g_rgctx_FROM_TYPE_t4A6CEAACBF4B3BD03D0F1CB6A6AE6A4CBC60FF85;
extern const uint32_t g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_tFAFAD028A21C8AC6113128B6072F114AD3F49092_mE81FC75A0DD34F7119C27E098D8B1EFE8AC27D57;
extern const uint32_t g_rgctx_Action_2_t09D1FBAA199EE3A5C3D05F8EE2938218D0B7F3EB;
extern const uint32_t g_rgctx_Action_2_Invoke_m4E232944FF87A89CA8A23DFD63EDD5C8CEB45706;
extern const uint32_t g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t7B18BDEA13918DE234C07526B55E8EC61FF01DA4_mAF6ED4DA3614E11C1BBD8168A6A188256461AB69;
extern const uint32_t g_rgctx_Action_2_t5134859EA1D179A65306CC08560420CB76382E60;
extern const uint32_t g_rgctx_Action_2_Invoke_m4CEBA72C411996B24E317BC10A43D633A91AFE10;
extern const uint32_t g_rgctx_T_tFF2C78A98D5471F414ECE0284899758B10749975;
extern const uint32_t g_rgctx_T_tFF2C78A98D5471F414ECE0284899758B10749975;
extern const uint32_t g_rgctx_WitResponseNode_Cast_TisT_t433BE44C793E00A0BE12BF38A035B538AF82195D_m73AEE2DA09907B081A6C7E3E9313A6B2528CDED4;
static const Il2CppRGCTXDefinition s_rgctxValues[68] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerable_SequenceEqual_TisTSource_tFA0327F5BD4FB1BDABD580592A8059CF88E4D586_m2F95819DFAC24093EEA0476A9ABE8FCD250B60D5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_0_1_t3D863B4D4E2127F8CDDB43F413E46741B345708F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_0_1__ctor_m512DE04C0D2083A38800D36B642E4FED33CD7841 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_0_1_U3CRequestJsonU3Eb__0_mB670E88837DB0AA1D1567B6686A736EB68CB0D0C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VRequest_RequestJson_TisTData_t9F17DDD53FA402F45BF75C94A0A41D76E1C98158_mC748E240EB65EA9A86C9F3F13D04E3DA535D22C4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VRequest_RequestJson_TisTData_tC4343733838FD23EB6D898D1BEEA306C0CE8E976_m07B67715B3A16B12417A49FF1CEC47536AD198CA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VRequest_RequestJson_TisTData_t03774D85DE86415F00CC0F22F31EA7F8640AE0C4_mE72D976E417E156D1106565647B3FB651228FD33 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_1_1_t2CDD2629EBDC61F5D78019858DFA0E7895234680 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_1_1__ctor_mC50C0B0C86D2420A60E88F078BEED1B3AFE581C5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RequestCompleteDelegate_1_t9883B4FED8247DE39F0F6D26BBD421DC02C9B0C5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RequestCompleteDelegate_1_Invoke_m51FFC09CF371B97CCFAEE1FE377A0E284F09257F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass36_1_1_U3CRequestJsonU3Eb__1_m34BD0846A90C0C50B64E8AA48544CE1937614226 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_2_t5680B761299BDEBDE7A012225ED878AB47F587F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_2__ctor_mA2EEDF7F2CE580559D72DAB106C3D12389647440 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeObjectAsync_TisTData_t2309277FE317767E673B25963A2BFEE7B69D4781_m00916F85490FC45887559293D727E27F0C0A2689 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RequestCompleteDelegate_1_tD501C36789410DA75D601132EFCC958CA0A0E861 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RequestCompleteDelegate_1_Invoke_mFC550015799FFEC1A72D0225F3CCEB7EC24D5144 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VRequest_RequestJson_TisTData_tF6445909900CA29639D08A89EE8147804B313DCF_m411DA0C349E51B4B332806924528424411BADCF9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VRequest_RequestJson_TisTData_tA357FD795EDCC41F2292C0E0407948C874844A8E_m1C637C2A09E23BAC67D3BC24D3101CF120CBFD96 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_HashSet_1_t2DD5B136BE5B9CE42224D9456D738812CCC0EDA4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSet_1_t2DD5B136BE5B9CE42224D9456D738812CCC0EDA4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1__ctor_m8446056EA2DE7FA08CBAE5450924C5ACBFBD4B5A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_WitResponseNode_Cast_TisT_t2D42AF85191E0191B37DF6DFF6669395FECEE81B_mCB665F44B26A12C1BFADE07B38387A3CF15DB231 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Add_m0D2491EE7549BA8B4CF7594236D9BAB615945DC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_GetEnumerator_m3B78092878D414DAAB1493BFD9E8A63503994452 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m84CB662CC9C87417F628A5CF06E3C220AC41BD3A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t2D42AF85191E0191B37DF6DFF6669395FECEE81B },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t2D42AF85191E0191B37DF6DFF6669395FECEE81B_Object_ToString_mF8AC1EB9D85AB52EC8FD8B8BDD131E855E69673F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mFE5A57DA3AF156373825C42345019029FC8D1F7C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t3B40F6C27CB62299453425DE5720583E98E54E3D },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t3B40F6C27CB62299453425DE5720583E98E54E3D_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__DisplayClass6_0_1_tC11530953042A3DE5BCEAAFC43233C425C5D2B82 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass6_0_1__ctor_m048149CFF158DBE0D081BD73917FA5FF52E29D1E },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_IN_TYPE_tD7E07A7DA4ECA9ED98B7A482C8633F908A4F5A9D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IN_TYPE_tD7E07A7DA4ECA9ED98B7A482C8633F908A4F5A9D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass6_0_1_U3CDeserializeObjectAsyncU3Eb__0_m135ECABDBE62BF8C30612BAFF830797467C04358 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass6_0_1_U3CDeserializeObjectAsyncU3Eb__1_mA1913154A3D2D4ADFA3C899B4DC979F003223282 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__DisplayClass7_0_1_tB1CF6E278C26647F300FDE6861E9E7E5D9232C3F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass7_0_1__ctor_m8CBAAE6BB2B8EB3ABF3A4C2F9D4D82EA1FB0778D },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_IN_TYPE_tFABB563ED7DB19328032C482AB0477D75003FA9C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IN_TYPE_tFABB563ED7DB19328032C482AB0477D75003FA9C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass7_0_1_U3CDeserializeObjectAsyncU3Eb__0_m38959B44A0B35F49811BBC9FE7E5AA24C54B19B3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__DisplayClass7_0_1_U3CDeserializeObjectAsyncU3Eb__1_m1DFA51FB72D3535556A6E207E951C43339AA3539 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_IN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t24E56290D667FE3FA8EC73FA2F253266AA7C58D3_mB4F17A688523DF8B2E4894D70FC007C8FED244DB },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_IN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t2C28CF9C03929594CF87B5D63CBCE934339A4D04_m8DBADFFBE776290F97A8704B666F9F348B3572D6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t29E3C00E637770CAE35C54462073A9B5FFE62D41_m32BDC5C7C1309E5D4799962FB5237CA69F1F6732 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_IN_TYPE_t6F3541AED2CEA8C0D0C4AF4028801B97F2BA4735 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IN_TYPE_t6F3541AED2CEA8C0D0C4AF4028801B97F2BA4735 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ITEM_TYPEU5BU5D_t62AA8F456903FB8998BC3CF39CB8C24B26CC6F2C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ITEM_TYPEU5BU5D_t62AA8F456903FB8998BC3CF39CB8C24B26CC6F2C },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_ITEM_TYPE_t93DF867F5BF8B8DFABB7E16C3C6006CAE626ECC9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ITEM_TYPE_t93DF867F5BF8B8DFABB7E16C3C6006CAE626ECC9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_SerializeToken_TisFROM_TYPE_tCBA11A0A0B4DBAEC7AB66F3AAF918BB714FD6AF5_mEE70EA3463E9C7CAFB08F534AAD69842CD5E93CC },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_FROM_TYPE_t4A6CEAACBF4B3BD03D0F1CB6A6AE6A4CBC60FF85 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_FROM_TYPE_t4A6CEAACBF4B3BD03D0F1CB6A6AE6A4CBC60FF85 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_tFAFAD028A21C8AC6113128B6072F114AD3F49092_mE81FC75A0DD34F7119C27E098D8B1EFE8AC27D57 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_2_t09D1FBAA199EE3A5C3D05F8EE2938218D0B7F3EB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_2_Invoke_m4E232944FF87A89CA8A23DFD63EDD5C8CEB45706 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_JsonConvert_DeserializeIntoObject_TisIN_TYPE_t7B18BDEA13918DE234C07526B55E8EC61FF01DA4_mAF6ED4DA3614E11C1BBD8168A6A188256461AB69 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_2_t5134859EA1D179A65306CC08560420CB76382E60 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_2_Invoke_m4CEBA72C411996B24E317BC10A43D633A91AFE10 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tFF2C78A98D5471F414ECE0284899758B10749975 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tFF2C78A98D5471F414ECE0284899758B10749975 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_WitResponseNode_Cast_TisT_t433BE44C793E00A0BE12BF38A035B538AF82195D_m73AEE2DA09907B081A6C7E3E9313A6B2528CDED4 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Meta_WitAi_Lib_CodeGenModule;
const Il2CppCodeGenModule g_Meta_WitAi_Lib_CodeGenModule = 
{
	"Meta.WitAi.Lib.dll",
	379,
	s_methodPointers,
	7,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	23,
	s_rgctxIndices,
	68,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
