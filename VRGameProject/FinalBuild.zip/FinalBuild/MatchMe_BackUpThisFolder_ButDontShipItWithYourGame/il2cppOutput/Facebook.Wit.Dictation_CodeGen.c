﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 Meta.WitAi.Dictation.DictationService Meta.WitAi.Utilities.DictationServiceReference::get_DictationService()
extern void DictationServiceReference_get_DictationService_mBBF4697608C8D3865F010FCD7686BAB83FB6F970 (void);
// 0x00000002 System.Void Meta.WitAi.Utilities.DictationServiceReference/<>c::.cctor()
extern void U3CU3Ec__cctor_mA45599AF3CE5DB9A1438BD91360547BBF9A7840B (void);
// 0x00000003 System.Void Meta.WitAi.Utilities.DictationServiceReference/<>c::.ctor()
extern void U3CU3Ec__ctor_m3D91B3CA05DB77683CCE14F40668B58848343292 (void);
// 0x00000004 System.Boolean Meta.WitAi.Utilities.DictationServiceReference/<>c::<get_DictationService>b__2_0(Meta.WitAi.Dictation.DictationService)
extern void U3CU3Ec_U3Cget_DictationServiceU3Eb__2_0_m5EAEC25BEB18D37A15FBC8E0E333D038ACB58057 (void);
// 0x00000005 Meta.WitAi.Interfaces.IAudioInputEvents Meta.WitAi.ServiceReferences.DictationServiceAudioEventReference::get_AudioEvents()
extern void DictationServiceAudioEventReference_get_AudioEvents_m7DBFBF3EE5C2A3568058BE5FFA0B8108B337A21F (void);
// 0x00000006 System.Void Meta.WitAi.ServiceReferences.DictationServiceAudioEventReference::.ctor()
extern void DictationServiceAudioEventReference__ctor_m928385DB395A2224A8EA04E259A683C51777755D (void);
// 0x00000007 System.Boolean Meta.WitAi.Dictation.DictationService::get_Active()
// 0x00000008 System.Boolean Meta.WitAi.Dictation.DictationService::get_IsRequestActive()
// 0x00000009 Meta.WitAi.Interfaces.ITranscriptionProvider Meta.WitAi.Dictation.DictationService::get_TranscriptionProvider()
// 0x0000000A System.Void Meta.WitAi.Dictation.DictationService::set_TranscriptionProvider(Meta.WitAi.Interfaces.ITranscriptionProvider)
// 0x0000000B System.Boolean Meta.WitAi.Dictation.DictationService::get_MicActive()
// 0x0000000C Meta.WitAi.Dictation.Events.DictationEvents Meta.WitAi.Dictation.DictationService::get_DictationEvents()
extern void DictationService_get_DictationEvents_m8AC884290BAE5CCC90FAF6BC365069268BBF9954 (void);
// 0x0000000D System.Void Meta.WitAi.Dictation.DictationService::set_DictationEvents(Meta.WitAi.Dictation.Events.DictationEvents)
extern void DictationService_set_DictationEvents_mD1DAAEA17A092E58DE1DD666C58CB673762BC40E (void);
// 0x0000000E Meta.WitAi.Interfaces.IAudioInputEvents Meta.WitAi.Dictation.DictationService::get_AudioEvents()
extern void DictationService_get_AudioEvents_m3C42CABF347FD00F6389BF5713414F63AB4E41CA (void);
// 0x0000000F Meta.WitAi.Interfaces.ITranscriptionEvent Meta.WitAi.Dictation.DictationService::get_TranscriptionEvents()
extern void DictationService_get_TranscriptionEvents_m0AA144BB870C93CF7B3CFBE1B0E2233A7CAF490D (void);
// 0x00000010 System.Boolean Meta.WitAi.Dictation.DictationService::get_ShouldSendMicData()
// 0x00000011 System.Void Meta.WitAi.Dictation.DictationService::Activate()
// 0x00000012 System.Void Meta.WitAi.Dictation.DictationService::Activate(Meta.WitAi.Configuration.WitRequestOptions)
// 0x00000013 System.Void Meta.WitAi.Dictation.DictationService::ActivateImmediately()
// 0x00000014 System.Void Meta.WitAi.Dictation.DictationService::ActivateImmediately(Meta.WitAi.Configuration.WitRequestOptions)
// 0x00000015 System.Void Meta.WitAi.Dictation.DictationService::Deactivate()
// 0x00000016 System.Void Meta.WitAi.Dictation.DictationService::Cancel()
// 0x00000017 System.Void Meta.WitAi.Dictation.DictationService::Awake()
extern void DictationService_Awake_m9D73AD12F09FB78124E8A44A318387BD1395C8DE (void);
// 0x00000018 System.Void Meta.WitAi.Dictation.DictationService::OnEnable()
extern void DictationService_OnEnable_m9F359DBD0CCD1D5F2670FC7A2089ECD12263D514 (void);
// 0x00000019 System.Void Meta.WitAi.Dictation.DictationService::OnDisable()
extern void DictationService_OnDisable_m844C346816A56ADC5BD00D0CCB1F1521C5D1AB8B (void);
// 0x0000001A System.Void Meta.WitAi.Dictation.DictationService::.ctor()
extern void DictationService__ctor_m9AFD7A256F383D33C9825760C202FC53263EFD3F (void);
// 0x0000001B System.Boolean Meta.WitAi.Dictation.IDictationService::get_Active()
// 0x0000001C System.Boolean Meta.WitAi.Dictation.IDictationService::get_IsRequestActive()
// 0x0000001D System.Boolean Meta.WitAi.Dictation.IDictationService::get_MicActive()
// 0x0000001E Meta.WitAi.Interfaces.ITranscriptionProvider Meta.WitAi.Dictation.IDictationService::get_TranscriptionProvider()
// 0x0000001F System.Void Meta.WitAi.Dictation.IDictationService::set_TranscriptionProvider(Meta.WitAi.Interfaces.ITranscriptionProvider)
// 0x00000020 Meta.WitAi.Dictation.Events.DictationEvents Meta.WitAi.Dictation.IDictationService::get_DictationEvents()
// 0x00000021 System.Void Meta.WitAi.Dictation.IDictationService::set_DictationEvents(Meta.WitAi.Dictation.Events.DictationEvents)
// 0x00000022 System.Void Meta.WitAi.Dictation.IDictationService::Activate()
// 0x00000023 System.Void Meta.WitAi.Dictation.IDictationService::Activate(Meta.WitAi.Configuration.WitRequestOptions)
// 0x00000024 System.Void Meta.WitAi.Dictation.IDictationService::ActivateImmediately()
// 0x00000025 System.Void Meta.WitAi.Dictation.IDictationService::ActivateImmediately(Meta.WitAi.Configuration.WitRequestOptions)
// 0x00000026 System.Void Meta.WitAi.Dictation.IDictationService::Deactivate()
// 0x00000027 System.Void Meta.WitAi.Dictation.MultiRequestTranscription::Awake()
extern void MultiRequestTranscription_Awake_m6F7E8454470B18A790B209BFC57F2AFA454D39C0 (void);
// 0x00000028 System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnEnable()
extern void MultiRequestTranscription_OnEnable_mF602729FDB134E3223950C7611F62EB328226F29 (void);
// 0x00000029 System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnDisable()
extern void MultiRequestTranscription_OnDisable_mDD7E1DD93954962B4A6FE4B0625F0E05972D1498 (void);
// 0x0000002A System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnCancelled()
extern void MultiRequestTranscription_OnCancelled_m3A9BE081F6B613099699E3F1C9BF492B693A6446 (void);
// 0x0000002B System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnFullTranscription(System.String)
extern void MultiRequestTranscription_OnFullTranscription_mC89778BE8EA34158E3298FE30BC5754EDA67C147 (void);
// 0x0000002C System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnPartialTranscription(System.String)
extern void MultiRequestTranscription_OnPartialTranscription_m90F3C83D530D86D412B4DF5B6F08FD80CBEFDD88 (void);
// 0x0000002D System.Void Meta.WitAi.Dictation.MultiRequestTranscription::Clear()
extern void MultiRequestTranscription_Clear_m8CD44A26B552FB8D5B5D9BAA5473B9872837FFB7 (void);
// 0x0000002E System.Void Meta.WitAi.Dictation.MultiRequestTranscription::OnTranscriptionUpdated()
extern void MultiRequestTranscription_OnTranscriptionUpdated_mA1D9172ED9D56787F329A62CDD4EE67989B0C8B1 (void);
// 0x0000002F System.Void Meta.WitAi.Dictation.MultiRequestTranscription::.ctor()
extern void MultiRequestTranscription__ctor_m9C3007EB5ADAEF134AE951402F11323921E95C2B (void);
// 0x00000030 Meta.WitAi.Configuration.WitRuntimeConfiguration Meta.WitAi.Dictation.WitDictation::get_RuntimeConfiguration()
extern void WitDictation_get_RuntimeConfiguration_m6BCE26A1878B1DFB3219C48D88F03FC9192EE969 (void);
// 0x00000031 System.Void Meta.WitAi.Dictation.WitDictation::set_RuntimeConfiguration(Meta.WitAi.Configuration.WitRuntimeConfiguration)
extern void WitDictation_set_RuntimeConfiguration_m5A2175C6DC4A2C23207F8825498E45D41B946619 (void);
// 0x00000032 System.Boolean Meta.WitAi.Dictation.WitDictation::get_Active()
extern void WitDictation_get_Active_m198CD33AF690E5620E5A01E9DB1126389C0B34F7 (void);
// 0x00000033 System.Boolean Meta.WitAi.Dictation.WitDictation::get_IsRequestActive()
extern void WitDictation_get_IsRequestActive_mF35C76CC3C8FD2A79E74C23C005D4302BA5F2A6B (void);
// 0x00000034 Meta.WitAi.Interfaces.ITranscriptionProvider Meta.WitAi.Dictation.WitDictation::get_TranscriptionProvider()
extern void WitDictation_get_TranscriptionProvider_mDC07DEA5374AF78A15607E1733EF0CFE2A2A4AA5 (void);
// 0x00000035 System.Void Meta.WitAi.Dictation.WitDictation::set_TranscriptionProvider(Meta.WitAi.Interfaces.ITranscriptionProvider)
extern void WitDictation_set_TranscriptionProvider_m6B39103D4D20D8AE423910645CC1B4B416545038 (void);
// 0x00000036 System.Boolean Meta.WitAi.Dictation.WitDictation::get_MicActive()
extern void WitDictation_get_MicActive_m1167ADD43F2CB541E21F0C0D8E14CA966555433D (void);
// 0x00000037 System.Boolean Meta.WitAi.Dictation.WitDictation::get_ShouldSendMicData()
extern void WitDictation_get_ShouldSendMicData_m3041AF3961F04A9814C841AC1B1E9F5CC045869C (void);
// 0x00000038 Meta.WitAi.Events.VoiceEvents Meta.WitAi.Dictation.WitDictation::get_VoiceEvents()
extern void WitDictation_get_VoiceEvents_m66661FAAA1C63820EE312715796544C6E5DAA3AD (void);
// 0x00000039 Meta.WitAi.WitRequest Meta.WitAi.Dictation.WitDictation::CreateWitRequest(Meta.WitAi.Data.Configuration.WitConfiguration,Meta.WitAi.Configuration.WitRequestOptions,Meta.WitAi.Interfaces.IDynamicEntitiesProvider[])
extern void WitDictation_CreateWitRequest_m136D79E5725D6F101E5DB42B58906E18B67C3869 (void);
// 0x0000003A System.Void Meta.WitAi.Dictation.WitDictation::Activate()
extern void WitDictation_Activate_m3E26A0F2A1B448C19785C95C56E6B53720280352 (void);
// 0x0000003B System.Void Meta.WitAi.Dictation.WitDictation::Activate(Meta.WitAi.Configuration.WitRequestOptions)
extern void WitDictation_Activate_mA4708CD9701A8219068C129EDDB4D271E49873A5 (void);
// 0x0000003C System.Void Meta.WitAi.Dictation.WitDictation::ActivateImmediately()
extern void WitDictation_ActivateImmediately_m028BD3250DDFC34CDFC28F932243C78CBEAC5428 (void);
// 0x0000003D System.Void Meta.WitAi.Dictation.WitDictation::ActivateImmediately(Meta.WitAi.Configuration.WitRequestOptions)
extern void WitDictation_ActivateImmediately_m5F1050CAFD8131A13885925635FDF8B51EB96F06 (void);
// 0x0000003E System.Void Meta.WitAi.Dictation.WitDictation::Deactivate()
extern void WitDictation_Deactivate_mBE7AF4E15741C97D20D2536155942478E420D1E5 (void);
// 0x0000003F System.Void Meta.WitAi.Dictation.WitDictation::Cancel()
extern void WitDictation_Cancel_m21A6871EB9D84DDD328FB92F208AAF74E59DC74F (void);
// 0x00000040 System.Void Meta.WitAi.Dictation.WitDictation::Awake()
extern void WitDictation_Awake_m36915B9A96B6F6EF630E1E516AC25AB8445B1012 (void);
// 0x00000041 System.Void Meta.WitAi.Dictation.WitDictation::OnEnable()
extern void WitDictation_OnEnable_m16057356D681B4D8B7395741A1117CDB839B74A6 (void);
// 0x00000042 System.Void Meta.WitAi.Dictation.WitDictation::OnDisable()
extern void WitDictation_OnDisable_m2956D048C9B2EAF9B37B17344FFC50A18847138B (void);
// 0x00000043 System.Void Meta.WitAi.Dictation.WitDictation::OnFullTranscription(System.String)
extern void WitDictation_OnFullTranscription_mB979C1F62FB47C820BF31BA7F04250D91D2C1B4F (void);
// 0x00000044 System.Void Meta.WitAi.Dictation.WitDictation::OnPartialTranscription(System.String)
extern void WitDictation_OnPartialTranscription_m83DFA5443B44A07A7D5C3E82B5E08FA3ECF95C4D (void);
// 0x00000045 System.Void Meta.WitAi.Dictation.WitDictation::OnStartedListening()
extern void WitDictation_OnStartedListening_m464FDA30E89DF77DB190C72A631C8CB98BEDC223 (void);
// 0x00000046 System.Void Meta.WitAi.Dictation.WitDictation::OnStoppedListening()
extern void WitDictation_OnStoppedListening_mC32CA94A288168F7C974DA055772C45D86B070BB (void);
// 0x00000047 System.Void Meta.WitAi.Dictation.WitDictation::OnMicLevelChanged(System.Single)
extern void WitDictation_OnMicLevelChanged_mEE2468D32D7C0FF4938ABACD7B2FAD1E9A2CD315 (void);
// 0x00000048 System.Void Meta.WitAi.Dictation.WitDictation::OnError(System.String,System.String)
extern void WitDictation_OnError_mF2E6F654A4B79E07B81DD86F513AAB342B646906 (void);
// 0x00000049 System.Void Meta.WitAi.Dictation.WitDictation::OnResponse(Meta.WitAi.Json.WitResponseNode)
extern void WitDictation_OnResponse_m60FF7A1A8182A554D7B107CCE07B8C5AE21C7FF2 (void);
// 0x0000004A System.Void Meta.WitAi.Dictation.WitDictation::.ctor()
extern void WitDictation__ctor_m6542096D76D48501EC363C5505C9574A453FF639 (void);
// 0x0000004B Meta.WitAi.Events.WitTranscriptionEvent Meta.WitAi.Dictation.Events.DictationEvents::get_OnPartialTranscription()
extern void DictationEvents_get_OnPartialTranscription_mCDCD111A32EBA35AE4BE2BB7EF11646DB76F7817 (void);
// 0x0000004C Meta.WitAi.Events.WitTranscriptionEvent Meta.WitAi.Dictation.Events.DictationEvents::get_OnFullTranscription()
extern void DictationEvents_get_OnFullTranscription_m0D27B26C941EFF4EC66D01F12B538D1C83EF4683 (void);
// 0x0000004D Meta.WitAi.Events.WitMicLevelChangedEvent Meta.WitAi.Dictation.Events.DictationEvents::get_OnMicAudioLevelChanged()
extern void DictationEvents_get_OnMicAudioLevelChanged_mA04FB964636684048C4149EF20F0006CA49EA671 (void);
// 0x0000004E UnityEngine.Events.UnityEvent Meta.WitAi.Dictation.Events.DictationEvents::get_OnMicStartedListening()
extern void DictationEvents_get_OnMicStartedListening_m55106F28C21FBD7BF7AC64A8A48D89D59AFFD01A (void);
// 0x0000004F UnityEngine.Events.UnityEvent Meta.WitAi.Dictation.Events.DictationEvents::get_OnMicStoppedListening()
extern void DictationEvents_get_OnMicStoppedListening_m3143BBDC2CB324152B52D355FCE34936ACEA3692 (void);
// 0x00000050 System.Void Meta.WitAi.Dictation.Events.DictationEvents::.ctor()
extern void DictationEvents__ctor_m14BB8C94EE1C58ED5D2C5E63C6F1F5742C22E337 (void);
// 0x00000051 System.Void Meta.WitAi.Dictation.Events.DictationSessionEvent::.ctor()
extern void DictationSessionEvent__ctor_m5AC84A37F1FFA43CC9CF86A7F3D413679A8802D3 (void);
// 0x00000052 System.Void Meta.WitAi.Dictation.Data.DictationSession::.ctor()
extern void DictationSession__ctor_m9B95E1111F60E6D443065FA7A37B09790A887AE4 (void);
static Il2CppMethodPointer s_methodPointers[82] = 
{
	DictationServiceReference_get_DictationService_mBBF4697608C8D3865F010FCD7686BAB83FB6F970,
	U3CU3Ec__cctor_mA45599AF3CE5DB9A1438BD91360547BBF9A7840B,
	U3CU3Ec__ctor_m3D91B3CA05DB77683CCE14F40668B58848343292,
	U3CU3Ec_U3Cget_DictationServiceU3Eb__2_0_m5EAEC25BEB18D37A15FBC8E0E333D038ACB58057,
	DictationServiceAudioEventReference_get_AudioEvents_m7DBFBF3EE5C2A3568058BE5FFA0B8108B337A21F,
	DictationServiceAudioEventReference__ctor_m928385DB395A2224A8EA04E259A683C51777755D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	DictationService_get_DictationEvents_m8AC884290BAE5CCC90FAF6BC365069268BBF9954,
	DictationService_set_DictationEvents_mD1DAAEA17A092E58DE1DD666C58CB673762BC40E,
	DictationService_get_AudioEvents_m3C42CABF347FD00F6389BF5713414F63AB4E41CA,
	DictationService_get_TranscriptionEvents_m0AA144BB870C93CF7B3CFBE1B0E2233A7CAF490D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	DictationService_Awake_m9D73AD12F09FB78124E8A44A318387BD1395C8DE,
	DictationService_OnEnable_m9F359DBD0CCD1D5F2670FC7A2089ECD12263D514,
	DictationService_OnDisable_m844C346816A56ADC5BD00D0CCB1F1521C5D1AB8B,
	DictationService__ctor_m9AFD7A256F383D33C9825760C202FC53263EFD3F,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	MultiRequestTranscription_Awake_m6F7E8454470B18A790B209BFC57F2AFA454D39C0,
	MultiRequestTranscription_OnEnable_mF602729FDB134E3223950C7611F62EB328226F29,
	MultiRequestTranscription_OnDisable_mDD7E1DD93954962B4A6FE4B0625F0E05972D1498,
	MultiRequestTranscription_OnCancelled_m3A9BE081F6B613099699E3F1C9BF492B693A6446,
	MultiRequestTranscription_OnFullTranscription_mC89778BE8EA34158E3298FE30BC5754EDA67C147,
	MultiRequestTranscription_OnPartialTranscription_m90F3C83D530D86D412B4DF5B6F08FD80CBEFDD88,
	MultiRequestTranscription_Clear_m8CD44A26B552FB8D5B5D9BAA5473B9872837FFB7,
	MultiRequestTranscription_OnTranscriptionUpdated_mA1D9172ED9D56787F329A62CDD4EE67989B0C8B1,
	MultiRequestTranscription__ctor_m9C3007EB5ADAEF134AE951402F11323921E95C2B,
	WitDictation_get_RuntimeConfiguration_m6BCE26A1878B1DFB3219C48D88F03FC9192EE969,
	WitDictation_set_RuntimeConfiguration_m5A2175C6DC4A2C23207F8825498E45D41B946619,
	WitDictation_get_Active_m198CD33AF690E5620E5A01E9DB1126389C0B34F7,
	WitDictation_get_IsRequestActive_mF35C76CC3C8FD2A79E74C23C005D4302BA5F2A6B,
	WitDictation_get_TranscriptionProvider_mDC07DEA5374AF78A15607E1733EF0CFE2A2A4AA5,
	WitDictation_set_TranscriptionProvider_m6B39103D4D20D8AE423910645CC1B4B416545038,
	WitDictation_get_MicActive_m1167ADD43F2CB541E21F0C0D8E14CA966555433D,
	WitDictation_get_ShouldSendMicData_m3041AF3961F04A9814C841AC1B1E9F5CC045869C,
	WitDictation_get_VoiceEvents_m66661FAAA1C63820EE312715796544C6E5DAA3AD,
	WitDictation_CreateWitRequest_m136D79E5725D6F101E5DB42B58906E18B67C3869,
	WitDictation_Activate_m3E26A0F2A1B448C19785C95C56E6B53720280352,
	WitDictation_Activate_mA4708CD9701A8219068C129EDDB4D271E49873A5,
	WitDictation_ActivateImmediately_m028BD3250DDFC34CDFC28F932243C78CBEAC5428,
	WitDictation_ActivateImmediately_m5F1050CAFD8131A13885925635FDF8B51EB96F06,
	WitDictation_Deactivate_mBE7AF4E15741C97D20D2536155942478E420D1E5,
	WitDictation_Cancel_m21A6871EB9D84DDD328FB92F208AAF74E59DC74F,
	WitDictation_Awake_m36915B9A96B6F6EF630E1E516AC25AB8445B1012,
	WitDictation_OnEnable_m16057356D681B4D8B7395741A1117CDB839B74A6,
	WitDictation_OnDisable_m2956D048C9B2EAF9B37B17344FFC50A18847138B,
	WitDictation_OnFullTranscription_mB979C1F62FB47C820BF31BA7F04250D91D2C1B4F,
	WitDictation_OnPartialTranscription_m83DFA5443B44A07A7D5C3E82B5E08FA3ECF95C4D,
	WitDictation_OnStartedListening_m464FDA30E89DF77DB190C72A631C8CB98BEDC223,
	WitDictation_OnStoppedListening_mC32CA94A288168F7C974DA055772C45D86B070BB,
	WitDictation_OnMicLevelChanged_mEE2468D32D7C0FF4938ABACD7B2FAD1E9A2CD315,
	WitDictation_OnError_mF2E6F654A4B79E07B81DD86F513AAB342B646906,
	WitDictation_OnResponse_m60FF7A1A8182A554D7B107CCE07B8C5AE21C7FF2,
	WitDictation__ctor_m6542096D76D48501EC363C5505C9574A453FF639,
	DictationEvents_get_OnPartialTranscription_mCDCD111A32EBA35AE4BE2BB7EF11646DB76F7817,
	DictationEvents_get_OnFullTranscription_m0D27B26C941EFF4EC66D01F12B538D1C83EF4683,
	DictationEvents_get_OnMicAudioLevelChanged_mA04FB964636684048C4149EF20F0006CA49EA671,
	DictationEvents_get_OnMicStartedListening_m55106F28C21FBD7BF7AC64A8A48D89D59AFFD01A,
	DictationEvents_get_OnMicStoppedListening_m3143BBDC2CB324152B52D355FCE34936ACEA3692,
	DictationEvents__ctor_m14BB8C94EE1C58ED5D2C5E63C6F1F5742C22E337,
	DictationSessionEvent__ctor_m5AC84A37F1FFA43CC9CF86A7F3D413679A8802D3,
	DictationSession__ctor_m9B95E1111F60E6D443065FA7A37B09790A887AE4,
};
extern void DictationServiceReference_get_DictationService_mBBF4697608C8D3865F010FCD7686BAB83FB6F970_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[1] = 
{
	{ 0x06000001, DictationServiceReference_get_DictationService_mBBF4697608C8D3865F010FCD7686BAB83FB6F970_AdjustorThunk },
};
static const int32_t s_InvokerIndices[82] = 
{
	5697,
	8805,
	5809,
	3411,
	5697,
	5809,
	0,
	0,
	0,
	0,
	0,
	5697,
	4680,
	5697,
	5697,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5809,
	5809,
	5809,
	5809,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5809,
	5809,
	5809,
	5809,
	4680,
	4680,
	5809,
	5809,
	5809,
	5697,
	4680,
	5610,
	5610,
	5697,
	4680,
	5610,
	5610,
	5697,
	1360,
	5809,
	4680,
	5809,
	4680,
	5809,
	5809,
	5809,
	5809,
	5809,
	4680,
	4680,
	5809,
	5809,
	4721,
	2733,
	4680,
	5809,
	5697,
	5697,
	5697,
	5697,
	5697,
	5809,
	5809,
	5809,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Facebook_Wit_Dictation_CodeGenModule;
const Il2CppCodeGenModule g_Facebook_Wit_Dictation_CodeGenModule = 
{
	"Facebook.Wit.Dictation.dll",
	82,
	s_methodPointers,
	1,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
