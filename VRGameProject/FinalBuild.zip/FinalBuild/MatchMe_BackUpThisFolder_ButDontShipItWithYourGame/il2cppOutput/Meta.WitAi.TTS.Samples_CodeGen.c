﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::OnEnable()
extern void TTSCacheToggle_OnEnable_m4BB182CD11683D061C8B51E13406B105F48E18E6 (void);
// 0x00000002 Meta.WitAi.TTS.Data.TTSDiskCacheLocation Meta.WitAi.TTS.Samples.TTSCacheToggle::GetCurrentCacheLocation()
extern void TTSCacheToggle_GetCurrentCacheLocation_mB8E5DFFAB1D1A957F0E03AB8464F594ACF33C134 (void);
// 0x00000003 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::Update()
extern void TTSCacheToggle_Update_m36775E0B77E5453B7BF8312799D240B2F4CB8AF0 (void);
// 0x00000004 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::RefreshLocation()
extern void TTSCacheToggle_RefreshLocation_m398386BE76BD8FAB1BDA9D4E0E0C4E97384FE4C1 (void);
// 0x00000005 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::OnDisable()
extern void TTSCacheToggle_OnDisable_m36DFA73E65C0F646F1A55260C3B368F74D20C3DF (void);
// 0x00000006 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::ToggleCache()
extern void TTSCacheToggle_ToggleCache_m12ED4A95681CC396660F71736590891731A93F40 (void);
// 0x00000007 System.Void Meta.WitAi.TTS.Samples.TTSCacheToggle::.ctor()
extern void TTSCacheToggle__ctor_m43B17F5DC2B8182B7C95373AEB085526615ADBED (void);
// 0x00000008 System.Void Meta.WitAi.TTS.Samples.TTSErrorText::Update()
extern void TTSErrorText_Update_mED02A9EA5CDD638EA5DCA6D668D4D0D21E693940 (void);
// 0x00000009 System.Void Meta.WitAi.TTS.Samples.TTSErrorText::.ctor()
extern void TTSErrorText__ctor_mE821155DA78F843906B9F523F51F07436935133B (void);
// 0x0000000A System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::OnEnable()
extern void TTSSpeakerInput_OnEnable_m95890A80A68B4A048EC3BDE04F5C3092BEB56448 (void);
// 0x0000000B System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::StopClick()
extern void TTSSpeakerInput_StopClick_m9ACC3361839C482CCB5F71CFDFFAB90D31EDC553 (void);
// 0x0000000C System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::SpeakClick()
extern void TTSSpeakerInput_SpeakClick_m6275F381EE597F002F75F7606B4B66F94D2C11A6 (void);
// 0x0000000D System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::SpeakQueuedClick()
extern void TTSSpeakerInput_SpeakQueuedClick_m20D86A57FF5A9A5A8CE711D313C69B74B252E5F6 (void);
// 0x0000000E System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::OnDisable()
extern void TTSSpeakerInput_OnDisable_mA633C3F3D320B38C9D6B0745559483BACD454EBA (void);
// 0x0000000F System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::Update()
extern void TTSSpeakerInput_Update_mB24644F92F46C3BA773EACACCA8EA73E467059F2 (void);
// 0x00000010 System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::RefreshButtons()
extern void TTSSpeakerInput_RefreshButtons_mB9BA66FD8B2A8C75A24A04A4F7EEE0EF001789FE (void);
// 0x00000011 System.Void Meta.WitAi.TTS.Samples.TTSSpeakerInput::.ctor()
extern void TTSSpeakerInput__ctor_m5BC1ED850F1D55DE0A37AA6426294D035F3059F8 (void);
// 0x00000012 System.Void Meta.WitAi.TTS.Samples.TTSStatusLabel::OnEnable()
extern void TTSStatusLabel_OnEnable_mE65A77398C534AE3B154969790BE963BEDDB7464 (void);
// 0x00000013 System.Void Meta.WitAi.TTS.Samples.TTSStatusLabel::OnClipRefresh(Meta.WitAi.TTS.Data.TTSClipData)
extern void TTSStatusLabel_OnClipRefresh_mD171A96A03E7544BE26E2531A9C7AB44DE0D0A46 (void);
// 0x00000014 System.Void Meta.WitAi.TTS.Samples.TTSStatusLabel::OnDisable()
extern void TTSStatusLabel_OnDisable_m747D14B1AC2C126E05F1C77CDFC1F6853C225A65 (void);
// 0x00000015 System.Void Meta.WitAi.TTS.Samples.TTSStatusLabel::RefreshLabel()
extern void TTSStatusLabel_RefreshLabel_m590AF96190B603AC0A8DDA52396157F851B6FE09 (void);
// 0x00000016 System.Void Meta.WitAi.TTS.Samples.TTSStatusLabel::.ctor()
extern void TTSStatusLabel__ctor_mEC750383310FD572E6FDEB5A8E114A5FA9501E4C (void);
static Il2CppMethodPointer s_methodPointers[22] = 
{
	TTSCacheToggle_OnEnable_m4BB182CD11683D061C8B51E13406B105F48E18E6,
	TTSCacheToggle_GetCurrentCacheLocation_mB8E5DFFAB1D1A957F0E03AB8464F594ACF33C134,
	TTSCacheToggle_Update_m36775E0B77E5453B7BF8312799D240B2F4CB8AF0,
	TTSCacheToggle_RefreshLocation_m398386BE76BD8FAB1BDA9D4E0E0C4E97384FE4C1,
	TTSCacheToggle_OnDisable_m36DFA73E65C0F646F1A55260C3B368F74D20C3DF,
	TTSCacheToggle_ToggleCache_m12ED4A95681CC396660F71736590891731A93F40,
	TTSCacheToggle__ctor_m43B17F5DC2B8182B7C95373AEB085526615ADBED,
	TTSErrorText_Update_mED02A9EA5CDD638EA5DCA6D668D4D0D21E693940,
	TTSErrorText__ctor_mE821155DA78F843906B9F523F51F07436935133B,
	TTSSpeakerInput_OnEnable_m95890A80A68B4A048EC3BDE04F5C3092BEB56448,
	TTSSpeakerInput_StopClick_m9ACC3361839C482CCB5F71CFDFFAB90D31EDC553,
	TTSSpeakerInput_SpeakClick_m6275F381EE597F002F75F7606B4B66F94D2C11A6,
	TTSSpeakerInput_SpeakQueuedClick_m20D86A57FF5A9A5A8CE711D313C69B74B252E5F6,
	TTSSpeakerInput_OnDisable_mA633C3F3D320B38C9D6B0745559483BACD454EBA,
	TTSSpeakerInput_Update_mB24644F92F46C3BA773EACACCA8EA73E467059F2,
	TTSSpeakerInput_RefreshButtons_mB9BA66FD8B2A8C75A24A04A4F7EEE0EF001789FE,
	TTSSpeakerInput__ctor_m5BC1ED850F1D55DE0A37AA6426294D035F3059F8,
	TTSStatusLabel_OnEnable_mE65A77398C534AE3B154969790BE963BEDDB7464,
	TTSStatusLabel_OnClipRefresh_mD171A96A03E7544BE26E2531A9C7AB44DE0D0A46,
	TTSStatusLabel_OnDisable_m747D14B1AC2C126E05F1C77CDFC1F6853C225A65,
	TTSStatusLabel_RefreshLabel_m590AF96190B603AC0A8DDA52396157F851B6FE09,
	TTSStatusLabel__ctor_mEC750383310FD572E6FDEB5A8E114A5FA9501E4C,
};
static const int32_t s_InvokerIndices[22] = 
{
	5809,
	5664,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	4680,
	5809,
	5809,
	5809,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Meta_WitAi_TTS_Samples_CodeGenModule;
const Il2CppCodeGenModule g_Meta_WitAi_TTS_Samples_CodeGenModule = 
{
	"Meta.WitAi.TTS.Samples.dll",
	22,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
