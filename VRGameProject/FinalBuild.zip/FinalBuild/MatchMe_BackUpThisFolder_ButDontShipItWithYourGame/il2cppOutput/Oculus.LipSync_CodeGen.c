﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Boolean EnableSwitch::SetActive(System.Int32)
// 0x00000002 System.Void EnableSwitch::.ctor()
extern void EnableSwitch__ctor_mE72E742E898359EA09C1EF6F848101E883D8D472 (void);
// 0x00000003 System.Void LipSyncDemo_Control::Start()
extern void LipSyncDemo_Control_Start_mD61FF5EC57256867670F56E615CDE00C489BCCCC (void);
// 0x00000004 System.Void LipSyncDemo_Control::Update()
extern void LipSyncDemo_Control_Update_m7B91861566C82A7B488893351682EB9187085B97 (void);
// 0x00000005 System.Void LipSyncDemo_Control::RotateObject(System.Single,System.Boolean)
extern void LipSyncDemo_Control_RotateObject_m29A4CACA02BB9ECCC113D2B108AD86925A264F79 (void);
// 0x00000006 System.Void LipSyncDemo_Control::.ctor()
extern void LipSyncDemo_Control__ctor_m0D4EB555A1662062EA296126E0B26BB3760E6A0D (void);
// 0x00000007 System.Void LipSyncDemo_SetCurrentTarget::Start()
extern void LipSyncDemo_SetCurrentTarget_Start_m67F42B5B5A77B7B3B7C72C03FF665874FCE61D77 (void);
// 0x00000008 System.Void LipSyncDemo_SetCurrentTarget::Update()
extern void LipSyncDemo_SetCurrentTarget_Update_m502A02B4AAB38D27190D8AF302478C0A00F7C3A4 (void);
// 0x00000009 System.Void LipSyncDemo_SetCurrentTarget::SetCurrentTarget()
extern void LipSyncDemo_SetCurrentTarget_SetCurrentTarget_m5A81EA774D09972A52027E11133E1C23CB387AD1 (void);
// 0x0000000A System.Void LipSyncDemo_SetCurrentTarget::LocalTouchEventCallback(OVRTouchpad/TouchEvent)
extern void LipSyncDemo_SetCurrentTarget_LocalTouchEventCallback_mF78151F48D5753BD04744D2D37D5954B56918E8A (void);
// 0x0000000B System.Void LipSyncDemo_SetCurrentTarget::.ctor()
extern void LipSyncDemo_SetCurrentTarget__ctor_mE4AE5A8FB74E36B4C1909BF210B6FFE3CE7429D0 (void);
// 0x0000000C OVRLipSyncDebugConsole OVRLipSyncDebugConsole::get_instance()
extern void OVRLipSyncDebugConsole_get_instance_m5136E16AE86AD7AFD760D19D5C1AE6097CC7EE04 (void);
// 0x0000000D System.Void OVRLipSyncDebugConsole::Awake()
extern void OVRLipSyncDebugConsole_Awake_m4BAB99D6C3E4CE6BAB60203F694FEF5986C054F9 (void);
// 0x0000000E System.Void OVRLipSyncDebugConsole::Update()
extern void OVRLipSyncDebugConsole_Update_m26FAC24289B42871DD17B681DC6DA547F59B7C26 (void);
// 0x0000000F System.Void OVRLipSyncDebugConsole::Init()
extern void OVRLipSyncDebugConsole_Init_m40AF585CF27DF7836484BA4DA871AB42ADA5D925 (void);
// 0x00000010 System.Void OVRLipSyncDebugConsole::Log(System.String)
extern void OVRLipSyncDebugConsole_Log_m2353FB6DB33D2796707D1890C28EB208F93CF1D5 (void);
// 0x00000011 System.Void OVRLipSyncDebugConsole::Log(System.String,UnityEngine.Color)
extern void OVRLipSyncDebugConsole_Log_mEFBEA44BEA112F9AF872A14A42ECAF434370B1FB (void);
// 0x00000012 System.Void OVRLipSyncDebugConsole::Clear()
extern void OVRLipSyncDebugConsole_Clear_m10890ABBC562F45B35035DD7B5A58BA009DFF433 (void);
// 0x00000013 System.Void OVRLipSyncDebugConsole::ClearTimeout(System.Single)
extern void OVRLipSyncDebugConsole_ClearTimeout_m87019EC4F6C00C72813563EE683157F637CE98D2 (void);
// 0x00000014 System.Void OVRLipSyncDebugConsole::AddMessage(System.String,UnityEngine.Color)
extern void OVRLipSyncDebugConsole_AddMessage_m3BA3F343DDEF65CA1F6A3D15C3528E3B2EB10359 (void);
// 0x00000015 System.Void OVRLipSyncDebugConsole::ClearMessages()
extern void OVRLipSyncDebugConsole_ClearMessages_m7D109CBFB9671146726C3B4D043A3A0046897513 (void);
// 0x00000016 System.Void OVRLipSyncDebugConsole::SetClearTimeout(System.Single)
extern void OVRLipSyncDebugConsole_SetClearTimeout_m0A6EA8CA30ECF2C669B0A1A0B855191B24EF9DFB (void);
// 0x00000017 System.Void OVRLipSyncDebugConsole::Prune()
extern void OVRLipSyncDebugConsole_Prune_m9CC441286CCCAD82F8F484D531D0982375B178FE (void);
// 0x00000018 System.Void OVRLipSyncDebugConsole::Display()
extern void OVRLipSyncDebugConsole_Display_mDB12A529E56335F593483297CC39A2DDF218E52D (void);
// 0x00000019 System.Void OVRLipSyncDebugConsole::.ctor()
extern void OVRLipSyncDebugConsole__ctor_m77B4AF2CEBEA44F2268986509576318A5FFE774B (void);
// 0x0000001A System.Void OVRNamedArrayAttribute::.ctor(System.String[])
extern void OVRNamedArrayAttribute__ctor_m360E4C1EA5E151092C27923E6FC8AB3D48C84A5D (void);
// 0x0000001B System.Void OVRTouchpad::Create()
extern void OVRTouchpad_Create_mEE84F9A1ED6F55F5561DD92BD66513CE20556FCE (void);
// 0x0000001C System.Void OVRTouchpad::Update()
extern void OVRTouchpad_Update_m5FB58A304AC0A94FDCCD715990513207CF25F2B4 (void);
// 0x0000001D System.Void OVRTouchpad::OnDisable()
extern void OVRTouchpad_OnDisable_m469F4E9B94BAF25E2656A03121DE1695D32DF2AD (void);
// 0x0000001E System.Void OVRTouchpad::HandleInputMouse(UnityEngine.Vector3&)
extern void OVRTouchpad_HandleInputMouse_mB126CA19341087E38A8F7EA051716CF58DCABAD6 (void);
// 0x0000001F System.Void OVRTouchpad::AddListener(OVRTouchpad/OVRTouchpadCallback`1<OVRTouchpad/TouchEvent>)
extern void OVRTouchpad_AddListener_m8CC5F239D7D99785B75E49CA5E8F53B787D528C0 (void);
// 0x00000020 System.Void OVRTouchpad::.cctor()
extern void OVRTouchpad__cctor_m92CCA3A91716B90B1AAE1672622D02F475159F14 (void);
// 0x00000021 System.Void OVRTouchpad/OVRTouchpadCallback`1::.ctor(System.Object,System.IntPtr)
// 0x00000022 System.Void OVRTouchpad/OVRTouchpadCallback`1::Invoke(TouchEvent)
// 0x00000023 System.IAsyncResult OVRTouchpad/OVRTouchpadCallback`1::BeginInvoke(TouchEvent,System.AsyncCallback,System.Object)
// 0x00000024 System.Void OVRTouchpad/OVRTouchpadCallback`1::EndInvoke(System.IAsyncResult)
// 0x00000025 System.Void OVRTouchpadHelper::Awake()
extern void OVRTouchpadHelper_Awake_m0F2E78B1ABC521210B139E220714A68976345AE2 (void);
// 0x00000026 System.Void OVRTouchpadHelper::Start()
extern void OVRTouchpadHelper_Start_m2622513855BAA57F8CDA3CF31F5FA97B94D90E6E (void);
// 0x00000027 System.Void OVRTouchpadHelper::Update()
extern void OVRTouchpadHelper_Update_mDCAD89C7986F6B6E889BA3161185107EC1533856 (void);
// 0x00000028 System.Void OVRTouchpadHelper::OnDisable()
extern void OVRTouchpadHelper_OnDisable_m8AFD640C303F1109E525605BE6FC8E4F17742B48 (void);
// 0x00000029 System.Void OVRTouchpadHelper::LocalTouchEventCallback(OVRTouchpad/TouchEvent)
extern void OVRTouchpadHelper_LocalTouchEventCallback_m81D26F9A2165CCE1AA460D9FE7AE47868198FDAF (void);
// 0x0000002A System.Void OVRTouchpadHelper::.ctor()
extern void OVRTouchpadHelper__ctor_m4FEACA45B51F8D5EA4C222B6E4240A1C4D1DAC90 (void);
// 0x0000002B System.Int32 OVRLipSync::ovrLipSyncDll_Initialize(System.Int32,System.Int32)
extern void OVRLipSync_ovrLipSyncDll_Initialize_mA161686A204076AF6E704EC1B2DAED45A1191DE2 (void);
// 0x0000002C System.Void OVRLipSync::ovrLipSyncDll_Shutdown()
extern void OVRLipSync_ovrLipSyncDll_Shutdown_m978DA2F71AA319AE5FDD835CAB8C383F5A84DAC1 (void);
// 0x0000002D System.IntPtr OVRLipSync::ovrLipSyncDll_GetVersion(System.Int32&,System.Int32&,System.Int32&)
extern void OVRLipSync_ovrLipSyncDll_GetVersion_m72B0F26E56090434155410823570F50E1DCADAC5 (void);
// 0x0000002E System.Int32 OVRLipSync::ovrLipSyncDll_CreateContextEx(System.UInt32&,OVRLipSync/ContextProviders,System.Int32,System.Boolean)
extern void OVRLipSync_ovrLipSyncDll_CreateContextEx_mF2540DF2E19BCA2EF35C0BB6EC4FFBB39460F3D0 (void);
// 0x0000002F System.Int32 OVRLipSync::ovrLipSyncDll_CreateContextWithModelFile(System.UInt32&,OVRLipSync/ContextProviders,System.String,System.Int32,System.Boolean)
extern void OVRLipSync_ovrLipSyncDll_CreateContextWithModelFile_m020FBE30EBAAE4301BEFAEA20AB231FD71FC893C (void);
// 0x00000030 System.Int32 OVRLipSync::ovrLipSyncDll_DestroyContext(System.UInt32)
extern void OVRLipSync_ovrLipSyncDll_DestroyContext_m6FD5E601543E60C1B89C5838CA4844F8DDB74347 (void);
// 0x00000031 System.Int32 OVRLipSync::ovrLipSyncDll_ResetContext(System.UInt32)
extern void OVRLipSync_ovrLipSyncDll_ResetContext_mBBFD0CFE660A11AD5F5A5850CC355D1F938878A3 (void);
// 0x00000032 System.Int32 OVRLipSync::ovrLipSyncDll_SendSignal(System.UInt32,OVRLipSync/Signals,System.Int32,System.Int32)
extern void OVRLipSync_ovrLipSyncDll_SendSignal_mE6B16167C3132CFE704B16D693791266115A6AAC (void);
// 0x00000033 System.Int32 OVRLipSync::ovrLipSyncDll_ProcessFrameEx(System.UInt32,System.IntPtr,System.UInt32,OVRLipSync/AudioDataType,System.Int32&,System.Int32&,System.Single[],System.Int32,System.Single&,System.Single[],System.Int32)
extern void OVRLipSync_ovrLipSyncDll_ProcessFrameEx_m383D0D4D61586A6088C20D67C7C39DB3C8030CFF (void);
// 0x00000034 System.Void OVRLipSync::Awake()
extern void OVRLipSync_Awake_m6AA5625E000FBC90B889BE73E73571C9C634A588 (void);
// 0x00000035 System.Void OVRLipSync::OnDestroy()
extern void OVRLipSync_OnDestroy_mCE3CBE51585AAB5E517E7D527C9D7D06C50009D3 (void);
// 0x00000036 OVRLipSync/Result OVRLipSync::Initialize()
extern void OVRLipSync_Initialize_m92618978D1C6B7B7E2AD3ED264750AFC4AF11687 (void);
// 0x00000037 OVRLipSync/Result OVRLipSync::Initialize(System.Int32,System.Int32)
extern void OVRLipSync_Initialize_m902174CA6C0749143304B7FF940C36E0196E4116 (void);
// 0x00000038 System.Void OVRLipSync::Shutdown()
extern void OVRLipSync_Shutdown_m0C2D53E108AA8FE698FEF8FBAC5746C9D8BE5930 (void);
// 0x00000039 OVRLipSync/Result OVRLipSync::IsInitialized()
extern void OVRLipSync_IsInitialized_m5C2C8059233A23524755FCE74D6EB39A137F0DE9 (void);
// 0x0000003A OVRLipSync/Result OVRLipSync::CreateContext(System.UInt32&,OVRLipSync/ContextProviders,System.Int32,System.Boolean)
extern void OVRLipSync_CreateContext_m079C78F8C463689DB21E7D32F76E7AC1D3135BCB (void);
// 0x0000003B OVRLipSync/Result OVRLipSync::CreateContextWithModelFile(System.UInt32&,OVRLipSync/ContextProviders,System.String,System.Int32,System.Boolean)
extern void OVRLipSync_CreateContextWithModelFile_mD7432B12E6495B74814F5C59D7BA0D40FC00BC8A (void);
// 0x0000003C OVRLipSync/Result OVRLipSync::DestroyContext(System.UInt32)
extern void OVRLipSync_DestroyContext_mD23D11B36E7071A0EC412CA08BB0388FEF0120AD (void);
// 0x0000003D OVRLipSync/Result OVRLipSync::ResetContext(System.UInt32)
extern void OVRLipSync_ResetContext_mEBBCBF3AF3E54D9BC9723845CE5C2EC2F2344621 (void);
// 0x0000003E OVRLipSync/Result OVRLipSync::SendSignal(System.UInt32,OVRLipSync/Signals,System.Int32,System.Int32)
extern void OVRLipSync_SendSignal_m1E9FEBA68B27C762870C821CF4A881FAAE82D63C (void);
// 0x0000003F OVRLipSync/Result OVRLipSync::ProcessFrame(System.UInt32,System.Single[],OVRLipSync/Frame,System.Boolean)
extern void OVRLipSync_ProcessFrame_mE99AFA1039366502604103ADA195260227DEE894 (void);
// 0x00000040 OVRLipSync/Result OVRLipSync::ProcessFrame(System.UInt32,System.Int16[],OVRLipSync/Frame,System.Boolean)
extern void OVRLipSync_ProcessFrame_mD51F03950149B894DE8B11BC2AA38D63FAA21359 (void);
// 0x00000041 System.Void OVRLipSync::.ctor()
extern void OVRLipSync__ctor_m79F9A695633ADA166A4BC4770327431281E1EDB0 (void);
// 0x00000042 System.Void OVRLipSync::.cctor()
extern void OVRLipSync__cctor_mEFF2260DAC6C1A4E1ED1A3A715210F82132419A6 (void);
// 0x00000043 System.Void OVRLipSync/Frame::CopyInput(OVRLipSync/Frame)
extern void Frame_CopyInput_mDACD5AE8AFA2C234C024E9A674185D36CDF57D3C (void);
// 0x00000044 System.Void OVRLipSync/Frame::Reset()
extern void Frame_Reset_mA904DD302A84A3C379678DD0AAF23125F30EAEF9 (void);
// 0x00000045 System.Void OVRLipSync/Frame::.ctor()
extern void Frame__ctor_mCA97A7417F15B2823CF976520DF43B6FB35C1E60 (void);
// 0x00000046 System.Void OVRLipSyncContext::Start()
extern void OVRLipSyncContext_Start_m7C604203871A33028EDDF1D64B6E16429D5D5F26 (void);
// 0x00000047 System.Void OVRLipSyncContext::HandleKeyboard()
extern void OVRLipSyncContext_HandleKeyboard_m2553A2BAB8E5465F23892541906874AEF5408B2F (void);
// 0x00000048 System.Void OVRLipSyncContext::Update()
extern void OVRLipSyncContext_Update_mC5E5A6FC37B9DFE23D1525DCA3DE82C7CE09D36C (void);
// 0x00000049 System.Void OVRLipSyncContext::PreprocessAudioSamples(System.Single[],System.Int32)
extern void OVRLipSyncContext_PreprocessAudioSamples_m43A04A34249FCF972BFB003218F9D9C40BDC0F84 (void);
// 0x0000004A System.Void OVRLipSyncContext::PostprocessAudioSamples(System.Single[],System.Int32)
extern void OVRLipSyncContext_PostprocessAudioSamples_m2BC51CAE2B76C7763168CBF55CD938E44A078DA0 (void);
// 0x0000004B System.Void OVRLipSyncContext::ProcessAudioSamplesRaw(System.Single[],System.Int32)
extern void OVRLipSyncContext_ProcessAudioSamplesRaw_m49D38D12F79C89DFA4636B46693979058CEF8B39 (void);
// 0x0000004C System.Void OVRLipSyncContext::ProcessAudioSamplesRaw(System.Int16[],System.Int32)
extern void OVRLipSyncContext_ProcessAudioSamplesRaw_m18B7364EA25213D7AE49F25CC5FB8734028E3124 (void);
// 0x0000004D System.Void OVRLipSyncContext::ProcessAudioSamples(System.Single[],System.Int32)
extern void OVRLipSyncContext_ProcessAudioSamples_m978496F3EE2E028A70ACE94B1959521B193671DF (void);
// 0x0000004E System.Void OVRLipSyncContext::OnAudioFilterRead(System.Single[],System.Int32)
extern void OVRLipSyncContext_OnAudioFilterRead_m7D05A4AC14FD926BFB345546622069432CA7EFB3 (void);
// 0x0000004F System.Void OVRLipSyncContext::DebugShowVisemesAndLaughter()
extern void OVRLipSyncContext_DebugShowVisemesAndLaughter_m4786192F726A5C6643133DD6BC56C875A20BBC26 (void);
// 0x00000050 System.Void OVRLipSyncContext::ToggleAudioLoopback()
extern void OVRLipSyncContext_ToggleAudioLoopback_mDC98A79DD567236B491EBC1ABD70CB3F24075177 (void);
// 0x00000051 System.Void OVRLipSyncContext::LocalTouchEventCallback(OVRTouchpad/TouchEvent)
extern void OVRLipSyncContext_LocalTouchEventCallback_m6A3C29151BC0D19D9E3B6AF3D4FB2250FA98FA2F (void);
// 0x00000052 System.Void OVRLipSyncContext::.ctor()
extern void OVRLipSyncContext__ctor_m16ADFBFC859E4E16B553EF1971FE1D5D5D6ED8EE (void);
// 0x00000053 System.Void OVRLipSyncContextBase::set_Smoothing(System.Int32)
extern void OVRLipSyncContextBase_set_Smoothing_mF36E6D20D1DCCA3486C70236664D9FD4E594DFCC (void);
// 0x00000054 System.Int32 OVRLipSyncContextBase::get_Smoothing()
extern void OVRLipSyncContextBase_get_Smoothing_mBFAC8B1ADE67B5A7FC8161E148A80E2326C8863E (void);
// 0x00000055 System.UInt32 OVRLipSyncContextBase::get_Context()
extern void OVRLipSyncContextBase_get_Context_mE1AEE864A95099C27C6B4B3DE6927EE77E6F6A4B (void);
// 0x00000056 OVRLipSync/Frame OVRLipSyncContextBase::get_Frame()
extern void OVRLipSyncContextBase_get_Frame_mD56E93629948BFC610036BEBC7734A9E7BF33615 (void);
// 0x00000057 System.Void OVRLipSyncContextBase::Awake()
extern void OVRLipSyncContextBase_Awake_m50F0C37F60E3505442A62A0D09628D59314C9D43 (void);
// 0x00000058 System.Void OVRLipSyncContextBase::OnDestroy()
extern void OVRLipSyncContextBase_OnDestroy_mBB530D7B6853B028C3AAA6FC401571376DF25D48 (void);
// 0x00000059 OVRLipSync/Frame OVRLipSyncContextBase::GetCurrentPhonemeFrame()
extern void OVRLipSyncContextBase_GetCurrentPhonemeFrame_m127A12A7BACF1AA262993583031CA6F83D4A5241 (void);
// 0x0000005A System.Void OVRLipSyncContextBase::SetVisemeBlend(System.Int32,System.Int32)
extern void OVRLipSyncContextBase_SetVisemeBlend_mAED102713610BDBCF112C9FBE5C626AB3DAE21BD (void);
// 0x0000005B System.Void OVRLipSyncContextBase::SetLaughterBlend(System.Int32)
extern void OVRLipSyncContextBase_SetLaughterBlend_m0C718E3F2730F42BD7504E53AD92432D006C8235 (void);
// 0x0000005C OVRLipSync/Result OVRLipSyncContextBase::ResetContext()
extern void OVRLipSyncContextBase_ResetContext_mF7A26EFFD9061357DF95FDA1A9E6806A732A7D70 (void);
// 0x0000005D System.Void OVRLipSyncContextBase::.ctor()
extern void OVRLipSyncContextBase__ctor_m87E551988E99045E4C57C66E04806A29DAE9AD9F (void);
// 0x0000005E System.Void OVRLipSyncContextCanned::Update()
extern void OVRLipSyncContextCanned_Update_m69A2F14B47DFFBA76877486809A3B3C38FD1AEF2 (void);
// 0x0000005F System.Void OVRLipSyncContextCanned::.ctor()
extern void OVRLipSyncContextCanned__ctor_m25C4F5274C4463145DD0B36CA5506EF4D8E23809 (void);
// 0x00000060 System.Void OVRLipSyncContextMorphTarget::Start()
extern void OVRLipSyncContextMorphTarget_Start_m00BCB9D9C90145E2284740D791D2282DE620C640 (void);
// 0x00000061 System.Void OVRLipSyncContextMorphTarget::Update()
extern void OVRLipSyncContextMorphTarget_Update_m98306988F30B6A67A7FC811B4FC045636ABB5CDA (void);
// 0x00000062 System.Void OVRLipSyncContextMorphTarget::CheckForKeys()
extern void OVRLipSyncContextMorphTarget_CheckForKeys_mEFBE74C5D8D347F5C84FF0009E4AFB4BAE120857 (void);
// 0x00000063 System.Void OVRLipSyncContextMorphTarget::SetVisemeToMorphTarget(OVRLipSync/Frame)
extern void OVRLipSyncContextMorphTarget_SetVisemeToMorphTarget_m94F3445300EF9A8E7397FE446CE37C8CF60E1A6A (void);
// 0x00000064 System.Void OVRLipSyncContextMorphTarget::SetLaughterToMorphTarget(OVRLipSync/Frame)
extern void OVRLipSyncContextMorphTarget_SetLaughterToMorphTarget_m30A3E5438BD0DFFF1DFED309B160FDAC40823D21 (void);
// 0x00000065 System.Void OVRLipSyncContextMorphTarget::CheckVisemeKey(UnityEngine.KeyCode,System.Int32,System.Int32)
extern void OVRLipSyncContextMorphTarget_CheckVisemeKey_m900E54C0D9EFB919162F72FE5C9AD7389A5E34A7 (void);
// 0x00000066 System.Void OVRLipSyncContextMorphTarget::CheckLaughterKey()
extern void OVRLipSyncContextMorphTarget_CheckLaughterKey_mB4375E7063168871DD9B611959191A5F99E362EF (void);
// 0x00000067 System.Void OVRLipSyncContextMorphTarget::.ctor()
extern void OVRLipSyncContextMorphTarget__ctor_m4BD0825BA9256E1BE698420017E2311943F25674 (void);
// 0x00000068 System.Void OVRLipSyncContextTextureFlip::Start()
extern void OVRLipSyncContextTextureFlip_Start_m43F5ED5A31A8CB1CCB609A0E87938878ABC2D56A (void);
// 0x00000069 System.Void OVRLipSyncContextTextureFlip::Update()
extern void OVRLipSyncContextTextureFlip_Update_mCCEC4161BB0F685F82FC0AA29619DB5F28F4C8A7 (void);
// 0x0000006A System.Void OVRLipSyncContextTextureFlip::SetVisemeToTexture()
extern void OVRLipSyncContextTextureFlip_SetVisemeToTexture_mBB7FAE6CCC1E95D60B716B4E34FB0BE5F30DF591 (void);
// 0x0000006B System.Void OVRLipSyncContextTextureFlip::.ctor()
extern void OVRLipSyncContextTextureFlip__ctor_mB56F62942975E353F8AD1AC89FE14D1BFCE46C31 (void);
// 0x0000006C System.Single OVRLipSyncMicInput::get_MicFrequency()
extern void OVRLipSyncMicInput_get_MicFrequency_mB30FA9E7E7CC52B5C6FFDEFEF27C75768C485D5F (void);
// 0x0000006D System.Void OVRLipSyncMicInput::set_MicFrequency(System.Single)
extern void OVRLipSyncMicInput_set_MicFrequency_m2ABC5C24A8A72DAD4A90878B4B3A0F81D1F5D1EF (void);
// 0x0000006E System.Void OVRLipSyncMicInput::Awake()
extern void OVRLipSyncMicInput_Awake_mCEB8360478A5EFDE008F1FB9C55C32B68D248CDF (void);
// 0x0000006F System.Void OVRLipSyncMicInput::Start()
extern void OVRLipSyncMicInput_Start_m6B9AECBC940CEABF8BFFF6CD2A644ADE659C1380 (void);
// 0x00000070 System.Void OVRLipSyncMicInput::InitializeMicrophone()
extern void OVRLipSyncMicInput_InitializeMicrophone_m44E60AEF9019BF2C240D30CC05F8ABE0C3F7BC58 (void);
// 0x00000071 System.Void OVRLipSyncMicInput::Update()
extern void OVRLipSyncMicInput_Update_mBE5B51CF7D939373CEDCC633B66B90816F82CB6C (void);
// 0x00000072 System.Void OVRLipSyncMicInput::OnApplicationFocus(System.Boolean)
extern void OVRLipSyncMicInput_OnApplicationFocus_m0E38B2208A857A6DDDE5BC65C3EB6E55E220ADDB (void);
// 0x00000073 System.Void OVRLipSyncMicInput::OnApplicationPause(System.Boolean)
extern void OVRLipSyncMicInput_OnApplicationPause_mD847C058EAE5D3D28EDDBCDDA409647A87C31663 (void);
// 0x00000074 System.Void OVRLipSyncMicInput::OnDisable()
extern void OVRLipSyncMicInput_OnDisable_mAFEF651D195845CFCA9E7E741445E85C9F86B5DB (void);
// 0x00000075 System.Void OVRLipSyncMicInput::OnGUI()
extern void OVRLipSyncMicInput_OnGUI_m9AE5D20D23BE9EAE541DB5C1438828F9CCC94498 (void);
// 0x00000076 System.Void OVRLipSyncMicInput::MicDeviceGUI(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void OVRLipSyncMicInput_MicDeviceGUI_m71CA3A9A7DABA45775D3CD772985A959E93C49F8 (void);
// 0x00000077 System.Void OVRLipSyncMicInput::GetMicCaps()
extern void OVRLipSyncMicInput_GetMicCaps_m100A78F2F3EEBAC5B8FA3C7E157CA9CCFA23C287 (void);
// 0x00000078 System.Void OVRLipSyncMicInput::StartMicrophone()
extern void OVRLipSyncMicInput_StartMicrophone_mD04A664F502023B643FD67A1A9A7A33BFB6CF868 (void);
// 0x00000079 System.Void OVRLipSyncMicInput::StopMicrophone()
extern void OVRLipSyncMicInput_StopMicrophone_mE5816D8BEC13511C7F2F0DDA1016A3B7E3229F8C (void);
// 0x0000007A System.Single OVRLipSyncMicInput::GetAveragedVolume()
extern void OVRLipSyncMicInput_GetAveragedVolume_m9E1228AB9F1AF75C3378E16ED65F4CBA298C1323 (void);
// 0x0000007B System.Void OVRLipSyncMicInput::.ctor()
extern void OVRLipSyncMicInput__ctor_m8CD13ABCD29CC2462AB99AC85FDE5383D3688B0F (void);
// 0x0000007C OVRLipSync/Frame OVRLipSyncSequence::GetFrameAtTime(System.Single)
extern void OVRLipSyncSequence_GetFrameAtTime_mDC0ED3C51DCB005CBF622102FEB1C8BA2BECB340 (void);
// 0x0000007D System.Void OVRLipSyncSequence::.ctor()
extern void OVRLipSyncSequence__ctor_mD5225FE34F0EE2A2A1571AE385DC919165F92075 (void);
static Il2CppMethodPointer s_methodPointers[125] = 
{
	NULL,
	EnableSwitch__ctor_mE72E742E898359EA09C1EF6F848101E883D8D472,
	LipSyncDemo_Control_Start_mD61FF5EC57256867670F56E615CDE00C489BCCCC,
	LipSyncDemo_Control_Update_m7B91861566C82A7B488893351682EB9187085B97,
	LipSyncDemo_Control_RotateObject_m29A4CACA02BB9ECCC113D2B108AD86925A264F79,
	LipSyncDemo_Control__ctor_m0D4EB555A1662062EA296126E0B26BB3760E6A0D,
	LipSyncDemo_SetCurrentTarget_Start_m67F42B5B5A77B7B3B7C72C03FF665874FCE61D77,
	LipSyncDemo_SetCurrentTarget_Update_m502A02B4AAB38D27190D8AF302478C0A00F7C3A4,
	LipSyncDemo_SetCurrentTarget_SetCurrentTarget_m5A81EA774D09972A52027E11133E1C23CB387AD1,
	LipSyncDemo_SetCurrentTarget_LocalTouchEventCallback_mF78151F48D5753BD04744D2D37D5954B56918E8A,
	LipSyncDemo_SetCurrentTarget__ctor_mE4AE5A8FB74E36B4C1909BF210B6FFE3CE7429D0,
	OVRLipSyncDebugConsole_get_instance_m5136E16AE86AD7AFD760D19D5C1AE6097CC7EE04,
	OVRLipSyncDebugConsole_Awake_m4BAB99D6C3E4CE6BAB60203F694FEF5986C054F9,
	OVRLipSyncDebugConsole_Update_m26FAC24289B42871DD17B681DC6DA547F59B7C26,
	OVRLipSyncDebugConsole_Init_m40AF585CF27DF7836484BA4DA871AB42ADA5D925,
	OVRLipSyncDebugConsole_Log_m2353FB6DB33D2796707D1890C28EB208F93CF1D5,
	OVRLipSyncDebugConsole_Log_mEFBEA44BEA112F9AF872A14A42ECAF434370B1FB,
	OVRLipSyncDebugConsole_Clear_m10890ABBC562F45B35035DD7B5A58BA009DFF433,
	OVRLipSyncDebugConsole_ClearTimeout_m87019EC4F6C00C72813563EE683157F637CE98D2,
	OVRLipSyncDebugConsole_AddMessage_m3BA3F343DDEF65CA1F6A3D15C3528E3B2EB10359,
	OVRLipSyncDebugConsole_ClearMessages_m7D109CBFB9671146726C3B4D043A3A0046897513,
	OVRLipSyncDebugConsole_SetClearTimeout_m0A6EA8CA30ECF2C669B0A1A0B855191B24EF9DFB,
	OVRLipSyncDebugConsole_Prune_m9CC441286CCCAD82F8F484D531D0982375B178FE,
	OVRLipSyncDebugConsole_Display_mDB12A529E56335F593483297CC39A2DDF218E52D,
	OVRLipSyncDebugConsole__ctor_m77B4AF2CEBEA44F2268986509576318A5FFE774B,
	OVRNamedArrayAttribute__ctor_m360E4C1EA5E151092C27923E6FC8AB3D48C84A5D,
	OVRTouchpad_Create_mEE84F9A1ED6F55F5561DD92BD66513CE20556FCE,
	OVRTouchpad_Update_m5FB58A304AC0A94FDCCD715990513207CF25F2B4,
	OVRTouchpad_OnDisable_m469F4E9B94BAF25E2656A03121DE1695D32DF2AD,
	OVRTouchpad_HandleInputMouse_mB126CA19341087E38A8F7EA051716CF58DCABAD6,
	OVRTouchpad_AddListener_m8CC5F239D7D99785B75E49CA5E8F53B787D528C0,
	OVRTouchpad__cctor_m92CCA3A91716B90B1AAE1672622D02F475159F14,
	NULL,
	NULL,
	NULL,
	NULL,
	OVRTouchpadHelper_Awake_m0F2E78B1ABC521210B139E220714A68976345AE2,
	OVRTouchpadHelper_Start_m2622513855BAA57F8CDA3CF31F5FA97B94D90E6E,
	OVRTouchpadHelper_Update_mDCAD89C7986F6B6E889BA3161185107EC1533856,
	OVRTouchpadHelper_OnDisable_m8AFD640C303F1109E525605BE6FC8E4F17742B48,
	OVRTouchpadHelper_LocalTouchEventCallback_m81D26F9A2165CCE1AA460D9FE7AE47868198FDAF,
	OVRTouchpadHelper__ctor_m4FEACA45B51F8D5EA4C222B6E4240A1C4D1DAC90,
	OVRLipSync_ovrLipSyncDll_Initialize_mA161686A204076AF6E704EC1B2DAED45A1191DE2,
	OVRLipSync_ovrLipSyncDll_Shutdown_m978DA2F71AA319AE5FDD835CAB8C383F5A84DAC1,
	OVRLipSync_ovrLipSyncDll_GetVersion_m72B0F26E56090434155410823570F50E1DCADAC5,
	OVRLipSync_ovrLipSyncDll_CreateContextEx_mF2540DF2E19BCA2EF35C0BB6EC4FFBB39460F3D0,
	OVRLipSync_ovrLipSyncDll_CreateContextWithModelFile_m020FBE30EBAAE4301BEFAEA20AB231FD71FC893C,
	OVRLipSync_ovrLipSyncDll_DestroyContext_m6FD5E601543E60C1B89C5838CA4844F8DDB74347,
	OVRLipSync_ovrLipSyncDll_ResetContext_mBBFD0CFE660A11AD5F5A5850CC355D1F938878A3,
	OVRLipSync_ovrLipSyncDll_SendSignal_mE6B16167C3132CFE704B16D693791266115A6AAC,
	OVRLipSync_ovrLipSyncDll_ProcessFrameEx_m383D0D4D61586A6088C20D67C7C39DB3C8030CFF,
	OVRLipSync_Awake_m6AA5625E000FBC90B889BE73E73571C9C634A588,
	OVRLipSync_OnDestroy_mCE3CBE51585AAB5E517E7D527C9D7D06C50009D3,
	OVRLipSync_Initialize_m92618978D1C6B7B7E2AD3ED264750AFC4AF11687,
	OVRLipSync_Initialize_m902174CA6C0749143304B7FF940C36E0196E4116,
	OVRLipSync_Shutdown_m0C2D53E108AA8FE698FEF8FBAC5746C9D8BE5930,
	OVRLipSync_IsInitialized_m5C2C8059233A23524755FCE74D6EB39A137F0DE9,
	OVRLipSync_CreateContext_m079C78F8C463689DB21E7D32F76E7AC1D3135BCB,
	OVRLipSync_CreateContextWithModelFile_mD7432B12E6495B74814F5C59D7BA0D40FC00BC8A,
	OVRLipSync_DestroyContext_mD23D11B36E7071A0EC412CA08BB0388FEF0120AD,
	OVRLipSync_ResetContext_mEBBCBF3AF3E54D9BC9723845CE5C2EC2F2344621,
	OVRLipSync_SendSignal_m1E9FEBA68B27C762870C821CF4A881FAAE82D63C,
	OVRLipSync_ProcessFrame_mE99AFA1039366502604103ADA195260227DEE894,
	OVRLipSync_ProcessFrame_mD51F03950149B894DE8B11BC2AA38D63FAA21359,
	OVRLipSync__ctor_m79F9A695633ADA166A4BC4770327431281E1EDB0,
	OVRLipSync__cctor_mEFF2260DAC6C1A4E1ED1A3A715210F82132419A6,
	Frame_CopyInput_mDACD5AE8AFA2C234C024E9A674185D36CDF57D3C,
	Frame_Reset_mA904DD302A84A3C379678DD0AAF23125F30EAEF9,
	Frame__ctor_mCA97A7417F15B2823CF976520DF43B6FB35C1E60,
	OVRLipSyncContext_Start_m7C604203871A33028EDDF1D64B6E16429D5D5F26,
	OVRLipSyncContext_HandleKeyboard_m2553A2BAB8E5465F23892541906874AEF5408B2F,
	OVRLipSyncContext_Update_mC5E5A6FC37B9DFE23D1525DCA3DE82C7CE09D36C,
	OVRLipSyncContext_PreprocessAudioSamples_m43A04A34249FCF972BFB003218F9D9C40BDC0F84,
	OVRLipSyncContext_PostprocessAudioSamples_m2BC51CAE2B76C7763168CBF55CD938E44A078DA0,
	OVRLipSyncContext_ProcessAudioSamplesRaw_m49D38D12F79C89DFA4636B46693979058CEF8B39,
	OVRLipSyncContext_ProcessAudioSamplesRaw_m18B7364EA25213D7AE49F25CC5FB8734028E3124,
	OVRLipSyncContext_ProcessAudioSamples_m978496F3EE2E028A70ACE94B1959521B193671DF,
	OVRLipSyncContext_OnAudioFilterRead_m7D05A4AC14FD926BFB345546622069432CA7EFB3,
	OVRLipSyncContext_DebugShowVisemesAndLaughter_m4786192F726A5C6643133DD6BC56C875A20BBC26,
	OVRLipSyncContext_ToggleAudioLoopback_mDC98A79DD567236B491EBC1ABD70CB3F24075177,
	OVRLipSyncContext_LocalTouchEventCallback_m6A3C29151BC0D19D9E3B6AF3D4FB2250FA98FA2F,
	OVRLipSyncContext__ctor_m16ADFBFC859E4E16B553EF1971FE1D5D5D6ED8EE,
	OVRLipSyncContextBase_set_Smoothing_mF36E6D20D1DCCA3486C70236664D9FD4E594DFCC,
	OVRLipSyncContextBase_get_Smoothing_mBFAC8B1ADE67B5A7FC8161E148A80E2326C8863E,
	OVRLipSyncContextBase_get_Context_mE1AEE864A95099C27C6B4B3DE6927EE77E6F6A4B,
	OVRLipSyncContextBase_get_Frame_mD56E93629948BFC610036BEBC7734A9E7BF33615,
	OVRLipSyncContextBase_Awake_m50F0C37F60E3505442A62A0D09628D59314C9D43,
	OVRLipSyncContextBase_OnDestroy_mBB530D7B6853B028C3AAA6FC401571376DF25D48,
	OVRLipSyncContextBase_GetCurrentPhonemeFrame_m127A12A7BACF1AA262993583031CA6F83D4A5241,
	OVRLipSyncContextBase_SetVisemeBlend_mAED102713610BDBCF112C9FBE5C626AB3DAE21BD,
	OVRLipSyncContextBase_SetLaughterBlend_m0C718E3F2730F42BD7504E53AD92432D006C8235,
	OVRLipSyncContextBase_ResetContext_mF7A26EFFD9061357DF95FDA1A9E6806A732A7D70,
	OVRLipSyncContextBase__ctor_m87E551988E99045E4C57C66E04806A29DAE9AD9F,
	OVRLipSyncContextCanned_Update_m69A2F14B47DFFBA76877486809A3B3C38FD1AEF2,
	OVRLipSyncContextCanned__ctor_m25C4F5274C4463145DD0B36CA5506EF4D8E23809,
	OVRLipSyncContextMorphTarget_Start_m00BCB9D9C90145E2284740D791D2282DE620C640,
	OVRLipSyncContextMorphTarget_Update_m98306988F30B6A67A7FC811B4FC045636ABB5CDA,
	OVRLipSyncContextMorphTarget_CheckForKeys_mEFBE74C5D8D347F5C84FF0009E4AFB4BAE120857,
	OVRLipSyncContextMorphTarget_SetVisemeToMorphTarget_m94F3445300EF9A8E7397FE446CE37C8CF60E1A6A,
	OVRLipSyncContextMorphTarget_SetLaughterToMorphTarget_m30A3E5438BD0DFFF1DFED309B160FDAC40823D21,
	OVRLipSyncContextMorphTarget_CheckVisemeKey_m900E54C0D9EFB919162F72FE5C9AD7389A5E34A7,
	OVRLipSyncContextMorphTarget_CheckLaughterKey_mB4375E7063168871DD9B611959191A5F99E362EF,
	OVRLipSyncContextMorphTarget__ctor_m4BD0825BA9256E1BE698420017E2311943F25674,
	OVRLipSyncContextTextureFlip_Start_m43F5ED5A31A8CB1CCB609A0E87938878ABC2D56A,
	OVRLipSyncContextTextureFlip_Update_mCCEC4161BB0F685F82FC0AA29619DB5F28F4C8A7,
	OVRLipSyncContextTextureFlip_SetVisemeToTexture_mBB7FAE6CCC1E95D60B716B4E34FB0BE5F30DF591,
	OVRLipSyncContextTextureFlip__ctor_mB56F62942975E353F8AD1AC89FE14D1BFCE46C31,
	OVRLipSyncMicInput_get_MicFrequency_mB30FA9E7E7CC52B5C6FFDEFEF27C75768C485D5F,
	OVRLipSyncMicInput_set_MicFrequency_m2ABC5C24A8A72DAD4A90878B4B3A0F81D1F5D1EF,
	OVRLipSyncMicInput_Awake_mCEB8360478A5EFDE008F1FB9C55C32B68D248CDF,
	OVRLipSyncMicInput_Start_m6B9AECBC940CEABF8BFFF6CD2A644ADE659C1380,
	OVRLipSyncMicInput_InitializeMicrophone_m44E60AEF9019BF2C240D30CC05F8ABE0C3F7BC58,
	OVRLipSyncMicInput_Update_mBE5B51CF7D939373CEDCC633B66B90816F82CB6C,
	OVRLipSyncMicInput_OnApplicationFocus_m0E38B2208A857A6DDDE5BC65C3EB6E55E220ADDB,
	OVRLipSyncMicInput_OnApplicationPause_mD847C058EAE5D3D28EDDBCDDA409647A87C31663,
	OVRLipSyncMicInput_OnDisable_mAFEF651D195845CFCA9E7E741445E85C9F86B5DB,
	OVRLipSyncMicInput_OnGUI_m9AE5D20D23BE9EAE541DB5C1438828F9CCC94498,
	OVRLipSyncMicInput_MicDeviceGUI_m71CA3A9A7DABA45775D3CD772985A959E93C49F8,
	OVRLipSyncMicInput_GetMicCaps_m100A78F2F3EEBAC5B8FA3C7E157CA9CCFA23C287,
	OVRLipSyncMicInput_StartMicrophone_mD04A664F502023B643FD67A1A9A7A33BFB6CF868,
	OVRLipSyncMicInput_StopMicrophone_mE5816D8BEC13511C7F2F0DDA1016A3B7E3229F8C,
	OVRLipSyncMicInput_GetAveragedVolume_m9E1228AB9F1AF75C3378E16ED65F4CBA298C1323,
	OVRLipSyncMicInput__ctor_m8CD13ABCD29CC2462AB99AC85FDE5383D3688B0F,
	OVRLipSyncSequence_GetFrameAtTime_mDC0ED3C51DCB005CBF622102FEB1C8BA2BECB340,
	OVRLipSyncSequence__ctor_mD5225FE34F0EE2A2A1571AE385DC919165F92075,
};
static const int32_t s_InvokerIndices[125] = 
{
	0,
	5809,
	5809,
	5809,
	2774,
	5809,
	5809,
	5809,
	5809,
	4648,
	5809,
	8773,
	5809,
	5809,
	5809,
	8626,
	8083,
	8805,
	8633,
	2722,
	5809,
	4721,
	5809,
	5809,
	5809,
	4680,
	8805,
	8805,
	8805,
	8617,
	8626,
	8805,
	0,
	0,
	0,
	0,
	5809,
	5809,
	5809,
	5809,
	4648,
	5809,
	7726,
	8805,
	7138,
	6607,
	6237,
	8370,
	8370,
	6738,
	5967,
	5809,
	5809,
	8765,
	7726,
	8805,
	8765,
	6607,
	6237,
	8370,
	8370,
	6738,
	6739,
	6739,
	5809,
	8805,
	4680,
	5809,
	5809,
	5809,
	5809,
	5809,
	2728,
	2728,
	2728,
	2728,
	2728,
	2728,
	5809,
	5809,
	4648,
	5809,
	4648,
	5664,
	5793,
	5697,
	5809,
	5809,
	5697,
	2501,
	4648,
	5664,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	4680,
	4680,
	1498,
	5809,
	5809,
	5809,
	5809,
	5809,
	5809,
	5740,
	4721,
	5809,
	5809,
	5809,
	5809,
	4589,
	4589,
	5809,
	5809,
	302,
	5809,
	5809,
	5809,
	5740,
	5809,
	4189,
	5809,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000001, { 0, 2 } },
};
extern const uint32_t g_rgctx_GameObject_GetComponent_TisT_tBF15C538FA8015BD2B53FE3A9AF07DE957714782_mE850108BD3766D0E53F76661A46E9A9A1B512413;
extern const uint32_t g_rgctx_T_tBF15C538FA8015BD2B53FE3A9AF07DE957714782;
static const Il2CppRGCTXDefinition s_rgctxValues[2] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponent_TisT_tBF15C538FA8015BD2B53FE3A9AF07DE957714782_mE850108BD3766D0E53F76661A46E9A9A1B512413 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tBF15C538FA8015BD2B53FE3A9AF07DE957714782 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Oculus_LipSync_CodeGenModule;
const Il2CppCodeGenModule g_Oculus_LipSync_CodeGenModule = 
{
	"Oculus.LipSync.dll",
	125,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	2,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
